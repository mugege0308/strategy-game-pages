"""Pygbag entry point for the browser/mobile version of the strategy game.

The Windows entry point remains ``python -m battle_game.main``.  This module
is intentionally a separate browser driver: it reuses the existing Pygame
screens and BattleEngine while providing the cooperative async loop required
by Pygbag.  No game rules are duplicated here.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any, Optional

from battle_game.free_battle import create_free_battle
from battle_game.free_battle_ui import FreeBattleApp
from battle_game.models import Faction
from battle_game.ui import PygameBattleApp
from battle_game.ui_text import find_japanese_font, load_font
from battle_game.web_input import (
    PointerDeduplicator,
    pointer_down_position,
    report_pygame_touch_event,
)


class WebGame:
    """Drive the existing menu, free-battle setup, battle, and result screens."""

    MENU_BUTTONS = ("battle", "strategy", "free_battle")

    def __init__(self, pygame_module: Any) -> None:
        self.pygame = pygame_module
        self.screen: Any = None
        self.mode = "menu"
        self.running = True
        self.free_app: Optional[FreeBattleApp] = None
        self.battle_app: Optional[PygameBattleApp] = None
        self.result_battle: Any = None
        self.suspended = False
        self.menu_message = "\u30bf\u30c3\u30d7\u3057\u3066\u30e2\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002"
        self.menu_fonts: dict[str, Any] = {}
        self.free_fonts: dict[str, Any] = {}
        self.battle_fonts: dict[str, Any] = {}
        self.result_fonts: dict[str, Any] = {}
        self._pointer_deduplicator = PointerDeduplicator()

    @staticmethod
    def menu_rects(pygame_module: Any, size: tuple[int, int]) -> dict[str, Any]:
        """Return large, touch-friendly menu buttons for the current canvas."""

        width, height = max(640, int(size[0])), max(520, int(size[1]))
        button_width = min(680, width - 80)
        button_height = 62
        left = (width - button_width) // 2
        first_y = max(150, height // 2 - 110)
        return {
            "battle": pygame_module.Rect(left, first_y, button_width, button_height),
            "strategy": pygame_module.Rect(left, first_y + 78, button_width, button_height),
            "free_battle": pygame_module.Rect(left, first_y + 156, button_width, button_height),
        }

    def _load_fonts(self) -> None:
        pygame = self.pygame
        font_path = find_japanese_font(pygame)
        self.menu_fonts = {
            "title": load_font(pygame, font_path, 32),
            "button": load_font(pygame, font_path, 20),
            "small": load_font(pygame, font_path, 16),
        }
        self.free_fonts = {
            "title": load_font(pygame, font_path, 28),
            "normal": load_font(pygame, font_path, 18),
            "small": load_font(pygame, font_path, 15),
            "button": load_font(pygame, font_path, 17),
        }
        self.battle_fonts = {
            "title": load_font(pygame, font_path, 30),
            "normal": load_font(pygame, font_path, 21),
            "small": load_font(pygame, font_path, 17),
            "button": load_font(pygame, font_path, 19),
            "cell": load_font(pygame, font_path, 20),
            "tiny": load_font(pygame, font_path, 13),
        }
        self.result_fonts = {
            "title": load_font(pygame, font_path, 32),
            "normal": load_font(pygame, font_path, 20),
            "button": load_font(pygame, font_path, 18),
        }

    def _resize(self, size: tuple[int, int]) -> None:
        pygame = self.pygame
        width, height = max(640, int(size[0])), max(560, int(size[1]))
        self.screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)
        actual_size = self.screen.get_size()
        if self.free_app is not None:
            self.free_app.set_window_size(actual_size)
        if self.battle_app is not None:
            self.battle_app.set_window_size(actual_size)

    def _pointer_position(self, event: Any) -> Optional[tuple[int, int]]:
        pygame = self.pygame
        event_type = getattr(event, "type", None)
        finger_down_type = getattr(pygame, "FINGERDOWN", None)
        finger_up_type = getattr(pygame, "FINGERUP", None)
        position = pointer_down_position(
            event,
            self.screen.get_size(),
            mouse_button_down_type=pygame.MOUSEBUTTONDOWN,
            finger_down_type=finger_down_type,
        )
        if event_type == pygame.MOUSEBUTTONDOWN:
            report_pygame_touch_event(
                "MOUSEBUTTONDOWN", getattr(event, "pos", position)
            )
        elif event_type == finger_down_type:
            report_pygame_touch_event("FINGERDOWN", position)
        elif event_type == finger_up_type:
            report_pygame_touch_event("FINGERUP")
        if position is None:
            return None
        clock = getattr(pygame, "time", None)
        get_ticks = getattr(clock, "get_ticks", None)
        time_ms = int(get_ticks()) if callable(get_ticks) else None
        if not self._pointer_deduplicator.accept(position, time_ms):
            return None
        return position

    def _handle_common_event(self, event: Any) -> Optional[tuple[int, int]]:
        pygame = self.pygame
        if event.type == pygame.QUIT:
            self.running = False
            return None
        if event.type == pygame.VIDEORESIZE:
            self._resize(event.size)
            return None
        if event.type == getattr(pygame, "WINDOWSIZECHANGED", -1):
            self._resize(self.screen.get_size())
            return None
        if event.type == getattr(pygame, "WINDOWFOCUSLOST", -1):
            self.suspended = True
            return None
        if event.type == getattr(pygame, "WINDOWFOCUSGAINED", -1):
            self.suspended = False
            self._resize(self.screen.get_size())
            return None
        return self._pointer_position(event)

    def _handle_menu(self, position: tuple[int, int]) -> None:
        rects = self.menu_rects(self.pygame, self.screen.get_size())
        for mode, rect in rects.items():
            if not rect.collidepoint(position):
                continue
            if mode == "strategy":
                # The strategic-map logic remains available in the Windows
                # frontend.  Keep this first web slice honest until its long
                # scroll/input flow has a browser-specific driver.
                self.menu_message = "\u6226\u7565\u30de\u30c3\u30d7\u306fWeb\u7248\u5bfe\u5fdc\u6e96\u5099\u4e2d\u3067\u3059\u3002\u81ea\u7531\u6226\u95d8\u3092\u5229\u7528\u3057\u3066\u304f\u3060\u3055\u3044\u3002"
                return
            if mode == "battle":
                self.battle_app = PygameBattleApp(return_on_game_over=True)
                self.battle_app.set_window_size(self.screen.get_size())
                self.mode = "battle"
                return
            self.free_app = FreeBattleApp()
            self.free_app.set_window_size(self.screen.get_size())
            self.mode = "free_battle"
            return

    def _start_free_battle(self) -> None:
        assert self.free_app is not None
        battle = create_free_battle(self.free_app.configuration, rules=self.free_app.rules)
        self.battle_app = PygameBattleApp(battle, return_on_game_over=True)
        self.battle_app.set_window_size(self.screen.get_size())
        self.mode = "battle"

    def _handle_free_battle(self, position: tuple[int, int]) -> None:
        assert self.free_app is not None
        action = self.free_app.handle_click(position)
        if action == "menu":
            self.free_app = None
            self.mode = "menu"
        elif action == "start_battle":
            self._start_free_battle()

    def _handle_battle_event(self, event: Any, position: Optional[tuple[int, int]]) -> None:
        pygame = self.pygame
        assert self.battle_app is not None
        if event.type == pygame.MOUSEMOTION:
            self.battle_app._update_hover(event.pos)
        elif event.type == pygame.MOUSEWHEEL:
            self.battle_app._handle_scroll(event.y, pygame.mouse.get_pos())
        elif position is not None:
            self.battle_app._handle_mouse_button(
                SimpleNamespace(button=1, pos=position), pygame
            )
        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                if self.battle_app.engine.game_over:
                    self.battle_app.return_requested = True
            elif event.key == pygame.K_ESCAPE:
                if self.battle_app.engine.turn_side is Faction.ALLY and not self.battle_app.engine.game_over:
                    self.battle_app._cancel_pending_selection()

    def _draw_menu(self) -> None:
        pygame = self.pygame
        width, height = self.screen.get_size()
        self.screen.fill((27, 31, 39))
        title = self.menu_fonts["title"].render("\u30bf\u30fc\u30f3\u5236\u6226\u7565\u30b2\u30fc\u30e0\uff08Web\u7248\uff09", True, (255, 230, 120))
        self.screen.blit(title, title.get_rect(center=(width // 2, max(70, height // 5))))
        labels = {
            "battle": "\u6226\u95d8\u30c7\u30e2",
            "strategy": "\u6226\u7565\u30de\u30c3\u30d7\uff08\u6e96\u5099\u4e2d\uff09",
            "free_battle": "\u81ea\u7531\u6226\u95d8\uff08\u7de8\u6210\u3057\u3066\u6226\u3046\uff09",
        }
        for mode, rect in self.menu_rects(pygame, self.screen.get_size()).items():
            pygame.draw.rect(self.screen, (80, 95, 120), rect)
            pygame.draw.rect(self.screen, (175, 185, 200), rect, 2)
            text = self.menu_fonts["button"].render(labels[mode], True, (255, 255, 255))
            self.screen.blit(text, text.get_rect(center=rect.center))
        message = self.menu_fonts["small"].render(self.menu_message, True, (205, 205, 215))
        self.screen.blit(message, message.get_rect(center=(width // 2, height - 46)))

    def _draw_battle(self) -> None:
        assert self.battle_app is not None
        self.battle_app._run_enemy_ai(self.pygame.time.get_ticks())
        self.battle_app._draw(self.screen, self.battle_fonts, self.pygame)
        if self.battle_app.engine.game_over and self.battle_app.return_requested:
            self.result_battle = self.battle_app.engine
            self.mode = "result"

    def _draw_result(self) -> None:
        pygame = self.pygame
        width, height = self.screen.get_size()
        self.screen.fill((24, 28, 38))
        winner = "\u52dd\u5229" if self.result_battle.winner is Faction.ALLY else "\u6557\u5317"
        title = self.result_fonts["title"].render(f"\u6226\u95d8\u7d50\u679c\uff1a{winner}", True, (255, 230, 120))
        self.screen.blit(title, title.get_rect(center=(width // 2, height // 4)))
        summary = FreeBattleApp._survivor_summary(self.result_battle)
        text = self.result_fonts["normal"].render(summary, True, (245, 245, 250))
        self.screen.blit(text, text.get_rect(center=(width // 2, height // 2)))
        button = pygame.Rect((width - min(420, width - 80)) // 2, height - 120, min(420, width - 80), 58)
        pygame.draw.rect(self.screen, (80, 95, 120), button)
        pygame.draw.rect(self.screen, (175, 185, 200), button, 2)
        label = self.result_fonts["button"].render("\u30e1\u30cb\u30e5\u30fc\u3078\u623b\u308b", True, (255, 255, 255))
        self.screen.blit(label, label.get_rect(center=button.center))
        self.result_button = button

    async def run(self) -> None:
        pygame = self.pygame
        pygame.init()
        self.screen = pygame.display.set_mode((960, 640), pygame.RESIZABLE)
        pygame.display.set_caption("\u30bf\u30fc\u30f3\u5236\u6226\u7565\u30b2\u30fc\u30e0\uff08Web\u7248\uff09")
        self._load_fonts()
        self.result_button: Any = pygame.Rect(0, 0, 0, 0)

        while self.running:
            for event in pygame.event.get():
                position = self._handle_common_event(event)
                if not self.running:
                    break
                if self.mode == "menu" and position is not None:
                    self._handle_menu(position)
                elif self.mode == "free_battle" and position is not None:
                    self._handle_free_battle(position)
                elif self.mode == "battle":
                    self._handle_battle_event(event, position)
                elif self.mode == "result" and position is not None:
                    if self.result_button.collidepoint(position):
                        self.mode = "menu"
                        self.battle_app = None
                        self.result_battle = None

            if self.suspended:
                await asyncio.sleep(0.05)
                continue

            if self.mode == "menu":
                self._draw_menu()
            elif self.mode == "free_battle":
                assert self.free_app is not None
                self.screen.fill((24, 28, 38))
                if self.free_app.mode == "compose":
                    self.free_app._draw_compose(self.screen, self.free_fonts, pygame)
                else:
                    self.free_app._draw_placement(self.screen, self.free_fonts, pygame)
            elif self.mode == "battle":
                self._draw_battle()
            else:
                self._draw_result()
            pygame.display.flip()
            await asyncio.sleep(0)

        pygame.quit()


async def main() -> None:
    import pygame

    await WebGame(pygame).run()


if __name__ == "__main__":
    asyncio.run(main())
