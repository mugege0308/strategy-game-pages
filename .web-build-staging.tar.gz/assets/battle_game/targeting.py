"""Pure target-position helpers, separate from damage calculation."""

from __future__ import annotations

from typing import Optional

from .models import Position
from .skills import AttackDirection


def line_positions(
    origin: Position,
    direction: AttackDirection,
    length: int,
    *,
    width: int,
    height: int,
) -> tuple[Position, ...]:
    """Return up to ``length`` in-bounds cells after ``origin``.

    This helper intentionally does not inspect units, so an enemy never blocks
    later cells in the line.
    """

    dx, dy = direction.delta
    positions: list[Position] = []
    for distance in range(1, length + 1):
        position = Position(origin.x + dx * distance, origin.y + dy * distance)
        if not (0 <= position.x < width and 0 <= position.y < height):
            break
        positions.append(position)
    return tuple(positions)


def infer_line_direction(
    origin: Position,
    target: Position,
    length: int,
) -> Optional[AttackDirection]:
    """Infer a cardinal line direction when a legacy target id is supplied."""

    for direction in AttackDirection:
        if target in line_positions(origin, direction, length, width=10**9, height=10**9):
            return direction
    return None
