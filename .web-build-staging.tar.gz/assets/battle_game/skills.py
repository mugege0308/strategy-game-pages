"""Minimal skill definitions used by character-specific combat actions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class TargetingMode(str, Enum):
    """Supported targeting shapes for the small Phase 2 skill model."""

    SINGLE = "single"
    LINE = "line"
    PAIR = "pair"


class SkillEffect(str, Enum):
    """The engine operation a skill performs after target validation."""

    DAMAGE = "damage"
    POSITION_SWAP = "position_swap"


@dataclass(frozen=True, slots=True)
class GuardDefinition:
    """Static parameters for a passive damage-guard ability.

    Percentages are integer percentages.  The battle engine selects one
    guardian at attack start and applies these values without introducing a
    character-name branch.
    """

    radius: int = 2
    damage_reduction_percent: int = 20
    lethal_share_percent: int = 50

    def __post_init__(self) -> None:
        if self.radius < 0:
            raise ValueError("guard radius must not be negative")
        for name, value in (
            ("damage_reduction_percent", self.damage_reduction_percent),
            ("lethal_share_percent", self.lethal_share_percent),
        ):
            if not 0 <= value <= 100:
                raise ValueError(f"{name} must be between 0 and 100")


class AttackDirection(str, Enum):
    """The four cardinal directions available to line skills."""

    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"

    @property
    def delta(self) -> tuple[int, int]:
        return {
            AttackDirection.UP: (0, -1),
            AttackDirection.DOWN: (0, 1),
            AttackDirection.LEFT: (-1, 0),
            AttackDirection.RIGHT: (1, 0),
        }[self]

    @classmethod
    def coerce(cls, value: "AttackDirection | str") -> "AttackDirection":
        if isinstance(value, cls):
            return value
        return cls(value.lower())


@dataclass(frozen=True, slots=True)
class SkillDefinition:
    """Static data for one battle skill.

    This is intentionally a small data object, not a full skill framework.
    ``effect`` lets the engine dispatch a small number of reusable operations
    without branching on character names or individual skill IDs.
    """

    skill_id: str
    name: str
    base_damage: int
    uses_per_battle: int = 1
    attack_range: Optional[int] = None
    targeting: TargetingMode = TargetingMode.SINGLE
    line_length: int = 1
    effect: SkillEffect = SkillEffect.DAMAGE
    uses_per_turn: Optional[int] = None
    ends_action: bool = True

    def __post_init__(self) -> None:
        if not self.skill_id:
            raise ValueError("skill_id must not be empty")
        try:
            effect = SkillEffect(self.effect)
        except ValueError as exc:
            raise ValueError(f"unknown skill effect: {self.effect}") from exc
        object.__setattr__(self, "effect", effect)
        if self.base_damage < 0:
            raise ValueError("base_damage must not be negative")
        if effect is SkillEffect.DAMAGE and self.base_damage == 0:
            raise ValueError("damage skills must have positive base_damage")
        if self.uses_per_battle <= 0:
            raise ValueError("uses_per_battle must be positive")
        if self.attack_range is not None and self.attack_range < 0:
            raise ValueError("attack_range must not be negative")
        if self.line_length <= 0:
            raise ValueError("line_length must be positive")
        if self.uses_per_turn is not None and self.uses_per_turn <= 0:
            raise ValueError("uses_per_turn must be positive")
        if not isinstance(self.ends_action, bool):
            raise ValueError("ends_action must be a bool")
        if self.targeting is TargetingMode.PAIR and self.effect is not SkillEffect.POSITION_SWAP:
            raise ValueError("pair targeting is reserved for position-swap skills")
        if self.effect is SkillEffect.POSITION_SWAP and self.targeting is not TargetingMode.PAIR:
            raise ValueError("position-swap skills must use pair targeting")


@dataclass(frozen=True, slots=True)
class AbilityDefinition:
    """Small data definition for passive character abilities.

    The engine consumes generic capability fields rather than checking a
    character or ability id. Combat-only power growth is kept separate from
    the unit's base power.
    """

    ability_id: str
    name: str
    post_attack_move_range: Optional[int] = None
    power_per_successful_attack: int = 0
    guard: Optional[GuardDefinition] = None

    def __post_init__(self) -> None:
        if not self.ability_id:
            raise ValueError("ability_id must not be empty")
        if not self.name:
            raise ValueError("ability name must not be empty")
        if self.post_attack_move_range is not None and self.post_attack_move_range <= 0:
            raise ValueError("post_attack_move_range must be positive")
        if self.power_per_successful_attack < 0:
            raise ValueError("power_per_successful_attack must not be negative")
        if self.guard is not None and not isinstance(self.guard, GuardDefinition):
            raise ValueError("guard must be a GuardDefinition")


EXCALIBUR_ID = "excalibur"
MOBILITY_SHOOTING_ID = "mobility_shooting"
BOOGIE_WOOGIE_ID = "boogie_woogie"
GUNSHIN_ID = "gunshin"
SINGLE_SALVATION_ID = "single_salvation"
