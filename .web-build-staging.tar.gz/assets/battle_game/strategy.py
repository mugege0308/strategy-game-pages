"""Data-driven strategic map, city, and faction state.

This module deliberately contains no Pygame code.  Map definitions describe
geography and connections, scenario definitions describe initial ownership,
and :class:`StrategicGameState` owns the mutable state used by a future
campaign layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import json
from math import isfinite
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Optional

from .models import Position


class StrategyDataError(ValueError):
    """Raised when a map or scenario definition is invalid."""


class RouteType(str, Enum):
    LAND = "LAND"
    SEA = "SEA"

    @classmethod
    def parse(cls, value: Any, *, context: str) -> "RouteType":
        if not isinstance(value, str):
            raise StrategyDataError(f"{context}: route type must be LAND or SEA")
        try:
            return cls(value.upper())
        except ValueError as exc:
            raise StrategyDataError(
                f"{context}: unknown route type {value!r}; expected LAND or SEA"
            ) from exc


class DomesticCommand(str, Enum):
    AGRICULTURE = "agriculture"
    COMMERCE = "commerce"
    RECRUIT = "recruit"


AGRICULTURE_RICE_GAIN = 100
COMMERCE_GOLD_GAIN = 100
RECRUIT_GOLD_COST = 100
RECRUIT_RICE_COST = 100
RECRUIT_TROOPS_GAIN = 100


@dataclass(frozen=True, slots=True)
class CityDefinition:
    city_id: str
    name: str
    position: Position
    region: Optional[str] = None

    @property
    def x(self) -> int:
        return self.position.x

    @property
    def y(self) -> int:
        return self.position.y


@dataclass(frozen=True, slots=True)
class ConnectionDefinition:
    from_city_id: str
    to_city_id: str
    route_type: RouteType

    @property
    def city_ids(self) -> tuple[str, str]:
        return self.from_city_id, self.to_city_id


@dataclass(frozen=True, slots=True)
class MapDefinition:
    map_id: str
    name: str
    width: int
    height: int
    cities: Mapping[str, CityDefinition]
    connections: tuple[ConnectionDefinition, ...]

    def city(self, city_id: str) -> CityDefinition:
        try:
            return self.cities[city_id]
        except KeyError as exc:
            raise StrategyDataError(f"map {self.map_id!r}: unknown city {city_id!r}") from exc

    def connections_for(
        self,
        city_id: str,
        route_type: Optional[RouteType] = None,
    ) -> tuple[ConnectionDefinition, ...]:
        self.city(city_id)
        return tuple(
            connection
            for connection in self.connections
            if city_id in connection.city_ids
            and (route_type is None or connection.route_type is route_type)
        )

    def neighbors(
        self,
        city_id: str,
        route_type: Optional[RouteType] = None,
    ) -> tuple[CityDefinition, ...]:
        neighbor_ids: list[str] = []
        for connection in self.connections_for(city_id, route_type):
            other_id = (
                connection.to_city_id
                if connection.from_city_id == city_id
                else connection.from_city_id
            )
            if other_id not in neighbor_ids:
                neighbor_ids.append(other_id)
        return tuple(self.cities[neighbor_id] for neighbor_id in neighbor_ids)

    def is_reachable(self, start_city_id: str, target_city_id: str) -> bool:
        self.city(start_city_id)
        self.city(target_city_id)
        visited = {start_city_id}
        queue = [start_city_id]
        while queue:
            current = queue.pop(0)
            if current == target_city_id:
                return True
            for neighbor in self.neighbors(current):
                if neighbor.city_id not in visited:
                    visited.add(neighbor.city_id)
                    queue.append(neighbor.city_id)
        return False


@dataclass(frozen=True, slots=True)
class FactionDefinition:
    faction_id: str
    name: str
    color: tuple[int, int, int]


@dataclass(frozen=True, slots=True)
class InitialFactionState:
    faction_id: str
    gold: int
    rice: int


@dataclass(frozen=True, slots=True)
class InitialCityState:
    city_id: str
    faction_id: str
    troops: int


@dataclass(frozen=True, slots=True)
class ScenarioDefinition:
    scenario_id: str
    name: str
    map_id: str
    factions: Mapping[str, FactionDefinition]
    initial_factions: Mapping[str, InitialFactionState]
    initial_cities: Mapping[str, InitialCityState]


@dataclass(slots=True)
class CityState:
    city_id: str
    faction_id: str
    troops: int
    domestic_action_used: bool = False


@dataclass(slots=True)
class FactionState:
    faction_id: str
    gold: int
    rice: int


@dataclass(frozen=True, slots=True)
class DomesticCommandDefinition:
    command: DomesticCommand
    name: str
    gold_delta: int = 0
    rice_delta: int = 0
    troops_delta: int = 0


@dataclass(frozen=True, slots=True)
class StrategyActionResult:
    success: bool
    message: str
    command: Optional[DomesticCommand] = None
    invasion_preparation: Optional["InvasionPreparation"] = None
    battle_started: bool = False
    battle_result: Optional["InvasionBattleResult"] = None


@dataclass(frozen=True, slots=True)
class InvasionPreparation:
    """Immutable snapshot passed to the future invasion/battle phase."""

    source_city_id: str
    target_city_id: str
    attacker_faction_id: str
    defender_faction_id: str
    attacking_troops: int
    defending_troops: int
    route_type: RouteType


class InvasionWinner(str, Enum):
    ATTACKER = "attacker"
    DEFENDER = "defender"


@dataclass(frozen=True, slots=True)
class InvasionBattleResult:
    """Completed battle result used to update strategic city state once."""

    preparation: InvasionPreparation
    winner: InvasionWinner
    attacker_survivors: int
    defender_survivors: int
    completed: bool = True


DOMESTIC_COMMANDS: Mapping[DomesticCommand, DomesticCommandDefinition] = MappingProxyType(
    {
        DomesticCommand.AGRICULTURE: DomesticCommandDefinition(
            DomesticCommand.AGRICULTURE,
            "農業",
            rice_delta=AGRICULTURE_RICE_GAIN,
        ),
        DomesticCommand.COMMERCE: DomesticCommandDefinition(
            DomesticCommand.COMMERCE,
            "商業",
            gold_delta=COMMERCE_GOLD_GAIN,
        ),
        DomesticCommand.RECRUIT: DomesticCommandDefinition(
            DomesticCommand.RECRUIT,
            "徴兵",
            gold_delta=-RECRUIT_GOLD_COST,
            rice_delta=-RECRUIT_RICE_COST,
            troops_delta=RECRUIT_TROOPS_GAIN,
        ),
    }
)


@dataclass(slots=True)
class StrategicGameState:
    """Mutable campaign state created from immutable map/scenario data."""

    map_definition: MapDefinition
    scenario_definition: ScenarioDefinition
    factions: Mapping[str, FactionDefinition]
    faction_states: dict[str, FactionState]
    cities: dict[str, CityState]
    faction_order: tuple[str, ...]
    current_faction_id: str
    round_number: int = 1
    player_faction_id: Optional[str] = None
    active_invasion: Optional[InvasionPreparation] = None

    @classmethod
    def from_definitions(
        cls,
        map_definition: MapDefinition,
        scenario_definition: ScenarioDefinition,
    ) -> "StrategicGameState":
        if map_definition.map_id != scenario_definition.map_id:
            raise StrategyDataError(
                f"scenario {scenario_definition.scenario_id!r} targets map "
                f"{scenario_definition.map_id!r}, not {map_definition.map_id!r}"
            )
        cities = {
            city_id: CityState(
                city_id=initial.city_id,
                faction_id=initial.faction_id,
                troops=initial.troops,
            )
            for city_id, initial in scenario_definition.initial_cities.items()
        }
        faction_states = {
            faction_id: FactionState(
                faction_id=initial.faction_id,
                gold=initial.gold,
                rice=initial.rice,
            )
            for faction_id, initial in scenario_definition.initial_factions.items()
        }
        faction_order = tuple(scenario_definition.factions)
        return cls(
            map_definition=map_definition,
            scenario_definition=scenario_definition,
            factions=scenario_definition.factions,
            faction_states=faction_states,
            cities=cities,
            faction_order=faction_order,
            current_faction_id=faction_order[0],
        )

    @property
    def scenario_id(self) -> str:
        return self.scenario_definition.scenario_id

    @property
    def current_faction(self) -> FactionDefinition:
        return self.factions[self.current_faction_id]

    @property
    def player_faction(self) -> Optional[FactionDefinition]:
        if self.player_faction_id is None:
            return None
        return self.factions[self.player_faction_id]

    def faction_state(self, faction_id: str) -> FactionState:
        if faction_id not in self.faction_states:
            raise StrategyDataError(f"unknown faction {faction_id!r}")
        return self.faction_states[faction_id]

    def select_player_faction(self, faction_id: str) -> StrategyActionResult:
        if self.active_invasion is not None:
            return StrategyActionResult(False, "侵攻戦闘中は操作勢力を変更できません。")
        if faction_id not in self.factions:
            return StrategyActionResult(False, f"不明な勢力です：{faction_id}")
        self.player_faction_id = faction_id
        self.current_faction_id = faction_id
        self.round_number = 1
        for city in self.cities.values():
            city.domestic_action_used = False
        return StrategyActionResult(True, f"{self.factions[faction_id].name}を操作勢力に選択しました。")

    def city_state(self, city_id: str) -> CityState:
        self.map_definition.city(city_id)
        try:
            return self.cities[city_id]
        except KeyError as exc:
            raise StrategyDataError(f"scenario has no state for city {city_id!r}") from exc

    def owner(self, city_id: str) -> FactionDefinition:
        state = self.city_state(city_id)
        try:
            return self.factions[state.faction_id]
        except KeyError as exc:
            raise StrategyDataError(
                f"city {city_id!r} has unknown faction {state.faction_id!r}"
            ) from exc

    def cities_for_faction(self, faction_id: str) -> tuple[CityState, ...]:
        if faction_id not in self.factions:
            raise StrategyDataError(f"unknown faction {faction_id!r}")
        return tuple(
            self.cities[city_id]
            for city_id in sorted(self.cities)
            if self.cities[city_id].faction_id == faction_id
        )

    def faction_city_ids(self, faction_id: str) -> tuple[str, ...]:
        return tuple(city.city_id for city in self.cities_for_faction(faction_id))

    def is_faction_defeated(self, faction_id: str) -> bool:
        return not self.cities_for_faction(faction_id)

    def city_domestic_action_available(self, city_id: str) -> bool:
        city = self.city_state(city_id)
        return (
            self.active_invasion is None
            and self.player_faction_id is not None
            and self.current_faction_id == self.player_faction_id
            and city.faction_id == self.player_faction_id
            and not city.domestic_action_used
        )

    def city_action_available(self, city_id: str) -> bool:
        """Return whether the shared once-per-turn city action is available."""

        return self.city_domestic_action_available(city_id)

    def can_execute_domestic_command(
        self,
        city_id: str,
        command: DomesticCommand | str,
    ) -> bool:
        try:
            command = DomesticCommand(command)
        except ValueError:
            return False
        player_faction_id = self.player_faction_id
        if player_faction_id is None:
            return False
        if not self.city_domestic_action_available(city_id):
            return False
        definition = DOMESTIC_COMMANDS[command]
        resources = self.faction_state(player_faction_id)
        city = self.city_state(city_id)
        return (
            resources.gold + definition.gold_delta >= 0
            and resources.rice + definition.rice_delta >= 0
            and city.troops + definition.troops_delta >= 0
        )

    def execute_domestic_command(
        self,
        city_id: str,
        command: DomesticCommand | str,
    ) -> StrategyActionResult:
        try:
            command = DomesticCommand(command)
        except ValueError:
            return StrategyActionResult(False, f"不明な内政コマンドです：{command}")
        definition = DOMESTIC_COMMANDS[command]
        city = self.city_state(city_id)
        if self.active_invasion is not None:
            return StrategyActionResult(False, "侵攻戦闘中は戦略操作できません。", command)
        if self.player_faction_id is None:
            return StrategyActionResult(False, "先に操作勢力を選択してください。", command)
        if self.current_faction_id != self.player_faction_id:
            return StrategyActionResult(False, "現在は自勢力のターンではありません。", command)
        if city.faction_id != self.player_faction_id:
            return StrategyActionResult(False, "他勢力の都市では内政できません。", command)
        if city.domestic_action_used:
            return StrategyActionResult(False, "この都市は今ターンの内政済みです。", command)

        resources = self.faction_state(self.player_faction_id)
        if resources.gold + definition.gold_delta < 0:
            return StrategyActionResult(False, "金が不足しています。", command)
        if resources.rice + definition.rice_delta < 0:
            return StrategyActionResult(False, "米が不足しています。", command)
        if city.troops + definition.troops_delta < 0:
            return StrategyActionResult(False, "兵士数が不正になるため実行できません。", command)

        resources.gold += definition.gold_delta
        resources.rice += definition.rice_delta
        city.troops += definition.troops_delta
        city.domestic_action_used = True
        faction_name = self.factions[self.player_faction_id].name
        city_name = self.map_definition.city(city_id).name
        details: list[str] = []
        if definition.gold_delta:
            details.append(f"金{definition.gold_delta:+d}")
        if definition.rice_delta:
            details.append(f"米{definition.rice_delta:+d}")
        if definition.troops_delta:
            details.append(f"兵士{definition.troops_delta:+d}")
        return StrategyActionResult(
            True,
            f"{city_name}で{definition.name}を実行（{', '.join(details)}）。{faction_name}",
            command,
        )

    def move_troops(
        self,
        source_city_id: str,
        target_city_id: str,
        troops: int,
    ) -> StrategyActionResult:
        """Move troops between adjacent cities owned by the player."""

        try:
            source = self.city_state(source_city_id)
            target = self.city_state(target_city_id)
        except StrategyDataError as exc:
            return StrategyActionResult(False, str(exc))
        player_faction_id = self.player_faction_id
        if player_faction_id is None:
            return StrategyActionResult(False, "先に操作勢力を選択してください。")
        if self.active_invasion is not None:
            return StrategyActionResult(False, "侵攻戦闘中は戦略操作できません。")
        if self.current_faction_id != player_faction_id:
            return StrategyActionResult(False, "現在は自勢力のターンではありません。")
        if source.faction_id != player_faction_id or target.faction_id != player_faction_id:
            return StrategyActionResult(False, "自勢力の都市間でのみ兵士を移動できます。")
        if self._connection_between(source_city_id, target_city_id) is None:
            return StrategyActionResult(False, "隣接する都市へしか兵士を移動できません。")
        if source.domestic_action_used:
            return StrategyActionResult(False, "移動元の都市は今ターンの行動済みです。")
        if isinstance(troops, bool) or not isinstance(troops, int) or troops < 1:
            return StrategyActionResult(False, "移動兵数は1以上で指定してください。")
        if source.troops - troops < 1:
            return StrategyActionResult(False, "移動元には最低1人を残してください。")

        source.troops -= troops
        target.troops += troops
        source.domestic_action_used = True
        source_name = self.map_definition.city(source_city_id).name
        target_name = self.map_definition.city(target_city_id).name
        return StrategyActionResult(
            True,
            f"{source_name}から{target_name}へ兵士{troops}人を移動しました。",
        )

    def can_move_troops(
        self,
        source_city_id: str,
        target_city_id: str,
        troops: int,
    ) -> bool:
        """Check troop movement without changing the state."""

        try:
            source = self.city_state(source_city_id)
            target = self.city_state(target_city_id)
        except StrategyDataError:
            return False
        player_faction_id = self.player_faction_id
        return bool(
            self.active_invasion is None
            and player_faction_id is not None
            and self.current_faction_id == player_faction_id
            and source.faction_id == player_faction_id
            and target.faction_id == player_faction_id
            and self._connection_between(source_city_id, target_city_id) is not None
            and not source.domestic_action_used
            and isinstance(troops, int)
            and not isinstance(troops, bool)
            and troops >= 1
            and source.troops - troops >= 1
        )

    def invasion_target_ids(self, source_city_id: str) -> tuple[str, ...]:
        """Return adjacent enemy cities that can currently be prepared for invasion."""

        try:
            source = self.city_state(source_city_id)
        except StrategyDataError:
            return ()
        player_faction_id = self.player_faction_id
        if (
            player_faction_id is None
            or self.current_faction_id != player_faction_id
            or self.active_invasion is not None
            or source.faction_id != player_faction_id
            or source.domestic_action_used
            or source.troops < 2
        ):
            return ()
        return tuple(
            city.city_id
            for city in self.map_definition.neighbors(source_city_id)
            if self.city_state(city.city_id).faction_id != player_faction_id
        )

    def can_prepare_invasion(
        self,
        source_city_id: str,
        target_city_id: str,
        attacking_troops: int,
    ) -> bool:
        """Check an invasion preview without consuming an action or troops."""

        try:
            source = self.city_state(source_city_id)
            target = self.city_state(target_city_id)
        except StrategyDataError:
            return False
        player_faction_id = self.player_faction_id
        return bool(
            self.active_invasion is None
            and player_faction_id is not None
            and self.current_faction_id == player_faction_id
            and source.faction_id == player_faction_id
            and target.faction_id != player_faction_id
            and target_city_id in self.invasion_target_ids(source_city_id)
            and isinstance(attacking_troops, int)
            and not isinstance(attacking_troops, bool)
            and attacking_troops >= 1
            and source.troops - attacking_troops >= 1
        )

    def prepare_invasion(
        self,
        source_city_id: str,
        target_city_id: str,
        attacking_troops: int,
    ) -> StrategyActionResult:
        """Create an invasion snapshot; this does not start combat or mutate state."""

        try:
            source = self.city_state(source_city_id)
            target = self.city_state(target_city_id)
        except StrategyDataError as exc:
            return StrategyActionResult(False, str(exc))
        if self.player_faction_id is None:
            return StrategyActionResult(False, "先に操作勢力を選択してください。")
        if self.active_invasion is not None:
            return StrategyActionResult(False, "侵攻戦闘中は戦略操作できません。")
        if not self.can_prepare_invasion(source_city_id, target_city_id, attacking_troops):
            if self.current_faction_id != self.player_faction_id:
                message = "現在は自勢力のターンではありません。"
            elif source.faction_id != self.player_faction_id:
                message = "侵攻元は自勢力の都市を指定してください。"
            elif target.faction_id == self.player_faction_id:
                message = "侵攻先は敵勢力の都市を指定してください。"
            elif self._connection_between(source_city_id, target_city_id) is None:
                message = "侵攻先は隣接する敵都市に限られます。"
            elif source.domestic_action_used:
                message = "侵攻元の都市は今ターンの行動済みです。"
            elif isinstance(attacking_troops, bool) or not isinstance(attacking_troops, int) or attacking_troops < 1:
                message = "出陣兵数は1以上で指定してください。"
            else:
                message = "出陣兵数が多すぎます。侵攻元には最低1人を残してください。"
            return StrategyActionResult(False, message)

        connection = self._connection_between(source_city_id, target_city_id)
        assert connection is not None
        preparation = InvasionPreparation(
            source_city_id=source_city_id,
            target_city_id=target_city_id,
            attacker_faction_id=source.faction_id,
            defender_faction_id=target.faction_id,
            attacking_troops=attacking_troops,
            defending_troops=target.troops,
            route_type=connection.route_type,
        )
        source_name = self.map_definition.city(source_city_id).name
        target_name = self.map_definition.city(target_city_id).name
        route_name = "陸路" if connection.route_type is RouteType.LAND else "海路"
        return StrategyActionResult(
            True,
            f"{source_name}から{target_name}への侵攻準備を確認しました（{route_name}・{attacking_troops}人）。戦闘は開始していません。",
            invasion_preparation=preparation,
        )

    def begin_invasion(self, preparation: InvasionPreparation) -> StrategyActionResult:
        """Lock the strategic state for one prepared invasion."""

        if self.active_invasion is not None:
            return StrategyActionResult(False, "すでに侵攻戦闘中です。")
        if not self.validate_invasion_preparation(preparation):
            return StrategyActionResult(False, "侵攻準備が現在の戦略状態と一致しません。")

        self.active_invasion = preparation
        if preparation.defending_troops == 0:
            result = InvasionBattleResult(
                preparation=preparation,
                winner=InvasionWinner.ATTACKER,
                attacker_survivors=preparation.attacking_troops,
                defender_survivors=0,
            )
            return self.apply_invasion_result(result)
        return StrategyActionResult(
            True,
            "侵攻戦闘を開始します。戦闘終了まで戦略操作は停止します。",
            invasion_preparation=preparation,
            battle_started=True,
        )

    def apply_invasion_result(self, result: InvasionBattleResult) -> StrategyActionResult:
        """Apply one completed invasion result atomically and only once."""

        if not isinstance(result, InvasionBattleResult):
            return StrategyActionResult(False, "不正な侵攻結果です。")
        preparation = result.preparation
        if self.active_invasion != preparation:
            return StrategyActionResult(False, "この侵攻戦闘は確定済み、または開始されていません。")
        if not result.completed or not self.validate_invasion_preparation(preparation):
            return StrategyActionResult(False, "侵攻結果を適用できる状態ではありません。")
        try:
            winner = InvasionWinner(result.winner)
        except ValueError:
            return StrategyActionResult(False, "不正な侵攻勝者です。")
        if (
            isinstance(result.attacker_survivors, bool)
            or not isinstance(result.attacker_survivors, int)
            or isinstance(result.defender_survivors, bool)
            or not isinstance(result.defender_survivors, int)
            or result.attacker_survivors < 0
            or result.defender_survivors < 0
            or result.attacker_survivors > preparation.attacking_troops
            or result.defender_survivors > preparation.defending_troops
        ):
            return StrategyActionResult(False, "侵攻結果の兵数が不正です。")
        if winner is InvasionWinner.ATTACKER and (
            result.attacker_survivors < 1 or result.defender_survivors != 0
        ):
            return StrategyActionResult(False, "攻撃側勝利の兵数が不正です。")
        if winner is InvasionWinner.DEFENDER and result.defender_survivors < 1:
            return StrategyActionResult(False, "防御側勝利の兵数が不正です。")

        source = self.city_state(preparation.source_city_id)
        target = self.city_state(preparation.target_city_id)
        source_troops_before = source.troops
        if winner is InvasionWinner.ATTACKER:
            new_source_troops = source_troops_before - preparation.attacking_troops
            new_target_troops = result.attacker_survivors
            new_target_faction = preparation.attacker_faction_id
            target_action_used = True
            message = (
                f"侵攻成功：{self.map_definition.city(preparation.target_city_id).name}を占領しました。"
                f"攻撃側残存兵数：{result.attacker_survivors}"
            )
        else:
            new_source_troops = (
                source_troops_before
                - preparation.attacking_troops
                + result.attacker_survivors
            )
            new_target_troops = result.defender_survivors
            new_target_faction = preparation.defender_faction_id
            target_action_used = target.domestic_action_used
            message = (
                f"侵攻失敗：{self.map_definition.city(preparation.target_city_id).name}は防衛されました。"
                f"攻撃側帰還兵：{result.attacker_survivors}、防御側残存兵数：{result.defender_survivors}"
            )
        if new_source_troops < 1 or new_target_troops < 0:
            return StrategyActionResult(False, "侵攻結果により兵数が不正になります。")

        source.troops = new_source_troops
        source.domestic_action_used = True
        target.troops = new_target_troops
        target.faction_id = new_target_faction
        target.domestic_action_used = target_action_used
        self.active_invasion = None
        return StrategyActionResult(
            True,
            message,
            invasion_preparation=preparation,
            battle_result=result,
        )

    def cancel_invasion(self) -> StrategyActionResult:
        """Discard an unresolved battle lock without changing strategic state."""

        if self.active_invasion is None:
            return StrategyActionResult(False, "進行中の侵攻戦闘はありません。")
        self.active_invasion = None
        return StrategyActionResult(True, "未確定の侵攻戦闘を破棄しました。都市状態は変更していません。")

    def validate_invasion_preparation(self, preparation: InvasionPreparation) -> bool:
        """Revalidate a snapshot immediately before a future invasion starts."""

        if not isinstance(preparation, InvasionPreparation):
            return False
        if (
            not isinstance(preparation.source_city_id, str)
            or not isinstance(preparation.target_city_id, str)
            or not isinstance(preparation.attacker_faction_id, str)
            or not isinstance(preparation.defender_faction_id, str)
            or not isinstance(preparation.attacking_troops, int)
            or isinstance(preparation.attacking_troops, bool)
            or preparation.attacking_troops < 1
            or not isinstance(preparation.defending_troops, int)
            or isinstance(preparation.defending_troops, bool)
            or preparation.defending_troops < 0
            or not isinstance(preparation.route_type, RouteType)
        ):
            return False
        try:
            source = self.city_state(preparation.source_city_id)
            target = self.city_state(preparation.target_city_id)
        except (AttributeError, StrategyDataError):
            return False
        connection = self._connection_between(preparation.source_city_id, preparation.target_city_id)
        player_faction_id = self.player_faction_id
        return bool(
            player_faction_id is not None
            and self.current_faction_id == player_faction_id
            and source.faction_id == preparation.attacker_faction_id == player_faction_id
            and target.faction_id == preparation.defender_faction_id
            and target.faction_id != player_faction_id
            and connection is not None
            and connection.route_type is preparation.route_type
            and source.troops - preparation.attacking_troops >= 1
            and target.troops == preparation.defending_troops
            and not source.domestic_action_used
        )

    def _connection_between(
        self,
        source_city_id: str,
        target_city_id: str,
    ) -> Optional[ConnectionDefinition]:
        for connection in self.map_definition.connections_for(source_city_id):
            if target_city_id in connection.city_ids:
                return connection
        return None

    def end_turn(self) -> StrategyActionResult:
        if self.active_invasion is not None:
            return StrategyActionResult(False, "侵攻戦闘中は戦略ターンを進められません。")
        current_index = self.faction_order.index(self.current_faction_id)
        next_index = (current_index + 1) % len(self.faction_order)
        if next_index == 0:
            self.round_number += 1
        self.current_faction_id = self.faction_order[next_index]
        for city in self.cities_for_faction(self.current_faction_id):
            city.domestic_action_used = False
        return StrategyActionResult(
            True,
            f"第{self.round_number}ラウンド：{self.current_faction.name}のターン開始。",
        )

    def advance_npc_turns(self) -> tuple[StrategyActionResult, ...]:
        """End non-player turns without actions; a future NPC hook fits here."""

        if self.player_faction_id is None or self.active_invasion is not None:
            return ()
        results: list[StrategyActionResult] = []
        while self.current_faction_id != self.player_faction_id:
            results.append(self.end_turn())
        return tuple(results)

    def neighbors(
        self,
        city_id: str,
        route_type: Optional[RouteType] = None,
    ) -> tuple[CityDefinition, ...]:
        return self.map_definition.neighbors(city_id, route_type)

    def are_adjacent(self, source_city_id: str, target_city_id: str) -> bool:
        """Return whether two cities have a direct map connection."""

        try:
            self.city_state(source_city_id)
            self.city_state(target_city_id)
        except StrategyDataError:
            return False
        return self._connection_between(source_city_id, target_city_id) is not None


def load_map(path: str | Path) -> MapDefinition:
    """Load and validate one geography definition from JSON."""

    source = Path(path)
    data = _read_json(source, "map")
    map_id = _required_string(data, "map_id", f"map {source}")
    name = _required_string(data, "name", f"map {map_id!r}")
    width = _required_positive_int(data, "width", f"map {map_id!r}")
    height = _required_positive_int(data, "height", f"map {map_id!r}")
    city_items = _required_list(data, "cities", f"map {map_id!r}")

    cities: dict[str, CityDefinition] = {}
    for index, raw_city in enumerate(city_items):
        context = f"map {map_id!r} city[{index}]"
        if not isinstance(raw_city, dict):
            raise StrategyDataError(f"{context}: must be an object")
        city_id = _required_string(raw_city, "city_id", context)
        if city_id in cities:
            raise StrategyDataError(f"map {map_id!r}: duplicate city_id {city_id!r}")
        city_name = _required_string(raw_city, "name", context)
        x = _required_coordinate(raw_city, "x", context, width)
        y = _required_coordinate(raw_city, "y", context, height)
        region = raw_city.get("region")
        if region is not None and not isinstance(region, str):
            raise StrategyDataError(f"{context}: region must be a string or null")
        cities[city_id] = CityDefinition(
            city_id=city_id,
            name=city_name,
            position=Position(x, y),
            region=region,
        )

    raw_connections = _required_list(data, "connections", f"map {map_id!r}")
    connections: list[ConnectionDefinition] = []
    seen_connections: set[tuple[str, str, RouteType]] = set()
    for index, raw_connection in enumerate(raw_connections):
        context = f"map {map_id!r} connection[{index}]"
        if not isinstance(raw_connection, dict):
            raise StrategyDataError(f"{context}: must be an object")
        from_id = _required_string(raw_connection, "from", context)
        to_id = _required_string(raw_connection, "to", context)
        if from_id not in cities or to_id not in cities:
            missing = from_id if from_id not in cities else to_id
            raise StrategyDataError(f"{context}: unknown city {missing!r}")
        if from_id == to_id:
            raise StrategyDataError(f"{context}: self-connection is not allowed")
        route_type = RouteType.parse(raw_connection.get("type"), context=context)
        key = (*sorted((from_id, to_id)), route_type)
        if key in seen_connections:
            raise StrategyDataError(
                f"{context}: duplicate connection between {from_id!r} and {to_id!r}"
            )
        seen_connections.add(key)
        connections.append(ConnectionDefinition(from_id, to_id, route_type))

    map_definition = MapDefinition(
        map_id=map_id,
        name=name,
        width=width,
        height=height,
        cities=MappingProxyType(cities),
        connections=tuple(connections),
    )
    _validate_map_reachability(map_definition)
    return map_definition


def load_scenario(path: str | Path, map_definition: MapDefinition) -> ScenarioDefinition:
    """Load scenario ownership/faction data for a previously loaded map."""

    source = Path(path)
    data = _read_json(source, "scenario")
    scenario_id = _required_string(data, "scenario_id", f"scenario {source}")
    name = _required_string(data, "name", f"scenario {scenario_id!r}")
    map_id = _required_string(data, "map_id", f"scenario {scenario_id!r}")
    if map_id != map_definition.map_id:
        raise StrategyDataError(
            f"scenario {scenario_id!r}: map_id {map_id!r} does not match "
            f"loaded map {map_definition.map_id!r}"
        )

    factions: dict[str, FactionDefinition] = {}
    initial_factions: dict[str, InitialFactionState] = {}
    for index, raw_faction in enumerate(_required_list(data, "factions", f"scenario {scenario_id!r}")):
        context = f"scenario {scenario_id!r} faction[{index}]"
        if not isinstance(raw_faction, dict):
            raise StrategyDataError(f"{context}: must be an object")
        faction_id = _required_string(raw_faction, "faction_id", context)
        if faction_id in factions:
            raise StrategyDataError(f"scenario {scenario_id!r}: duplicate faction_id {faction_id!r}")
        faction_name = _required_string(raw_faction, "name", context)
        raw_color = raw_faction.get("color")
        if (
            not isinstance(raw_color, list)
            or len(raw_color) != 3
            or any(isinstance(channel, bool) or not isinstance(channel, int) for channel in raw_color)
            or any(channel < 0 or channel > 255 for channel in raw_color)
        ):
            raise StrategyDataError(f"{context}: color must be three integers from 0 to 255")
        factions[faction_id] = FactionDefinition(
            faction_id=faction_id,
            name=faction_name,
            color=tuple(raw_color),
        )
        gold = _required_nonnegative_int(raw_faction, "gold", context)
        rice = _required_nonnegative_int(raw_faction, "rice", context)
        initial_factions[faction_id] = InitialFactionState(faction_id, gold, rice)

    if not factions:
        raise StrategyDataError(f"scenario {scenario_id!r}: at least one faction is required")

    initial_cities: dict[str, InitialCityState] = {}
    for index, raw_city in enumerate(_required_list(data, "cities", f"scenario {scenario_id!r}")):
        context = f"scenario {scenario_id!r} city[{index}]"
        if not isinstance(raw_city, dict):
            raise StrategyDataError(f"{context}: must be an object")
        city_id = _required_string(raw_city, "city_id", context)
        if city_id in initial_cities:
            raise StrategyDataError(f"scenario {scenario_id!r}: duplicate city_id {city_id!r}")
        if city_id not in map_definition.cities:
            raise StrategyDataError(f"{context}: unknown city {city_id!r}")
        faction_id = _required_string(raw_city, "faction_id", context)
        if faction_id not in factions:
            raise StrategyDataError(f"{context}: unknown faction_id {faction_id!r}")
        troops = raw_city.get("troops")
        if isinstance(troops, bool) or not isinstance(troops, int) or troops < 0:
            raise StrategyDataError(f"{context}: troops must be a non-negative integer")
        initial_cities[city_id] = InitialCityState(city_id, faction_id, troops)

    missing = sorted(set(map_definition.cities) - set(initial_cities))
    extra = sorted(set(initial_cities) - set(map_definition.cities))
    if missing:
        raise StrategyDataError(
            f"scenario {scenario_id!r}: missing initial state for cities {missing}"
        )
    if extra:
        raise StrategyDataError(
            f"scenario {scenario_id!r}: initial state has unknown cities {extra}"
        )

    return ScenarioDefinition(
        scenario_id=scenario_id,
        name=name,
        map_id=map_id,
        factions=MappingProxyType(factions),
        initial_factions=MappingProxyType(initial_factions),
        initial_cities=MappingProxyType(initial_cities),
    )


class StrategyCatalog:
    """Small filesystem-backed catalog for maps and scenarios."""

    def __init__(self, data_root: str | Path | None = None) -> None:
        self.data_root = Path(data_root) if data_root is not None else default_data_root()
        self.maps_dir = self.data_root / "maps"
        self.scenarios_dir = self.data_root / "scenarios"

    def map_ids(self) -> tuple[str, ...]:
        return tuple(path.stem for path in sorted(self.maps_dir.glob("*.json")))

    def scenario_ids(self) -> tuple[str, ...]:
        return tuple(path.stem for path in sorted(self.scenarios_dir.glob("*.json")))

    def map_path(self, map_id: str) -> Path:
        path = self.maps_dir / f"{map_id}.json"
        if not path.is_file():
            raise StrategyDataError(f"map definition not found: {map_id!r}")
        return path

    def scenario_path(self, scenario_id: str) -> Path:
        path = self.scenarios_dir / f"{scenario_id}.json"
        if not path.is_file():
            raise StrategyDataError(f"scenario definition not found: {scenario_id!r}")
        return path

    def load_map(self, map_id: str) -> MapDefinition:
        return load_map(self.map_path(map_id))

    def load_scenario(self, scenario_id: str) -> ScenarioDefinition:
        source = self.scenario_path(scenario_id)
        data = _read_json(source, "scenario")
        map_id = _required_string(data, "map_id", f"scenario {source}")
        return load_scenario(source, self.load_map(map_id))

    def load_state(self, scenario_id: str) -> StrategicGameState:
        scenario = self.load_scenario(scenario_id)
        return StrategicGameState.from_definitions(self.load_map(scenario.map_id), scenario)

    def scenarios_for_map(self, map_id: str) -> tuple[ScenarioDefinition, ...]:
        scenarios = []
        for scenario_id in self.scenario_ids():
            scenario = self.load_scenario(scenario_id)
            if scenario.map_id == map_id:
                scenarios.append(scenario)
        return tuple(scenarios)


def default_data_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _read_json(path: Path, kind: str) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as stream:
            data = json.load(stream)
    except FileNotFoundError as exc:
        raise StrategyDataError(f"{kind} definition not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise StrategyDataError(f"{kind} {path}: invalid JSON at line {exc.lineno}") from exc
    if not isinstance(data, dict):
        raise StrategyDataError(f"{kind} {path}: top-level value must be an object")
    return data


def _required_string(data: Mapping[str, Any], key: str, context: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise StrategyDataError(f"{context}: {key} must be a non-empty string")
    return value


def _required_positive_int(data: Mapping[str, Any], key: str, context: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise StrategyDataError(f"{context}: {key} must be a positive integer")
    return value


def _required_nonnegative_int(data: Mapping[str, Any], key: str, context: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise StrategyDataError(f"{context}: {key} must be a non-negative integer")
    return value


def _required_list(data: Mapping[str, Any], key: str, context: str) -> list[Any]:
    value = data.get(key)
    if not isinstance(value, list):
        raise StrategyDataError(f"{context}: {key} must be a list")
    return value


def _required_coordinate(
    data: Mapping[str, Any],
    key: str,
    context: str,
    limit: int,
) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise StrategyDataError(f"{context}: {key} must be numeric")
    if isinstance(value, float) and not isfinite(value):
        raise StrategyDataError(f"{context}: {key} must be finite")
    if int(value) != value or value < 0 or value >= limit:
        raise StrategyDataError(f"{context}: {key} must be an integer in [0, {limit})")
    return int(value)


def _validate_map_reachability(map_definition: MapDefinition) -> None:
    if not map_definition.cities:
        raise StrategyDataError(f"map {map_definition.map_id!r}: at least one city is required")
    start = next(iter(map_definition.cities))
    visited = {start}
    queue = [start]
    while queue:
        current = queue.pop(0)
        for neighbor in map_definition.neighbors(current):
            if neighbor.city_id not in visited:
                visited.add(neighbor.city_id)
                queue.append(neighbor.city_id)
    unreachable = sorted(set(map_definition.cities) - visited)
    if unreachable:
        raise StrategyDataError(
            f"map {map_definition.map_id!r}: unreachable cities {unreachable}"
        )
