"""Small deterministic enemy controller for the battle prototype.

The controller only decides what to do.  All state changes go through the
BattleEngine public actions, so the same movement, targeting, events, and
transaction guards are used by human and computer-controlled units.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from .engine import ActionResult, BattleEngine
from .models import Faction, Position, Unit


class AIActionKind(str, Enum):
    """The initial AI action vocabulary."""

    ATTACK = "attack"
    MOVE = "move"
    END = "end"


@dataclass(frozen=True, slots=True)
class AIAction:
    """A planned action, without changing the battle state."""

    kind: AIActionKind
    unit_id: str
    target_id: Optional[str] = None
    destination: Optional[Position] = None


class SimpleEnemyAI:
    """Deterministic, one-action-at-a-time enemy controller.

    The controller deliberately does not inspect character names or use
    skills.  Skill selection can be added later by extending ``choose_action``
    while retaining ``execute_action`` and the engine's public API.
    """

    def choose_action(
        self,
        engine: BattleEngine,
        unit_id: Optional[str] = None,
    ) -> Optional[AIAction]:
        """Plan one legal-looking action for the next active enemy unit.

        This method is read-only.  The engine performs the final validation
        when ``execute_action`` applies the plan.
        """

        if engine.game_over or engine.turn_side is not Faction.ENEMY:
            return None

        unit = self._select_unit(engine, unit_id)
        if unit is None:
            return None

        targets = engine.get_attackable_targets(unit.unit_id)
        if targets:
            target = min(
                targets,
                key=lambda candidate: (
                    candidate.troops,
                    candidate.unit_id,
                    candidate.position.y,
                    candidate.position.x,
                ),
            )
            return AIAction(
                kind=AIActionKind.ATTACK,
                unit_id=unit.unit_id,
                target_id=target.unit_id,
            )

        opponents = engine.units_for_side(Faction.ALLY, alive_only=True)
        reachable = engine.get_reachable_positions(unit.unit_id)
        if opponents and reachable:
            destination = min(
                reachable,
                key=lambda position: (
                    self._nearest_distance(position, opponents),
                    position.y,
                    position.x,
                ),
            )
            return AIAction(
                kind=AIActionKind.MOVE,
                unit_id=unit.unit_id,
                destination=destination,
            )

        return AIAction(kind=AIActionKind.END, unit_id=unit.unit_id)

    def execute_action(self, engine: BattleEngine, action: AIAction) -> ActionResult:
        """Apply a plan through the engine's public action methods."""

        if action.kind is AIActionKind.ATTACK:
            if action.target_id is None:
                return ActionResult(False, "AI attack plan has no target.")
            return engine.attack_unit(action.unit_id, action.target_id)
        if action.kind is AIActionKind.MOVE:
            if action.destination is None:
                return ActionResult(False, "AI move plan has no destination.")
            return engine.move_unit(action.unit_id, action.destination)
        return engine.end_unit_action(action.unit_id)

    def step(self, engine: BattleEngine) -> Optional[ActionResult]:
        """Perform at most one AI action and never loop on a failed plan.

        A failed plan is converted into an engine-mediated end action when
        possible.  This prevents a cancelled or stale plan from causing an
        infinite enemy turn.
        """

        action = self.choose_action(engine)
        if action is None:
            return None
        result = self.execute_action(engine, action)
        if result.success or engine.game_over:
            return result
        fallback = engine.end_unit_action(action.unit_id)
        return fallback if fallback.success else result

    def run_turn(self, engine: BattleEngine, *, max_steps: Optional[int] = None) -> list[ActionResult]:
        """Resolve an enemy turn synchronously, primarily for headless tests."""

        active_enemy_count = len(engine.units_for_side(Faction.ENEMY, alive_only=True))
        step_limit = max_steps if max_steps is not None else max(1, active_enemy_count * 3)
        results: list[ActionResult] = []
        for _ in range(step_limit):
            result = self.step(engine)
            if result is None:
                break
            results.append(result)
            if engine.turn_side is not Faction.ENEMY or engine.game_over:
                break
        return results

    @staticmethod
    def _select_unit(engine: BattleEngine, unit_id: Optional[str]) -> Optional[Unit]:
        if unit_id is not None:
            unit = engine.get_unit(unit_id)
            if (
                unit.faction is Faction.ENEMY
                and not unit.defeated
                and not unit.action_ended
            ):
                return unit
            return None
        active_units = [
            unit
            for unit in engine.units_for_side(Faction.ENEMY, alive_only=True)
            if not unit.action_ended
        ]
        return min(active_units, key=lambda unit: unit.unit_id) if active_units else None

    @staticmethod
    def _nearest_distance(position: Position, opponents: list[Unit]) -> int:
        return min(position.manhattan_distance(unit.position) for unit in opponents)
