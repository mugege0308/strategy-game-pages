"""Presentation-only text, labels, and Japanese font discovery."""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable, Optional

from .models import Faction, Unit


_CHARACTER_MARKERS = {
    "セイバー": "セ",
    "伊達政宗": "政",
    "東堂葵": "東",
    "上杉謙信": "謙",
    "趙雲": "雲",
}

_CHARACTER_NAMES = {
    "Saber": "セイバー",
    "Date Masamune": "伊達政宗",
    "Toudo Aoi": "東堂葵",
    "Uesugi Kenshin": "上杉謙信",
    "Zhao Yun": "趙雲",
}

_STATIC_MESSAGES = {
    "Ally turn started.": "味方ターン開始",
    "Enemy turn started.": "敵ターン開始",
    "Victory! All enemy units were defeated.": "勝利：敵軍を全滅させました。",
    "Defeat. All ally units were defeated.": "敗北：味方軍が全滅しました。",
    "The battle is over.": "戦闘は終了しています。",
    "That unit is not on the active side.": "そのユニットは現在の陣営ではありません。",
    "That unit has been defeated.": "そのユニットは撃破されています。",
    "That unit has already ended its action.": "そのユニットは行動終了済みです。",
    "This unit already moved this turn.": "このユニットは今ターンに移動済みです。",
    "Destination is outside the map.": "移動先がマップ外です。",
    "Choose a different destination.": "別の移動先を選択してください。",
    "The destination is occupied.": "移動先に別のユニットがいます。",
    "That destination is unreachable.": "そのマスには移動できません。",
    "Movement was cancelled by an event.": "イベントにより移動がキャンセルされました。",
    "This unit already attacked this turn.": "このユニットは今ターンに攻撃済みです。",
    "You cannot attack an allied unit.": "味方ユニットは攻撃できません。",
    "That unit has already been defeated.": "そのユニットはすでに撃破されています。",
    "The target is outside attack range.": "対象が射程外です。",
    "Choose an attack direction.": "攻撃方向を選択してください。",
    "There are no enemies in that direction.": "その方向に敵はいません。",
    "Choose two different targets.": "異なる2体を選択してください。",
    "Both targets must be alive and within swap range.": "2体とも生存中で交換範囲内である必要があります。",
    "Choose a target.": "対象を選択してください。",
    "Attack was cancelled by an event.": "イベントにより攻撃がキャンセルされました。",
    "Attack targets became invalid after the event.": "イベント後に攻撃対象が無効になりました。",
    "The skill is no longer available.": "そのスキルは使用できません。",
    "There are no valid targets.": "有効な対象がありません。",
    "Position swap was cancelled by an event.": "イベントにより位置交換がキャンセルされました。",
    "Position swap targets became invalid after the event.": "イベント後に位置交換対象が無効になりました。",
    "Position swap produced an invalid battle state.": "位置交換後の戦闘状態が不正です。",
    "Another action is already in progress.": "別の行動を処理中です。",
    "Action produced an invalid battle state.": "行動後の戦闘状態が不正です。",
    "AI attack plan has no target.": "AIの攻撃対象がありません。",
    "AI move plan has no destination.": "AIの移動先がありません。",
}

_FONT_FILENAMES = (
    "meiryo.ttc",
    "meiryob.ttc",
    "YuGothM.ttc",
    "YuGothB.ttc",
    "msgothic.ttc",
    "NotoSansJP-Regular.otf",
    "NotoSansCJK-Regular.ttc",
)

_BUNDLED_FONT_FILENAMES = (
    "NotoSansJP-VF.ttf",
)


def bundled_japanese_font_candidates() -> tuple[Path, ...]:
    """Return Japanese fonts shipped with the game before system fonts.

    The browser build cannot rely on the host operating system's fonts. Keep
    this path relative to the package so Pygbag includes it with ``battle_game``
    and the Windows build can use the same asset without changing its rules.
    """

    font_dir = Path(__file__).resolve().parent / "assets" / "fonts"
    return tuple(font_dir / filename for filename in _BUNDLED_FONT_FILENAMES)


def japanese_font_candidates() -> tuple[Path, ...]:
    """Return font candidates with browser-specific priority.

    Windows keeps the existing system-font priority. Pygbag sets the runtime
    platform to ``emscripten`` (or ``wasi``), where the bundled font must be
    preferred because the user's operating-system fonts are unavailable.
    """

    bundled = list(bundled_japanese_font_candidates())
    system: list[Path] = []
    windows_dir = Path(os.environ.get("WINDIR", "C:/Windows"))
    system.extend(windows_dir / "Fonts" / filename for filename in _FONT_FILENAMES)
    system.extend(
        Path(path) / filename
        for path in (
            "/usr/share/fonts/opentype/noto",
            "/usr/share/fonts/truetype/noto",
            "/usr/local/share/fonts",
        )
        for filename in _FONT_FILENAMES
    )
    if sys.platform in ("emscripten", "wasi"):
        return tuple(bundled + system)
    return tuple(system + bundled)


def find_japanese_font(
    pygame_module: Any = None,
    *,
    candidates: Optional[Iterable[Path | str]] = None,
) -> Optional[str]:
    """Find a usable installed Japanese font, returning ``None`` safely.

    When Pygame is supplied, the font is opened and rendered once before it is
    accepted.  No font is copied into the project.
    """

    candidate_paths = japanese_font_candidates() if candidates is None else candidates
    for candidate in candidate_paths:
        path = Path(candidate)
        if not path.is_file():
            continue
        if pygame_module is None:
            return str(path)
        try:
            font = pygame_module.font.Font(str(path), 20)
            surface = font.render("日本語", True, (255, 255, 255))
            if surface.get_width() > 0 and surface.get_height() > 0:
                return str(path)
        except (OSError, RuntimeError, TypeError):
            continue
    return None


def load_font(pygame_module: Any, font_path: Optional[str], size: int) -> Any:
    """Load the selected font and fall back to Pygame's default font."""

    if font_path:
        try:
            return pygame_module.font.Font(font_path, size)
        except (OSError, RuntimeError, TypeError):
            pass
    try:
        return pygame_module.font.SysFont("sans", size)
    except (OSError, RuntimeError, TypeError):
        return pygame_module.font.Font(None, size)


def faction_label(faction: Faction) -> str:
    return "味方" if faction is Faction.ALLY else "敵"


def display_name(unit: Unit | str) -> str:
    """Return a Japanese display name without changing internal identifiers."""

    raw_name = unit if isinstance(unit, str) else unit.name
    if raw_name in _CHARACTER_NAMES:
        return _CHARACTER_NAMES[raw_name]
    if not isinstance(unit, str) and unit.faction is Faction.ENEMY:
        match = re.search(r"(?:enemy|敵)[ _-]*(\d+)$", unit.unit_id, re.IGNORECASE)
        if match:
            return f"敵{match.group(1)}"
    match = re.match(r"Enemy[ _-]*(\d+)$", raw_name, re.IGNORECASE)
    if match:
        return f"敵{match.group(1)}"
    return raw_name


def unit_marker(unit: Unit) -> str:
    # Strategic invasion units use one-character role markers so adjacent
    # labels stay inside their cells.  These are presentation labels only;
    # the internal IDs and full names remain unchanged in the battle layer.
    if unit.unit_id == "strategy_attacker":
        return "攻"
    if unit.unit_id == "strategy_defender":
        return "防"
    if unit.name in _CHARACTER_MARKERS:
        return _CHARACTER_MARKERS[unit.name]
    match = re.search(r"(?:enemy|敵)[ _-]*(\d+)$", unit.unit_id, re.IGNORECASE)
    if match:
        return f"敵{match.group(1)}"
    return display_name(unit)[:2]


def skill_status(available: bool) -> str:
    return "使用可能" if available else "使用済み"


def direction_label(direction: Any) -> str:
    return {
        "up": "上",
        "down": "下",
        "left": "左",
        "right": "右",
    }.get(getattr(direction, "value", direction), str(direction))


def _localize_tail(tail: str) -> str:
    if not tail:
        return ""
    result = tail
    result = re.sub(r"(\d+) target\(s\) were defeated\.", r"\1体を撃破。", result)
    result = re.sub(
        r"(.+?) stack: (\d+) \(power \+(\d+)\)\.",
        r"\1の軍神が\2スタック（出力 +\3）。",
        result,
    )
    result = re.sub(
        r"(.+?) guarded (.+?) \(absorbed (\d+) damage\)\.",
        r"\1が\2を護衛（\3ダメージ肩代わり）。",
        result,
    )
    return result.strip()


def localize_message(message: str, *, turn_number: Optional[int] = None) -> str:
    """Translate engine/UI status text while leaving internal messages intact."""

    if message.startswith("Enemy AI: "):
        return "敵AI：" + localize_message(message[len("Enemy AI: ") :], turn_number=turn_number)

    turn_match = re.fullmatch(r"(Ally|Enemy) turn started\.", message)
    if turn_match:
        side = "味方" if turn_match.group(1) == "Ally" else "敵"
        prefix = f"第{turn_number}ターン：" if turn_number is not None else ""
        return f"{prefix}{side}ターン開始"

    if message in _STATIC_MESSAGES:
        return _STATIC_MESSAGES[message]

    moved = re.fullmatch(r"(.+?) moved to \((\d+), (\d+)\)\.", message)
    if moved:
        return f"{display_name(moved.group(1))}が（{moved.group(2)}, {moved.group(3)}）へ移動しました。"

    single_attack = re.fullmatch(r"(.+?) dealt (\d+) damage to (.+?)\.(.*)", message)
    if single_attack:
        tail = _localize_tail(single_attack.group(4))
        suffix = f" {tail}" if tail else ""
        return f"{display_name(single_attack.group(1))}が{display_name(single_attack.group(3))}に{single_attack.group(2)}ダメージ。{suffix}"

    multi_attack = re.fullmatch(r"(.+?) dealt (\d+) damage to (\d+) targets\.(.*)", message)
    if multi_attack:
        tail = _localize_tail(multi_attack.group(4))
        suffix = f" {tail}" if tail else ""
        return f"{display_name(multi_attack.group(1))}が{multi_attack.group(3)}体に{multi_attack.group(2)}ダメージ。{suffix}"

    skill_attack = re.fullmatch(
        r"(.+?) used (.+?) and dealt (\d+) damage to (\d+) target\(s\)\.(.*)",
        message,
    )
    if skill_attack:
        tail = _localize_tail(skill_attack.group(5))
        suffix = f" {tail}" if tail else ""
        return f"{display_name(skill_attack.group(1))}が{skill_attack.group(2)}を使用：{skill_attack.group(4)}体に{skill_attack.group(3)}ダメージ。{suffix}"

    ended = re.fullmatch(r"(.+?) ended its action\.", message)
    if ended:
        return f"{display_name(ended.group(1))}が行動を終了しました。"
    return message
