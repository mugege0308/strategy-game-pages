"""Minimal Pygame view for the data-driven strategic map."""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from typing import Any, Optional

from .strategy import (
    DOMESTIC_COMMANDS,
    DomesticCommand,
    InvasionPreparation,
    RouteType,
    StrategicGameState,
    StrategyActionResult,
    StrategyCatalog,
    StrategyDataError,
)
from .strategy_battle import create_invasion_battle, result_from_battle
from .engine import BattleEngine
from .ui_text import find_japanese_font, load_font


LayoutRect = tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class StrategyLayout:
    """Calculated client-area layout for one strategy-map window size."""

    window_size: tuple[int, int]
    map_rect: LayoutRect
    world_rect: LayoutRect
    panel_rect: LayoutRect
    map_buttons: tuple[LayoutRect, ...]
    scenario_buttons: tuple[LayoutRect, ...]
    faction_buttons: tuple[LayoutRect, ...]
    domestic_buttons: tuple[tuple[DomesticCommand, LayoutRect], ...]
    military_buttons: tuple[tuple[str, LayoutRect], ...]
    message_rect: LayoutRect
    city_info_rect: LayoutRect
    action_input_rect: LayoutRect
    action_confirm_button: LayoutRect
    action_cancel_button: LayoutRect
    invasion_start_button: LayoutRect
    log_rect: LayoutRect
    turn_button: LayoutRect
    battle_button: LayoutRect
    menu_button: LayoutRect


class StrategyMapApp:
    """Pygame view and input adapter for the strategic campaign prototype."""

    SCREEN_SIZE = (1200, 800)
    MAP_RECT = (20, 20, 700, 760)
    PANEL_RECT = (740, 20, 440, 760)
    MAP_BUTTONS = ((760, 145, 200, 34), (980, 145, 200, 34))
    SCENARIO_BUTTONS = ((760, 200, 200, 34), (980, 200, 200, 34))
    FACTION_BUTTONS = ((760, 255, 130, 34), (900, 255, 130, 34), (1040, 255, 130, 34))
    DOMESTIC_BUTTONS = (
        (DomesticCommand.AGRICULTURE, (760, 590, 130, 34)),
        (DomesticCommand.COMMERCE, (900, 590, 130, 34)),
        (DomesticCommand.RECRUIT, (1040, 590, 130, 34)),
    )
    MILITARY_BUTTONS = (
        ("move", (760, 630, 200, 34)),
        ("invasion", (980, 630, 200, 34)),
    )
    ACTION_INPUT_RECT = (760, 570, 420, 34)
    ACTION_CONFIRM_BUTTON = (760, 670, 200, 32)
    ACTION_CANCEL_BUTTON = (980, 670, 200, 32)
    INVASION_START_BUTTON = (760, 665, 420, 32)
    TURN_BUTTON = (760, 705, 200, 32)
    BATTLE_BUTTON = (760, 745, 200, 30)
    MENU_BUTTON = (980, 745, 200, 30)
    CITY_RADIUS = 15
    MAP_WORLD_SIZE = (700, 740)
    WINDOW_MARGIN = 12
    PANEL_GAP = 12
    MIN_WINDOW_SIZE = (960, 620)

    def __init__(self, catalog: Optional[StrategyCatalog] = None) -> None:
        self.catalog = catalog or StrategyCatalog()
        self.map_ids = self.catalog.map_ids()
        self.scenario_ids = self.catalog.scenario_ids()
        if not self.scenario_ids:
            raise StrategyDataError("no scenario definitions were found")
        self.selected_scenario_id = self.scenario_ids[0]
        self.state = self.catalog.load_state(self.selected_scenario_id)
        self.selected_city_id: Optional[str] = None
        self.message = ""
        self.log: deque[str] = deque(maxlen=8)
        self.action_mode: Optional[str] = None
        self.action_source_city_id: Optional[str] = None
        self.action_target_city_id: Optional[str] = None
        self.troop_input = ""
        self.last_invasion_preparation: Optional[InvasionPreparation] = None
        self.window_size = self.SCREEN_SIZE
        self.layout = self.layout_for_size(self.window_size)
        self.log_scroll = 0
        self.city_info_scroll = 0
        self._set_message("操作勢力を選択してください。")

    @classmethod
    def layout_for_size(cls, size: tuple[int, int]) -> StrategyLayout:
        """Calculate all map/panel hit boxes inside a resizable client area.

        The returned coordinates are client-area coordinates, which are also
        the coordinate system used by Pygame mouse events.  No title-bar or
        Windows DPI assumptions are baked into the layout.
        """

        width = max(1, int(size[0]))
        height = max(1, int(size[1]))
        margin = cls.WINDOW_MARGIN
        gap = cls.PANEL_GAP

        panel_width = min(460, max(340, int(width * 0.36)))
        panel_width = min(panel_width, max(280, width - (margin * 2 + gap + 360)))
        panel_x = max(margin + 360 + gap, width - margin - panel_width)
        panel_width = max(1, width - margin - panel_x)
        map_rect = (
            margin,
            margin,
            max(1, panel_x - margin - gap),
            max(1, height - margin * 2),
        )
        panel_rect = (panel_x, margin, panel_width, max(1, height - margin * 2))

        inner_x = map_rect[0] + 8
        inner_y = map_rect[1] + 8
        inner_width = max(1, map_rect[2] - 16)
        inner_height = max(1, map_rect[3] - 16)
        world_width, world_height = cls.MAP_WORLD_SIZE
        scale = min(inner_width / world_width, inner_height / world_height)
        rendered_width = max(1, round(world_width * scale))
        rendered_height = max(1, round(world_height * scale))
        world_rect = (
            inner_x + (inner_width - rendered_width) // 2,
            inner_y + (inner_height - rendered_height) // 2,
            rendered_width,
            rendered_height,
        )

        content_x = panel_x + 12
        content_width = max(1, panel_width - 24)
        half_gap = 6
        two_width = max(1, (content_width - half_gap) // 2)
        three_width = max(1, (content_width - half_gap * 2) // 3)
        # Keep the three selector rows below the round/turn/resource header.
        # Labels are carried by the buttons themselves so they cannot collide
        # with the preceding row when the client area is short.
        map_y = margin + 108
        scenario_y = map_y + 38
        faction_y = scenario_y + 38
        message_rect = (content_x, faction_y + 40, content_width, 34)
        city_top = message_rect[1] + message_rect[3] + 8
        city_height = max(128, min(220, int(panel_rect[3] * 0.28)))
        city_info_rect = (content_x, city_top, content_width, city_height)
        action_top = city_top + city_height + 8
        action_input_rect = (content_x, action_top, content_width, 32)
        action_confirm_y = action_top + 42
        action_confirm_button = (content_x, action_confirm_y, two_width, 34)
        action_cancel_button = (
            content_x + two_width + half_gap,
            action_confirm_y,
            two_width,
            34,
        )
        invasion_start_button = (content_x, action_confirm_y, content_width, 34)

        bottom_y = max(action_confirm_y + 34 + 8, height - margin - 34)
        log_top = action_top + 84
        log_rect = (
            content_x,
            log_top,
            content_width,
            max(28, bottom_y - log_top - 8),
        )
        bottom_width = max(1, (content_width - half_gap * 2) // 3)
        turn_button = (content_x, bottom_y, bottom_width, 34)
        battle_button = (content_x + bottom_width + half_gap, bottom_y, bottom_width, 34)
        menu_button = (
            content_x + (bottom_width + half_gap) * 2,
            bottom_y,
            bottom_width,
            34,
        )

        map_buttons = (
            (content_x, map_y, two_width, 32),
            (content_x + two_width + half_gap, map_y, two_width, 32),
        )
        scenario_buttons = (
            (content_x, scenario_y, two_width, 32),
            (content_x + two_width + half_gap, scenario_y, two_width, 32),
        )
        faction_buttons = tuple(
            (content_x + index * (three_width + half_gap), faction_y, three_width, 32)
            for index in range(3)
        )
        domestic_buttons = tuple(
            (
                command,
                (content_x + index * (three_width + half_gap), action_top, three_width, 34),
            )
            for index, command in enumerate(
                (
                    DomesticCommand.AGRICULTURE,
                    DomesticCommand.COMMERCE,
                    DomesticCommand.RECRUIT,
                )
            )
        )
        military_buttons = (
            ("move", (content_x, action_top + 42, two_width, 34)),
            ("invasion", (content_x + two_width + half_gap, action_top + 42, two_width, 34)),
        )
        return StrategyLayout(
            window_size=(width, height),
            map_rect=map_rect,
            world_rect=world_rect,
            panel_rect=panel_rect,
            map_buttons=map_buttons,
            scenario_buttons=scenario_buttons,
            faction_buttons=faction_buttons,
            domestic_buttons=domestic_buttons,
            military_buttons=military_buttons,
            message_rect=message_rect,
            city_info_rect=city_info_rect,
            action_input_rect=action_input_rect,
            action_confirm_button=action_confirm_button,
            action_cancel_button=action_cancel_button,
            invasion_start_button=invasion_start_button,
            log_rect=log_rect,
            turn_button=turn_button,
            battle_button=battle_button,
            menu_button=menu_button,
        )

    def set_window_size(self, size: tuple[int, int]) -> None:
        """Update the client-area layout after a Pygame resize event."""

        self.window_size = (max(1, int(size[0])), max(1, int(size[1])))
        self.layout = self.layout_for_size(self.window_size)

    @staticmethod
    def _initial_window_size(pygame: Any) -> tuple[int, int]:
        """Choose a client size that leaves room for title bar and taskbar."""

        try:
            desktop_width, desktop_height = pygame.display.get_desktop_sizes()[0]
        except (AttributeError, IndexError, TypeError, ValueError):
            info = pygame.display.Info()
            desktop_width = getattr(info, "current_w", 1200) or 1200
            desktop_height = getattr(info, "current_h", 800) or 800
        return (
            min(1200, max(800, int(desktop_width) - 40)),
            min(800, max(560, int(desktop_height) - 100)),
        )

    def select_scenario(self, scenario_id: str) -> None:
        self.state = self.catalog.load_state(scenario_id)
        self.selected_scenario_id = scenario_id
        self.selected_city_id = None
        self.log_scroll = 0
        self.city_info_scroll = 0
        self._clear_action_mode(clear_preparation=True)
        self._set_message(f"{self.state.scenario_definition.name}を読み込みました。操作勢力を選択してください。")

    def select_map(self, map_id: str) -> None:
        scenarios = self.catalog.scenarios_for_map(map_id)
        if not scenarios:
            raise StrategyDataError(f"no scenario is available for map {map_id!r}")
        self.select_scenario(scenarios[0].scenario_id)

    def select_player_faction(self, faction_id: str) -> StrategyActionResult:
        result = self.state.select_player_faction(faction_id)
        if result.success:
            self._clear_action_mode(clear_preparation=True)
        self._set_message(result.message)
        return result

    def select_city(self, city_id: str) -> None:
        self.state.map_definition.city(city_id)
        self.state.city_state(city_id)
        self.selected_city_id = city_id
        self._set_message(f"{self.state.map_definition.city(city_id).name}を選択しました。")

    def execute_domestic_command(
        self,
        city_id: str,
        command: DomesticCommand | str,
    ) -> StrategyActionResult:
        result = self.state.execute_domestic_command(city_id, command)
        if result.success:
            self._clear_action_mode(clear_preparation=True)
        self._set_message(result.message)
        return result

    def move_troops(
        self,
        source_city_id: str,
        target_city_id: str,
        troops: int,
    ) -> StrategyActionResult:
        result = self.state.move_troops(source_city_id, target_city_id, troops)
        if result.success:
            self._clear_action_mode(clear_preparation=True)
        self._set_message(result.message)
        return result

    def prepare_invasion(
        self,
        source_city_id: str,
        target_city_id: str,
        attacking_troops: int,
    ) -> StrategyActionResult:
        result = self.state.prepare_invasion(source_city_id, target_city_id, attacking_troops)
        if result.success:
            self.last_invasion_preparation = result.invasion_preparation
            self._clear_action_mode(clear_preparation=False)
        self._set_message(result.message)
        return result

    def start_invasion(self) -> Optional[BattleEngine]:
        """Start the prepared invasion or resolve an empty defense immediately."""

        preparation = self.last_invasion_preparation
        if preparation is None:
            self._set_message("先に侵攻準備を確定してください。")
            return None
        result = self.state.begin_invasion(preparation)
        self._set_message(result.message)
        if not result.success:
            return None
        if result.battle_result is not None:
            self.last_invasion_preparation = None
            self._set_message(result.message)
            return None
        try:
            return create_invasion_battle(preparation)
        except (TypeError, ValueError) as exc:
            self.state.cancel_invasion()
            self._set_message(f"侵攻戦闘を作成できませんでした：{exc}")
            return None

    def finish_invasion(self, battle: BattleEngine) -> StrategyActionResult:
        """Convert a completed temporary battle into one strategic result."""

        preparation = self.last_invasion_preparation
        if preparation is None:
            result = StrategyActionResult(False, "侵攻準備情報がありません。")
            self._set_message(result.message)
            return result
        try:
            battle_result = result_from_battle(preparation, battle)
        except ValueError as exc:
            result = StrategyActionResult(False, f"未決着の戦闘結果は反映できません：{exc}")
            self._set_message(result.message)
            return result
        result = self.state.apply_invasion_result(battle_result)
        if result.success:
            self.last_invasion_preparation = None
        self._set_message(result.message)
        return result

    def cancel_invasion(self) -> StrategyActionResult:
        result = self.state.cancel_invasion()
        if result.success:
            self.last_invasion_preparation = None
        self._set_message(result.message)
        return result

    def end_turn(self) -> StrategyActionResult:
        if self.state.active_invasion is not None:
            result = self.state.end_turn()
            self._set_message(result.message)
            return result
        self._clear_action_mode(clear_preparation=True)
        result = self.state.end_turn()
        self._set_message(result.message)
        for npc_result in self.state.advance_npc_turns():
            self._set_message(npc_result.message)
        return result

    def _clear_action_mode(self, *, clear_preparation: bool) -> None:
        self.action_mode = None
        self.action_source_city_id = None
        self.action_target_city_id = None
        self.troop_input = ""
        if clear_preparation:
            self.last_invasion_preparation = None

    def _start_action_mode(self, mode: str) -> None:
        if self.selected_city_id is None:
            self._set_message("先に都市を選択してください。")
            return
        if not self.state.city_action_available(self.selected_city_id):
            self._set_message("この都市は今ターンの行動に使用できません。")
            return
        if mode == "invasion" and not self.state.invasion_target_ids(self.selected_city_id):
            self._set_message("隣接する敵都市がないため、侵攻準備できません。")
            return
        self.action_mode = mode
        self.action_source_city_id = self.selected_city_id
        self.action_target_city_id = None
        self.troop_input = ""
        self.last_invasion_preparation = None
        label = "兵士移動" if mode == "move" else "侵攻準備"
        self._set_message(f"{label}：対象都市を選び、兵数を入力してください。")

    def _select_action_target(self, city_id: str) -> None:
        if self.action_mode is None or self.action_source_city_id is None:
            return
        source_id = self.action_source_city_id
        if city_id == source_id:
            self._set_message("移動元と対象都市は別に指定してください。")
            return
        if self.action_mode == "move":
            target = self.state.city_state(city_id)
            player_faction_id = self.state.player_faction_id
            if (
                player_faction_id is None
                or target.faction_id != player_faction_id
                or not self.state.are_adjacent(source_id, city_id)
            ):
                self._set_message("兵士移動は隣接する自勢力の都市に限られます。")
                return
        else:
            if city_id not in self.state.invasion_target_ids(source_id):
                self._set_message("侵攻準備は隣接する敵都市に限られます。")
                return
        self.action_target_city_id = city_id
        city_name = self.state.map_definition.city(city_id).name
        self._set_message(f"対象都市：{city_name}。兵数を入力して確定してください。")

    def _confirm_action(self) -> None:
        if self.action_mode is None or self.action_source_city_id is None or self.action_target_city_id is None:
            self._set_message("対象都市と兵数を指定してください。")
            return
        if not self.troop_input:
            self._set_message("兵数を入力してください。")
            return
        troops = int(self.troop_input)
        if self.action_mode == "move":
            self.move_troops(self.action_source_city_id, self.action_target_city_id, troops)
        else:
            source_id = self.action_source_city_id
            target_id = self.action_target_city_id
            result = self.prepare_invasion(source_id, target_id, troops)
            if result.success:
                self.selected_city_id = target_id

    def _handle_keydown(self, event: Any, pygame: Any) -> None:
        if self.action_mode is None:
            return
        if event.key == pygame.K_BACKSPACE:
            self.troop_input = self.troop_input[:-1]
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self._confirm_action()
        elif event.unicode.isdecimal() and len(self.troop_input) < 7:
            self.troop_input += event.unicode

    def _set_message(self, message: str) -> None:
        self.message = message
        self.log_scroll = 0
        if not self.log or self.log[-1] != message:
            self.log.append(message)

    def selected_neighbors(self) -> tuple[str, ...]:
        if self.selected_city_id is None:
            return ()
        return tuple(city.city_id for city in self.state.neighbors(self.selected_city_id))

    def run(self) -> str:
        try:
            import pygame
        except ImportError as exc:
            raise RuntimeError(
                "Pygame-CE is required to run the strategic map. Install dependencies with "
                "python -m pip install -r requirements.txt."
            ) from exc

        pygame.init()
        initial_size = self._initial_window_size(pygame)
        self.set_window_size(initial_size)
        screen = pygame.display.set_mode(initial_size, pygame.RESIZABLE)
        pygame.display.set_caption("戦略マップ・都市勢力デモ")
        clock = pygame.time.Clock()
        font_path = find_japanese_font(pygame)
        fonts = {
            "title": load_font(pygame, font_path, 28),
            "normal": load_font(pygame, font_path, 20),
            "small": load_font(pygame, font_path, 16),
            "button": load_font(pygame, font_path, 17),
        }
        result = "quit"
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    result = "quit"
                elif event.type == pygame.VIDEORESIZE:
                    self.set_window_size(event.size)
                    screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
                elif event.type == getattr(pygame, "WINDOWSIZECHANGED", -1):
                    self.set_window_size(screen.get_size())
                elif event.type == pygame.MOUSEWHEEL:
                    self._handle_scroll(event.y, pygame.mouse.get_pos())
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if self.action_mode is not None:
                            self._clear_action_mode(clear_preparation=False)
                            self._set_message("操作をキャンセルしました。")
                        else:
                            running = False
                            result = "menu"
                    else:
                        self._handle_keydown(event, pygame)
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    next_mode = self._handle_click(event.pos, pygame)
                    if next_mode is not None:
                        running = False
                        result = next_mode

            actual_size = screen.get_size()
            if actual_size != self.window_size:
                self.set_window_size(actual_size)
            self._draw(screen, fonts, pygame)
            pygame.display.flip()
            clock.tick(60)
        pygame.quit()
        return result

    def _handle_scroll(self, amount: int, mouse_position: tuple[int, int]) -> None:
        """Scroll only the information areas under the mouse cursor."""

        if self._point_in_rect(mouse_position, self.layout.log_rect):
            max_scroll = self._log_scroll_limit()
            self.log_scroll = max(0, min(max_scroll, self.log_scroll - int(amount)))
        elif self._point_in_rect(mouse_position, self.layout.city_info_rect):
            max_scroll = self._city_info_max_scroll()
            self.city_info_scroll = max(0, min(max_scroll, self.city_info_scroll - int(amount)))

    def _log_visible_lines(self) -> int:
        return max(1, (self.layout.log_rect[3] - 26) // 18)

    def _log_scroll_limit(self) -> int:
        return max(0, len(self.log) * 3 - self._log_visible_lines())

    def _city_info_max_scroll(self) -> int:
        if self.selected_city_id is None:
            return 0
        connection_count = len(self.state.map_definition.connections_for(self.selected_city_id))
        content_height = 142 + max(0, connection_count - 1) * 22
        return max(0, content_height - self.layout.city_info_rect[3] + 8)

    @staticmethod
    def _point_in_rect(point: tuple[int, int], rect: LayoutRect) -> bool:
        x, y = point
        return rect[0] <= x < rect[0] + rect[2] and rect[1] <= y < rect[1] + rect[3]

    def _handle_click(self, mouse_position: tuple[int, int], pygame: Any) -> Optional[str]:
        layout = self.layout
        for index, rect_data in enumerate(layout.map_buttons[: len(self.map_ids)]):
            if pygame.Rect(*rect_data).collidepoint(mouse_position):
                self.select_map(self.map_ids[index])
                return None
        for index, rect_data in enumerate(layout.scenario_buttons[: len(self.scenario_ids)]):
            if pygame.Rect(*rect_data).collidepoint(mouse_position):
                self.select_scenario(self.scenario_ids[index])
                return None
        faction_ids = tuple(self.state.factions)
        for index, rect_data in enumerate(layout.faction_buttons[: len(faction_ids)]):
            if pygame.Rect(*rect_data).collidepoint(mouse_position):
                self.select_player_faction(faction_ids[index])
                return None

        # The prepared-invasion button occupies the same action slot as the
        # normal military buttons.  Handle it first so the click is tied to
        # the stored preparation, not to the currently selected city.
        if (
            self.action_mode is None
            and self.last_invasion_preparation is not None
            and pygame.Rect(*layout.invasion_start_button).collidepoint(mouse_position)
        ):
            return "invasion"

        if self.action_mode is None:
            for command, rect_data in layout.domestic_buttons:
                if pygame.Rect(*rect_data).collidepoint(mouse_position):
                    if self.selected_city_id is None:
                        self._set_message("先に都市を選択してください。")
                    else:
                        self.execute_domestic_command(self.selected_city_id, command)
                    return None
            for mode, rect_data in layout.military_buttons:
                if pygame.Rect(*rect_data).collidepoint(mouse_position):
                    self._start_action_mode(mode)
                    return None
        if self.action_mode is not None:
            if pygame.Rect(*layout.action_confirm_button).collidepoint(mouse_position):
                self._confirm_action()
                return None
            if pygame.Rect(*layout.action_cancel_button).collidepoint(mouse_position):
                self._clear_action_mode(clear_preparation=False)
                self._set_message("操作をキャンセルしました。")
                return None
            if (
                pygame.Rect(*layout.turn_button).collidepoint(mouse_position)
                or pygame.Rect(*layout.battle_button).collidepoint(mouse_position)
                or pygame.Rect(*layout.menu_button).collidepoint(mouse_position)
            ):
                self._set_message("先に現在の操作を確定またはキャンセルしてください。")
                return None
        if pygame.Rect(*layout.turn_button).collidepoint(mouse_position):
            if self.state.player_faction_id is None:
                self._set_message("先に操作勢力を選択してください。")
            elif self.state.current_faction_id != self.state.player_faction_id:
                self._set_message("現在は自勢力のターンではありません。")
            else:
                self.end_turn()
            return None
        if pygame.Rect(*layout.battle_button).collidepoint(mouse_position):
            return "battle"
        if pygame.Rect(*layout.menu_button).collidepoint(mouse_position):
            return "menu"

        city_id = self._city_at(mouse_position)
        if city_id is not None:
            if self.action_mode is not None:
                self._select_action_target(city_id)
            else:
                self.select_city(city_id)
        return None

    def _city_at(self, mouse_position: tuple[int, int]) -> Optional[str]:
        radius = self._city_radius()
        for city_id, city in self.state.map_definition.cities.items():
            center = self._screen_position(city.position.x, city.position.y)
            if math.hypot(mouse_position[0] - center[0], mouse_position[1] - center[1]) <= radius + 4:
                return city_id
        return None

    def _draw(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        screen.fill((27, 31, 39))
        self._draw_map(screen, fonts, pygame)
        self._draw_panel(screen, fonts, pygame)

    def _draw_map(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        layout = self.layout
        map_rect = pygame.Rect(*layout.map_rect)
        pygame.draw.rect(screen, (36, 61, 73), map_rect)
        pygame.draw.rect(screen, (100, 125, 135), map_rect, 2)
        previous_clip = screen.get_clip()
        screen.set_clip(map_rect)

        for connection in self.state.map_definition.connections:
            start_city = self.state.map_definition.city(connection.from_city_id)
            end_city = self.state.map_definition.city(connection.to_city_id)
            start = self._screen_position(start_city.x, start_city.y)
            end = self._screen_position(end_city.x, end_city.y)
            color = (180, 185, 185) if connection.route_type is RouteType.LAND else (80, 200, 220)
            if connection.route_type is RouteType.LAND:
                pygame.draw.line(screen, color, start, end, 3)
            else:
                self._draw_dashed_line(screen, pygame, start, end, color)

        neighbor_ids = set(self.selected_neighbors())
        action_target_ids: set[str] = set()
        if self.action_mode == "move" and self.action_source_city_id is not None:
            player_faction_id = self.state.player_faction_id
            if player_faction_id is not None:
                action_target_ids = {
                    city.city_id
                    for city in self.state.neighbors(self.action_source_city_id)
                    if self.state.city_state(city.city_id).faction_id == player_faction_id
                }
        elif self.action_mode == "invasion" and self.action_source_city_id is not None:
            action_target_ids = set(self.state.invasion_target_ids(self.action_source_city_id))
        for city_id, city in self.state.map_definition.cities.items():
            city_state = self.state.city_state(city_id)
            faction = self.state.factions[city_state.faction_id]
            center = self._screen_position(city.x, city.y)
            radius = self._city_radius()
            pygame.draw.circle(screen, faction.color, center, radius)
            if city_id == self.selected_city_id:
                pygame.draw.circle(screen, (255, 230, 90), center, radius + 5, 3)
            if city_id == self.action_target_city_id:
                pygame.draw.circle(screen, (255, 120, 80), center, radius + 6, 3)
            elif city_id in action_target_ids:
                pygame.draw.circle(screen, (255, 170, 80), center, radius + 4, 3)
            elif city_id in neighbor_ids:
                pygame.draw.circle(screen, (100, 235, 240), center, radius + 4, 3)
            pygame.draw.circle(screen, (235, 235, 235), center, radius, 2)
            label = fonts["small"].render(city.name, True, (245, 245, 245))
            screen.blit(label, label.get_rect(center=(center[0], center[1] + radius + 14)))
        screen.set_clip(previous_clip)

    def _draw_panel(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        layout = self.layout
        panel = pygame.Rect(*layout.panel_rect)
        pygame.draw.rect(screen, (45, 49, 59), panel)
        pygame.draw.rect(screen, (110, 115, 125), panel, 2)
        left = panel.x + 12
        self._text(screen, fonts["title"], "【戦略マップ】", (left, panel.y + 8))
        self._text(screen, fonts["small"], f"第{self.state.round_number}ラウンド", (left, panel.y + 42), (255, 230, 120))
        self._text(screen, fonts["small"], f"現在のターン：{self.state.current_faction.name}", (left, panel.y + 64))
        player = self.state.player_faction
        if player is None:
            resource_text = "操作勢力：未選択　金：—　米：—"
        else:
            resources = self.state.faction_state(player.faction_id)
            resource_text = f"操作勢力：{player.name}　金：{resources.gold}　米：{resources.rice}"
        self._text(screen, fonts["small"], resource_text, (left, panel.y + 86))

        for index, rect_data in enumerate(layout.map_buttons[: len(self.map_ids)]):
            map_id = self.map_ids[index]
            label = self.catalog.load_map(map_id).name
            self._button(screen, fonts["button"], pygame, rect_data, label, map_id == self.state.map_definition.map_id)

        for index, rect_data in enumerate(layout.scenario_buttons[: len(self.scenario_ids)]):
            scenario_id = self.scenario_ids[index]
            label = self.catalog.load_scenario(scenario_id).name
            self._button(screen, fonts["button"], pygame, rect_data, label, scenario_id == self.selected_scenario_id)

        faction_ids = tuple(self.state.factions)
        for index, rect_data in enumerate(layout.faction_buttons[: len(faction_ids)]):
            faction_id = faction_ids[index]
            self._button(
                screen,
                fonts["button"],
                pygame,
                rect_data,
                self.state.factions[faction_id].name,
                faction_id == self.state.player_faction_id,
            )

        self._draw_wrapped(screen, fonts["small"], self.message, layout.message_rect, (220, 220, 225), max_lines=2)
        self._draw_city_info(screen, fonts, pygame)

        if self.selected_city_id is not None and self.action_mode is None and self.last_invasion_preparation is None:
            can_act = self.state.city_domestic_action_available(self.selected_city_id)
            for command, rect_data in layout.domestic_buttons:
                definition = DOMESTIC_COMMANDS[command]
                self._button(
                    screen,
                    fonts["button"],
                    pygame,
                    rect_data,
                    definition.name,
                    selected=False,
                    enabled=can_act and self.state.can_execute_domestic_command(self.selected_city_id, command),
                )
            self._button(
                screen,
                fonts["button"],
                pygame,
                layout.military_buttons[0][1],
                "兵士移動",
                enabled=can_act,
            )
            self._button(
                screen,
                fonts["button"],
                pygame,
                layout.military_buttons[1][1],
                "侵攻準備",
                enabled=can_act and bool(self.state.invasion_target_ids(self.selected_city_id)),
            )

        if self.action_mode is not None:
            mode_name = "兵士移動" if self.action_mode == "move" else "侵攻準備"
            target_name = "未選択"
            if self.action_target_city_id is not None:
                target_name = self.state.map_definition.city(self.action_target_city_id).name
            self._text(screen, fonts["small"], f"【{mode_name}】対象：{target_name}", (left, layout.action_input_rect[1] - 19), (255, 220, 150))
            input_rect = pygame.Rect(*layout.action_input_rect)
            pygame.draw.rect(screen, (35, 38, 47), input_rect)
            pygame.draw.rect(screen, (170, 175, 185), input_rect, 2)
            input_text = self.troop_input or "兵数を入力"
            self._text(screen, fonts["normal"], input_text, (left + 12, layout.action_input_rect[1] + 5), (245, 245, 245))
            self._button(
                screen,
                fonts["button"],
                pygame,
                layout.action_confirm_button,
                "確定",
                enabled=self.action_target_city_id is not None and bool(self.troop_input),
            )
            self._button(screen, fonts["button"], pygame, layout.action_cancel_button, "キャンセル")

        if self.action_mode is None and self.last_invasion_preparation is not None:
            preparation = self.last_invasion_preparation
            if self.state.validate_invasion_preparation(preparation):
                source_name = self.state.map_definition.city(preparation.source_city_id).name
                target_name = self.state.map_definition.city(preparation.target_city_id).name
                self._text(
                    screen,
                    fonts["small"],
                    f"侵攻準備：{source_name}→{target_name} 攻撃{preparation.attacking_troops}人／防御{preparation.defending_troops}人",
                    (left, layout.action_input_rect[1] - 19),
                    (255, 220, 150),
                )
                route = "陸路" if preparation.route_type is RouteType.LAND else "海路"
                self._text(screen, fonts["small"], f"接続：{route}　戦闘は未開始", (left, layout.action_input_rect[1] + 2), (255, 220, 150))

        player_turn = self.state.player_faction_id is not None and self.state.current_faction_id == self.state.player_faction_id
        prepared_invasion = (
            self.action_mode is None
            and self.last_invasion_preparation is not None
            and self.state.validate_invasion_preparation(self.last_invasion_preparation)
        )
        if prepared_invasion:
            self._button(
                screen,
                fonts["button"],
                pygame,
                layout.invasion_start_button,
                "侵攻開始（戦闘へ）",
                enabled=player_turn,
            )
        self._draw_log(screen, fonts, pygame)
        self._button(screen, fonts["button"], pygame, layout.turn_button, "ターン終了", enabled=player_turn and self.action_mode is None)
        self._button(screen, fonts["button"], pygame, layout.battle_button, "戦闘デモ", enabled=self.action_mode is None)
        self._button(screen, fonts["button"], pygame, layout.menu_button, "メニューへ戻る", enabled=self.action_mode is None)

    def _draw_city_info(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        layout = self.layout
        rect = pygame.Rect(*layout.city_info_rect)
        previous_clip = screen.get_clip()
        screen.set_clip(rect)
        left = rect.x + 8
        y = rect.y + 7 - self.city_info_scroll
        if self.selected_city_id is None:
            self._text(screen, fonts["normal"], "都市を選択してください", (left, y), (235, 235, 235))
            self._text(screen, fonts["small"], "線：陸路　破線：海路", (left, y + 30))
        else:
            city = self.state.map_definition.city(self.selected_city_id)
            city_state = self.state.city_state(self.selected_city_id)
            faction = self.state.factions[city_state.faction_id]
            action_state = "済" if city_state.domestic_action_used else "可能"
            self._text(screen, fonts["small"], "【選択都市】", (left, y))
            self._text(screen, fonts["normal"], city.name, (left, y + 23), (255, 230, 120))
            self._text(screen, fonts["small"], f"地域：{city.region or '未設定'}", (left, y + 49))
            self._text(screen, fonts["small"], f"所属勢力：{faction.name}", (left, y + 71), faction.color)
            self._text(screen, fonts["small"], f"兵士数：{city_state.troops}　都市行動：{action_state}", (left, y + 93))
            self._text(screen, fonts["small"], "【接続都市】", (left, y + 115))
            connections = []
            for connection in self.state.map_definition.connections_for(self.selected_city_id):
                other_id = (
                    connection.to_city_id
                    if connection.from_city_id == self.selected_city_id
                    else connection.from_city_id
                )
                other = self.state.map_definition.city(other_id)
                route = "陸路" if connection.route_type is RouteType.LAND else "海路"
                connections.append(f"{other.name}（{route}）")
            connection_text = "・" + "、".join(connections) if connections else "・なし"
            for index, line in enumerate(self._wrap_text(connection_text, fonts["small"], rect.width - 16)):
                self._text(screen, fonts["small"], line, (left, y + 137 + index * 20))
        screen.set_clip(previous_clip)
        self.city_info_scroll = min(self.city_info_scroll, self._city_info_max_scroll())

    def _draw_log(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        rect = pygame.Rect(*self.layout.log_rect)
        pygame.draw.rect(screen, (38, 42, 51), rect)
        pygame.draw.rect(screen, (100, 105, 115), rect, 1)
        previous_clip = screen.get_clip()
        screen.set_clip(rect)
        self._text(screen, fonts["small"], "【戦略ログ】", (rect.x + 8, rect.y + 3))
        entries: list[str] = []
        for entry in self.log:
            entries.extend(self._wrap_text("・" + entry, fonts["small"], rect.width - 16))
        visible = self._log_visible_lines()
        start = max(0, len(entries) - visible - self.log_scroll)
        for index, entry in enumerate(entries[start : start + visible]):
            self._text(screen, fonts["small"], entry, (rect.x + 8, rect.y + 25 + index * 18), (215, 215, 220))
        screen.set_clip(previous_clip)

    def _screen_position(self, x: int, y: int) -> tuple[int, int]:
        world = self.layout.world_rect
        map_width, map_height = self.state.map_definition.width, self.state.map_definition.height
        return (
            world[0] + round(x * world[2] / map_width),
            world[1] + round(y * world[3] / map_height),
        )

    def _city_radius(self) -> int:
        world = self.layout.world_rect
        map_width, map_height = self.state.map_definition.width, self.state.map_definition.height
        scale = min(world[2] / map_width, world[3] / map_height)
        return max(8, min(self.CITY_RADIUS, round(self.CITY_RADIUS * scale)))

    @staticmethod
    def _wrap_text(text: str, font: Any, max_width: int) -> list[str]:
        lines: list[str] = []
        for paragraph in text.split("\n"):
            current = ""
            for character in paragraph:
                candidate = current + character
                if current and font.size(candidate)[0] > max_width:
                    lines.append(current)
                    current = character
                else:
                    current = candidate
            lines.append(current)
        return lines or [""]

    def _draw_wrapped(
        self,
        screen: Any,
        font: Any,
        text: str,
        rect_data: LayoutRect,
        color: tuple[int, int, int],
        *,
        max_lines: int,
    ) -> None:
        rect_x, rect_y, rect_width, rect_height = rect_data
        lines = self._wrap_text(text, font, max(1, rect_width))[:max_lines]
        for index, line in enumerate(lines):
            y = rect_y + index * 18
            if y + 18 > rect_y + rect_height:
                break
            self._text(screen, font, line, (rect_x, y), color)

    @staticmethod
    def _draw_dashed_line(screen: Any, pygame: Any, start: tuple[int, int], end: tuple[int, int], color: tuple[int, int, int]) -> None:
        distance = math.hypot(end[0] - start[0], end[1] - start[1])
        if distance == 0:
            return
        dash = 9
        gap = 6
        steps = max(1, int(distance / (dash + gap)))
        for index in range(steps + 1):
            begin_ratio = min(1.0, index * (dash + gap) / distance)
            end_ratio = min(1.0, (index * (dash + gap) + dash) / distance)
            begin = (
                int(start[0] + (end[0] - start[0]) * begin_ratio),
                int(start[1] + (end[1] - start[1]) * begin_ratio),
            )
            finish = (
                int(start[0] + (end[0] - start[0]) * end_ratio),
                int(start[1] + (end[1] - start[1]) * end_ratio),
            )
            pygame.draw.line(screen, color, begin, finish, 3)

    @staticmethod
    def _text(screen: Any, font: Any, text: str, position: tuple[int, int], color=(235, 235, 235)) -> None:
        screen.blit(font.render(text, True, color), position)

    @staticmethod
    def _button(
        screen: Any,
        font: Any,
        pygame: Any,
        rect_data: tuple[int, int, int, int],
        label: str,
        selected: bool = False,
        enabled: bool = True,
    ) -> None:
        rect = pygame.Rect(*rect_data)
        if not enabled:
            fill = (65, 68, 78)
            border = (100, 100, 110)
            text_color = (135, 135, 145)
        else:
            fill = (125, 100, 45) if selected else (80, 95, 120)
            border = (255, 215, 90) if selected else (130, 140, 155)
            text_color = (255, 255, 255)
        pygame.draw.rect(screen, fill, rect)
        pygame.draw.rect(screen, border, rect, 2)
        rendered = font.render(label, True, text_color)
        screen.blit(rendered, rendered.get_rect(center=rect.center))
