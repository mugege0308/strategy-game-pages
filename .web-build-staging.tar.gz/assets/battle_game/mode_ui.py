"""Startup mode selection for the battle and strategic-map demos."""

from __future__ import annotations

from typing import Any

from .ui_text import find_japanese_font, load_font


class PygameModeMenu:
    """Small menu that keeps the existing battle UI as a separate application."""

    SCREEN_SIZE = (1200, 800)
    BATTLE_BUTTON = (300, 300, 260, 70)
    STRATEGY_BUTTON = (640, 300, 260, 70)
    FREE_BATTLE_BUTTON = (300, 405, 600, 70)

    def run(self) -> str:
        try:
            import pygame
        except ImportError as exc:
            raise RuntimeError(
                "Pygame-CE is required to run the game. Install dependencies with "
                "python -m pip install -r requirements.txt."
            ) from exc

        pygame.init()
        screen = pygame.display.set_mode(self.SCREEN_SIZE)
        pygame.display.set_caption("ターン制戦略ゲーム")
        clock = pygame.time.Clock()
        font_path = find_japanese_font(pygame)
        title_font = load_font(pygame, font_path, 34)
        button_font = load_font(pygame, font_path, 23)
        small_font = load_font(pygame, font_path, 17)
        result = "quit"
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if pygame.Rect(*self.BATTLE_BUTTON).collidepoint(event.pos):
                        result = "battle"
                        running = False
                    elif pygame.Rect(*self.STRATEGY_BUTTON).collidepoint(event.pos):
                        result = "strategy"
                        running = False
                    elif pygame.Rect(*self.FREE_BATTLE_BUTTON).collidepoint(event.pos):
                        result = "free_battle"
                        running = False

            screen.fill((27, 31, 39))
            title = title_font.render("ターン制戦略ゲーム", True, (255, 230, 120))
            screen.blit(title, title.get_rect(center=(self.SCREEN_SIZE[0] // 2, 170)))
            self._button(screen, pygame, button_font, self.BATTLE_BUTTON, "戦闘デモ")
            self._button(screen, pygame, button_font, self.STRATEGY_BUTTON, "戦略マップ")
            self._button(screen, pygame, button_font, self.FREE_BATTLE_BUTTON, "自由戦闘（編成して戦う）")
            hint = small_font.render("Esc：終了", True, (205, 205, 215))
            screen.blit(hint, hint.get_rect(center=(self.SCREEN_SIZE[0] // 2, 470)))
            pygame.display.flip()
            clock.tick(60)
        pygame.quit()
        return result

    @staticmethod
    def _button(screen: Any, pygame: Any, font: Any, rect_data: tuple[int, int, int, int], label: str) -> None:
        rect = pygame.Rect(*rect_data)
        pygame.draw.rect(screen, (80, 95, 120), rect)
        pygame.draw.rect(screen, (155, 165, 180), rect, 2)
        text = font.render(label, True, (255, 255, 255))
        screen.blit(text, text.get_rect(center=rect.center))
