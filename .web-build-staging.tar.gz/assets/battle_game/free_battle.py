"""Data-driven setup for free-form multi-unit battles.

This module deliberately contains no Pygame code.  It validates teams and
initial placements, then creates ordinary ``Unit`` objects for the existing
``BattleEngine``.  That keeps the strategic invasion path and the combat rules
unchanged while making the setup usable by a future simulation runner.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Optional

from .characters import CharacterDefinition, character_definition, character_definitions
from .engine import BattleEngine
from .models import Faction, Position, Unit


MIN_TEAM_SIZE = 1
MAX_TEAM_SIZE = 5
DEFAULT_TEAM_SIZE = 4


@dataclass(slots=True)
class FreeBattleTeam:
    """A mutable list of character ids for one side of a free battle."""

    faction: Faction
    character_ids: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.character_ids = list(self.character_ids)

    def validate(self) -> None:
        if not MIN_TEAM_SIZE <= len(self.character_ids) <= MAX_TEAM_SIZE:
            raise ValueError(
                f"team size must be between {MIN_TEAM_SIZE} and {MAX_TEAM_SIZE}"
            )
        for character_id in self.character_ids:
            character_definition(character_id)

    def add(self, character_id: str) -> None:
        character_definition(character_id)
        if len(self.character_ids) >= MAX_TEAM_SIZE:
            raise ValueError("team is full")
        self.character_ids.append(character_id)

    def remove(self, index: int) -> str:
        if not 0 <= index < len(self.character_ids):
            raise IndexError("team slot is out of range")
        if len(self.character_ids) <= MIN_TEAM_SIZE:
            raise ValueError("team must keep at least one unit")
        return self.character_ids.pop(index)

    def cycle(self, index: int, step: int = 1) -> str:
        if not 0 <= index < len(self.character_ids):
            raise IndexError("team slot is out of range")
        options = character_definitions()
        current = next(
            position
            for position, option in enumerate(options)
            if option.character_id == self.character_ids[index]
        )
        selected = options[(current + step) % len(options)]
        self.character_ids[index] = selected.character_id
        return selected.character_id


@dataclass(frozen=True, slots=True)
class PlacementRules:
    """Separated initial zones for a rectangular battle map."""

    width: int = 20
    height: int = 20

    def __post_init__(self) -> None:
        if self.width <= 1 or self.height <= 0:
            raise ValueError("placement map must be at least 2x1")

    def allowed(self, faction: Faction, position: Position) -> bool:
        if not (0 <= position.x < self.width and 0 <= position.y < self.height):
            return False
        midpoint = self.width // 2
        return position.x < midpoint if faction is Faction.ALLY else position.x >= midpoint

    def positions(self, faction: Faction) -> tuple[Position, ...]:
        return tuple(
            Position(x, y)
            for y in range(self.height)
            for x in range(self.width)
            if self.allowed(faction, Position(x, y))
        )

    def auto_positions(self, faction: Faction, count: int) -> tuple[Position, ...]:
        if not MIN_TEAM_SIZE <= count <= MAX_TEAM_SIZE:
            raise ValueError("auto placement count must be between 1 and 5")
        midpoint = self.width // 2
        x_values = (0, 1, 2) if faction is Faction.ALLY else (
            self.width - 1,
            self.width - 2,
            self.width - 3,
        )
        candidates = [
            Position(x, y)
            for y in range(1, self.height - 1)
            for x in x_values
            if self.allowed(faction, Position(x, y))
        ]
        # ``x_values`` is deliberately near the edge so both teams have a
        # visible deployment area and enough room for an opening approach.
        if len(candidates) < count:
            candidates = list(self.positions(faction))
        return tuple(candidates[:count])


@dataclass(slots=True)
class FreeBattleConfiguration:
    """Serializable setup data suitable for UI or future simulation runs."""

    ally_character_ids: list[str] = field(
        default_factory=lambda: ["saber", "masamune", "toudo", "kenshin"]
    )
    enemy_character_ids: list[str] = field(
        default_factory=lambda: ["saber", "masamune", "toudo", "kenshin"]
    )
    ally_positions: dict[str, Position] = field(default_factory=dict)
    enemy_positions: dict[str, Position] = field(default_factory=dict)
    seed: Optional[int] = None

    def teams(self) -> tuple[FreeBattleTeam, FreeBattleTeam]:
        return (
            FreeBattleTeam(Faction.ALLY, list(self.ally_character_ids)),
            FreeBattleTeam(Faction.ENEMY, list(self.enemy_character_ids)),
        )

    def validate(self, rules: Optional[PlacementRules] = None) -> None:
        rules = rules or PlacementRules()
        ally, enemy = self.teams()
        ally.validate()
        enemy.validate()
        self._validate_positions(ally, self.ally_positions, rules)
        self._validate_positions(enemy, self.enemy_positions, rules)
        occupied = set(self.ally_positions.values())
        if occupied.intersection(self.enemy_positions.values()):
            raise ValueError("teams cannot share an initial position")

    @staticmethod
    def _validate_positions(
        team: FreeBattleTeam,
        positions: Mapping[str, Position],
        rules: PlacementRules,
    ) -> None:
        expected_ids = {f"{team.faction.value}_{index + 1}" for index in range(len(team.character_ids))}
        if set(positions) != expected_ids:
            raise ValueError("every team unit needs exactly one initial position")
        values = list(positions.values())
        if len(set(values)) != len(values):
            raise ValueError("initial positions must be unique")
        if not all(rules.allowed(team.faction, position) for position in values):
            raise ValueError("initial position is outside its faction deployment zone")

    def auto_place(self, rules: Optional[PlacementRules] = None) -> None:
        rules = rules or PlacementRules()
        self.ally_positions = {
            f"ally_{index + 1}": position
            for index, position in enumerate(
                rules.auto_positions(Faction.ALLY, len(self.ally_character_ids))
            )
        }
        self.enemy_positions = {
            f"enemy_{index + 1}": position
            for index, position in enumerate(
                rules.auto_positions(Faction.ENEMY, len(self.enemy_character_ids))
            )
        }
        self.validate(rules)


def create_free_battle(
    configuration: FreeBattleConfiguration,
    *,
    rules: Optional[PlacementRules] = None,
) -> BattleEngine:
    """Create a normal ``BattleEngine`` from a validated free-battle setup."""

    rules = rules or PlacementRules()
    configuration.validate(rules)
    units: list[Unit] = []
    for faction, character_ids, positions in (
        (Faction.ALLY, configuration.ally_character_ids, configuration.ally_positions),
        (Faction.ENEMY, configuration.enemy_character_ids, configuration.enemy_positions),
    ):
        for index, character_id in enumerate(character_ids, start=1):
            unit_id = f"{faction.value}_{index}"
            definition: CharacterDefinition = character_definition(character_id)
            units.append(definition.create(unit_id, faction, positions[unit_id]))
    return BattleEngine(units, width=rules.width, height=rules.height)
