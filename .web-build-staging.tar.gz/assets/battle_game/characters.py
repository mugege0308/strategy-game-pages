"""Factories and the data-driven playable character roster."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .models import Faction, Position, Unit
from .skills import (
    AbilityDefinition,
    BOOGIE_WOOGIE_ID,
    EXCALIBUR_ID,
    GUNSHIN_ID,
    MOBILITY_SHOOTING_ID,
    SkillDefinition,
    SkillEffect,
    TargetingMode,
)


EXCALIBUR = SkillDefinition(
    skill_id=EXCALIBUR_ID,
    name="エクスカリバー",
    base_damage=200,
    uses_per_battle=1,
    attack_range=4,
    targeting=TargetingMode.LINE,
    line_length=4,
)

MOBILITY_SHOOTING = AbilityDefinition(
    ability_id=MOBILITY_SHOOTING_ID,
    name="機動射撃",
    post_attack_move_range=3,
)

GUNSHIN = AbilityDefinition(
    ability_id=GUNSHIN_ID,
    name="軍神",
    power_per_successful_attack=10,
)

BOOGIE_WOOGIE = SkillDefinition(
    skill_id=BOOGIE_WOOGIE_ID,
    name="不義遊戯",
    base_damage=0,
    uses_per_battle=1,
    uses_per_turn=1,
    attack_range=5,
    targeting=TargetingMode.PAIR,
    effect=SkillEffect.POSITION_SWAP,
    ends_action=False,
)


def create_saber(unit_id: str, faction: Faction, position: Position) -> Unit:
    """Create a Saber unit with its one battle skill available."""

    return Unit(
        unit_id=unit_id,
        name="セイバー",
        faction=faction,
        position=position,
        power=110,
        defense=115,
        move=2,
        attack_range=1,
        troops=1000,
        max_troops=1000,
        skills={EXCALIBUR_ID: EXCALIBUR},
    )


def create_masamune(unit_id: str, faction: Faction, position: Position) -> Unit:
    """Create Date Masamune with the post-attack movement ability."""

    return Unit(
        unit_id=unit_id,
        name="伊達政宗",
        faction=faction,
        position=position,
        power=90,
        defense=90,
        move=3,
        attack_range=4,
        troops=1000,
        max_troops=1000,
        abilities={MOBILITY_SHOOTING_ID: MOBILITY_SHOOTING},
    )


def create_toudo(unit_id: str, faction: Faction, position: Position) -> Unit:
    """Create Toudo Aoi with the per-turn position-swap skill."""

    return Unit(
        unit_id=unit_id,
        name="東堂葵",
        faction=faction,
        position=position,
        power=95,
        defense=105,
        move=2,
        attack_range=1,
        troops=1000,
        max_troops=1000,
        skills={BOOGIE_WOOGIE_ID: BOOGIE_WOOGIE},
    )


def create_kenshin(unit_id: str, faction: Faction, position: Position) -> Unit:
    """Create Uesugi Kenshin with combat-only attack growth."""

    return Unit(
        unit_id=unit_id,
        name="上杉謙信",
        faction=faction,
        position=position,
        power=110,
        defense=105,
        move=3,
        attack_range=1,
        troops=1000,
        max_troops=1000,
        abilities={GUNSHIN_ID: GUNSHIN},
    )


CharacterFactory = Callable[[str, Faction, Position], Unit]


@dataclass(frozen=True, slots=True)
class CharacterDefinition:
    """A roster entry used by free battle setup screens.

    Runtime state is never stored here.  Each call to ``create`` returns a new
    :class:`Unit`, so duplicate roster entries remain independent in battle.
    """

    character_id: str
    display_name: str
    factory: CharacterFactory

    def create(self, unit_id: str, faction: Faction, position: Position) -> Unit:
        return self.factory(unit_id, faction, position)


CHARACTER_DEFINITIONS: tuple[CharacterDefinition, ...] = (
    CharacterDefinition("saber", "セイバー", create_saber),
    CharacterDefinition("masamune", "伊達政宗", create_masamune),
    CharacterDefinition("toudo", "東堂葵", create_toudo),
    CharacterDefinition("kenshin", "上杉謙信", create_kenshin),
)


def character_definitions() -> tuple[CharacterDefinition, ...]:
    """Return all available character definitions in stable UI order."""

    return CHARACTER_DEFINITIONS


def character_definition(character_id: str) -> CharacterDefinition:
    """Look up a roster entry without duplicating character-name branches."""

    for definition in CHARACTER_DEFINITIONS:
        if definition.character_id == character_id:
            return definition
    raise KeyError(f"unknown character id: {character_id}")
