"""Pure combat calculations."""

from __future__ import annotations

from typing import Optional

from .models import Unit


def troop_ratio(troops: int, max_troops: int) -> float:
    """Return the specification's 0.5--1.0 troop effectiveness ratio."""

    if max_troops <= 0:
        raise ValueError("max_troops must be positive")
    return 0.5 + 0.5 * (max(0, troops) / max_troops)


def calculate_damage(
    attacker: Unit,
    defender: Unit,
    base_damage: int = 100,
    *,
    attacker_troops: Optional[int] = None,
) -> int:
    """Calculate normal damage using integer truncation for fractional damage.

    The formula is deliberately independent of the battle engine so it can be
    unit-tested and reused by future skills or alternate UIs.
    """

    if base_damage <= 0:
        raise ValueError("base_damage must be positive")
    attacking_troops = attacker.troops if attacker_troops is None else attacker_troops
    effective_power = attacker.effective_power * troop_ratio(attacking_troops, attacker.max_troops)
    effective_defense = defender.defense * troop_ratio(defender.troops, defender.max_troops)
    if effective_defense <= 0:
        raise ValueError("effective defense must be positive")
    return int(base_damage * effective_power / effective_defense)
