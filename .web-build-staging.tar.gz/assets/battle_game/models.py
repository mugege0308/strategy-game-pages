"""Core data models for the battle engine.

The models intentionally contain no Pygame dependencies.  A future UI can use
the same engine state without changing these classes.
"""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from enum import Enum

from .skills import AbilityDefinition, SkillDefinition


class Faction(str, Enum):
    """The two factions in the prototype."""

    ALLY = "ally"
    ENEMY = "enemy"

    @property
    def opponent(self) -> "Faction":
        return Faction.ENEMY if self is Faction.ALLY else Faction.ALLY


@dataclass(frozen=True, slots=True)
class Position:
    """An integer map coordinate, with (0, 0) at the top-left."""

    x: int
    y: int

    def manhattan_distance(self, other: "Position") -> int:
        return abs(self.x - other.x) + abs(self.y - other.y)


@dataclass(slots=True)
class Unit:
    """A combat unit and its per-turn action state."""

    unit_id: str
    name: str
    faction: Faction
    position: Position
    power: int = 100
    defense: int = 100
    move: int = 2
    attack_range: int = 1
    troops: int = 1000
    max_troops: int = 1000
    moved_this_turn: bool = False
    attacked_this_turn: bool = False
    action_ended: bool = False
    skills: dict[str, SkillDefinition] = field(default_factory=dict)
    skill_uses: dict[str, int] = field(default_factory=dict)
    abilities: dict[str, AbilityDefinition] = field(default_factory=dict)
    ability_stacks: dict[str, int] = field(default_factory=dict)
    post_attack_move_available: bool = False
    post_attack_move_used: bool = False
    post_attack_move_range: int = 0

    def __post_init__(self) -> None:
        if self.max_troops <= 0:
            raise ValueError("max_troops must be positive")
        if self.move < 0:
            raise ValueError("move must not be negative")
        if self.attack_range < 0:
            raise ValueError("attack_range must not be negative")
        self.troops = max(0, min(self.troops, self.max_troops))
        for skill_id in self.skills:
            if skill_id != self.skills[skill_id].skill_id:
                raise ValueError("skill dictionary key must match skill_id")
            self.skill_uses.setdefault(skill_id, 0)
        for ability_id in self.abilities:
            if ability_id != self.abilities[ability_id].ability_id:
                raise ValueError("ability dictionary key must match ability_id")
            self.ability_stacks.setdefault(ability_id, 0)
        for ability_id, stacks in self.ability_stacks.items():
            if ability_id not in self.abilities:
                raise ValueError("ability stack key must match an ability")
            if stacks < 0:
                raise ValueError("ability stacks must not be negative")
        if self.post_attack_move_range < 0:
            raise ValueError("post_attack_move_range must not be negative")

    @property
    def defeated(self) -> bool:
        """Whether the unit has no remaining troops."""

        return self.troops <= 0

    def reset_turn_actions(self) -> None:
        self.moved_this_turn = False
        self.attacked_this_turn = False
        self.action_ended = self.defeated
        self.post_attack_move_available = False
        self.post_attack_move_used = False
        self.post_attack_move_range = 0
        for skill_id, skill in self.skills.items():
            if skill.uses_per_turn is not None:
                self.skill_uses[skill_id] = 0

    def clear_post_attack_move(self) -> None:
        """Discard an unused post-attack movement right."""

        self.post_attack_move_available = False
        self.post_attack_move_range = 0

    def grant_post_attack_move(self, distance: int) -> None:
        if distance <= 0:
            raise ValueError("post-attack movement distance must be positive")
        self.post_attack_move_range = distance
        self.post_attack_move_available = True
        self.post_attack_move_used = False

    def reset_battle_skills(self) -> None:
        """Make every defined skill available at the start of a battle."""

        self.skill_uses = {skill_id: 0 for skill_id in self.skills}

    def reset_battle_abilities(self) -> None:
        """Reset combat-only ability progression for a new battle."""

        self.ability_stacks = {ability_id: 0 for ability_id in self.abilities}

    def ability_stack_count(self, ability_id: str) -> int:
        if ability_id not in self.abilities:
            return 0
        return self.ability_stacks.get(ability_id, 0)

    def power_bonus(self) -> int:
        """Return the current power bonus supplied by combat abilities."""

        return sum(
            ability.power_per_successful_attack * self.ability_stack_count(ability_id)
            for ability_id, ability in self.abilities.items()
        )

    @property
    def effective_power(self) -> int:
        """Return base power plus current combat-only power bonuses."""

        return self.power + self.power_bonus()

    def increment_ability_stack(self, ability_id: str) -> int:
        if ability_id not in self.abilities:
            return 0
        next_value = self.ability_stack_count(ability_id) + 1
        self.ability_stacks[ability_id] = next_value
        return next_value

    def skill_uses_remaining(self, skill_id: str) -> int:
        skill = self.skills.get(skill_id)
        if skill is None:
            return 0
        limit = skill.uses_per_turn or skill.uses_per_battle
        return max(0, limit - self.skill_uses.get(skill_id, 0))

    def consume_skill(self, skill_id: str) -> bool:
        if self.skill_uses_remaining(skill_id) <= 0:
            return False
        self.skill_uses[skill_id] = self.skill_uses.get(skill_id, 0) + 1
        return True
