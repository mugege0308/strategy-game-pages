"""Small connection layer between strategic invasions and BattleEngine."""

from __future__ import annotations

from .engine import BattleEngine
from .models import Faction, Position, Unit
from .strategy import InvasionBattleResult, InvasionPreparation, InvasionWinner


ATTACKER_UNIT_ID = "strategy_attacker"
DEFENDER_UNIT_ID = "strategy_defender"


def create_invasion_battle(preparation: InvasionPreparation) -> BattleEngine:
    """Create the temporary one-unit battle used by Phase 10B."""

    if preparation.attacking_troops < 1 or preparation.defending_troops < 1:
        raise ValueError("a battle requires positive attacker and defender troops")
    return BattleEngine(
        (
            Unit(
                ATTACKER_UNIT_ID,
                "侵攻軍",
                Faction.ALLY,
                Position(8, 10),
                troops=preparation.attacking_troops,
                max_troops=preparation.attacking_troops,
            ),
            Unit(
                DEFENDER_UNIT_ID,
                "防衛軍",
                Faction.ENEMY,
                Position(9, 10),
                troops=preparation.defending_troops,
                max_troops=preparation.defending_troops,
            ),
        )
    )


def result_from_battle(
    preparation: InvasionPreparation,
    battle: BattleEngine,
) -> InvasionBattleResult:
    """Extract a completed BattleEngine result without changing strategic state."""

    if not isinstance(preparation, InvasionPreparation):
        raise ValueError("invalid invasion preparation")
    if not battle.game_over or battle.winner is None:
        raise ValueError("the invasion battle is not complete")
    try:
        attacker = battle.get_unit(ATTACKER_UNIT_ID)
        defender = battle.get_unit(DEFENDER_UNIT_ID)
    except KeyError as exc:
        raise ValueError("the battle does not contain the invasion units") from exc
    if (
        attacker.faction is not Faction.ALLY
        or defender.faction is not Faction.ENEMY
        or attacker.max_troops != preparation.attacking_troops
        or defender.max_troops != preparation.defending_troops
    ):
        raise ValueError("the battle units do not match the invasion preparation")
    winner = (
        InvasionWinner.ATTACKER
        if battle.winner is Faction.ALLY
        else InvasionWinner.DEFENDER
    )
    return InvasionBattleResult(
        preparation=preparation,
        winner=winner,
        attacker_survivors=attacker.troops,
        defender_survivors=defender.troops,
    )
