"""Japanese-friendly Pygame frontend for :mod:`battle_game.engine`.

The UI owns only presentation state (selection, hover, scroll position, and
pending skill choices).  All battle-state changes continue to go through the
public :class:`~battle_game.engine.BattleEngine` API.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import math
import sys
from types import SimpleNamespace
from typing import Any, Optional

from .ai import SimpleEnemyAI
from .combat import calculate_damage
from .engine import ActionResult, BattleEngine
from .models import Faction, Position, Unit
from .skills import BOOGIE_WOOGIE_ID, EXCALIBUR_ID, AttackDirection
from .ui_text import (
    display_name,
    direction_label,
    faction_label,
    find_japanese_font,
    load_font,
    localize_message,
    map_unit_label,
    skill_status,
    unit_marker,
)
from .web_input import PointerDeduplicator, normalized_touch_position, pointer_down_position


LayoutRect = tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class BattleLayout:
    """Client-area coordinates for one battle window size."""

    window_size: tuple[int, int]
    grid_origin: tuple[int, int]
    cell_size: int
    grid_rect: LayoutRect
    panel_rect: LayoutRect
    message_rect: LayoutRect
    unit_info_rect: LayoutRect
    boogie_button: LayoutRect
    excalibur_button: LayoutRect
    direction_buttons: tuple[tuple[AttackDirection, LayoutRect], ...]
    action_button: LayoutRect
    turn_button: LayoutRect
    return_button: LayoutRect
    log_rect: LayoutRect
    log_toggle_button: LayoutRect = (0, 0, 0, 0)
    stacked: bool = False


class PygameBattleApp:
    """Mouse-driven frontend; all rule decisions remain in the engine."""

    # Public compatibility geometry for the original 1200x800 demo.
    GRID_ORIGIN = (20, 20)
    CELL_SIZE = 34
    PANEL_X = 720
    SCREEN_SIZE = (1200, 800)
    PANEL_RECT = (PANEL_X, 16, 460, 768)
    BOOGIE_BUTTON = (740, 390, 200, 34)
    EXCALIBUR_BUTTON = (960, 390, 200, 34)
    DIRECTION_BUTTONS = (
        (AttackDirection.UP, (740, 435, 42, 34)),
        (AttackDirection.DOWN, (788, 435, 42, 34)),
        (AttackDirection.LEFT, (836, 435, 42, 34)),
        (AttackDirection.RIGHT, (884, 435, 42, 34)),
    )
    ACTION_BUTTON = (740, 490, 200, 42)
    TURN_BUTTON = (960, 490, 200, 42)
    RETURN_BUTTON = (960, 540, 200, 42)
    AI_ACTION_DELAY_MS = 450
    LOG_LIMIT = 8

    def __init__(
        self,
        engine: Optional[BattleEngine] = None,
        *,
        return_on_game_over: bool = False,
    ) -> None:
        self.engine = engine or BattleEngine.demo()
        self.return_on_game_over = return_on_game_over
        self.return_requested = False
        self.enemy_ai = SimpleEnemyAI()
        self.ai_next_action_at = 0
        self.selected_id: Optional[str] = None
        self.hovered_id: Optional[str] = None
        self.inspected_id: Optional[str] = None
        self.pending_skill_id: Optional[str] = None
        self.pending_direction: Optional[AttackDirection] = None
        self.pending_swap_ids: list[str] = []
        self.message = ""
        self.log: deque[str] = deque(maxlen=self.LOG_LIMIT)
        self.log_scroll = 0
        self.log_collapsed = False
        self._pointer_deduplicator = PointerDeduplicator()
        self.map_zoom = 1.0
        self.map_pan = [0.0, 0.0]
        self._pointer_down_position: Optional[tuple[int, int]] = None
        self._pointer_last_position: Optional[tuple[int, int]] = None
        self._pointer_dragging = False
        self._pointer_down_in_map = False
        self._pointer_source = "mouse"
        self._touch_points: dict[int, tuple[int, int]] = {}
        self._pinch_distance: Optional[float] = None
        self._pinch_center: Optional[tuple[int, int]] = None
        self._pinch_in_map = False
        self.window_size = self.SCREEN_SIZE
        self.layout = self.layout_for_size(
            self.window_size,
            grid_width=self.engine.width,
            grid_height=self.engine.height,
            log_collapsed=self.log_collapsed,
        )
        self._sync_compatibility_geometry()
        self._set_message(self.engine.last_message)

    @classmethod
    def layout_for_size(
        cls,
        size: tuple[int, int],
        *,
        grid_width: int = 20,
        grid_height: int = 20,
        log_collapsed: bool = False,
    ) -> BattleLayout:
        """Return a complete layout for a Pygame client area.

        Landscape clients give the square battle map as much space as possible
        while keeping a usable side panel.  Portrait clients stack the map
        above the controls, which avoids shrinking a 20x20 map into a narrow
        side column on phones.  The same rectangles are used for drawing and
        hit testing, so a resize cannot make the controls drift.
        """

        width = max(1, int(size[0]))
        height = max(1, int(size[1]))
        stacked = height > width * 1.08

        if stacked:
            margin = max(10, min(16, width // 32))
            gap = max(8, min(14, height // 70))
            # Reserve room for controls before choosing the map scale.
            panel_reserve = max(220, min(340, int(height * 0.38)))
            map_height = max(1, height - margin * 2 - gap - panel_reserve)
            cell_size = max(
                8,
                min(
                    64,
                    max(1, (width - margin * 2) // max(1, grid_width)),
                    map_height // max(1, grid_height),
                ),
            )
            grid_width_px = cell_size * grid_width
            grid_height_px = cell_size * grid_height
            grid_x = max(0, (width - grid_width_px) // 2)
            grid_y = margin
            panel_x = margin
            panel_y = grid_y + grid_height_px + gap
            panel_width = max(1, width - margin * 2)
            panel_height = max(1, height - panel_y - margin)
            panel_rect = (panel_x, panel_y, panel_width, panel_height)
            content_x = panel_x + min(14, max(8, panel_width // 30))
            content_width = max(1, panel_width - 2 * (content_x - panel_x))
            message_rect = (content_x, panel_y + 36, content_width, 30)
            info_top = panel_y + 70
            button_height = max(36, min(46, int(min(width, height) * 0.055)))
            direction_height = min(34, button_height)
        else:
            margin = max(12, min(24, min(width, height) // 40))
            panel_width = min(460, max(380, int(width * 0.30)))
            if width < 900:
                panel_width = min(360, max(300, int(width * 0.38)))
            panel_x = max(margin + grid_width * 8, width - margin - panel_width)
            panel_width = max(260, min(panel_width, width - panel_x - margin))
            panel_height = max(1, height - margin * 2)
            available_map_width = max(1, panel_x - margin * 2)
            available_map_height = max(1, height - margin * 2)
            cell_size = max(
                8,
                min(
                    64,
                    available_map_width // max(1, grid_width),
                    available_map_height // max(1, grid_height),
                ),
            )
            grid_width_px = cell_size * grid_width
            grid_height_px = cell_size * grid_height
            grid_x = margin + max(0, (available_map_width - grid_width_px) // 2)
            grid_y = margin + max(0, (available_map_height - grid_height_px) // 2)
            panel_rect = (panel_x, margin, panel_width, panel_height)
            content_x = panel_x + 12
            content_width = max(1, panel_width - 24)
            message_rect = (content_x, panel_rect[1] + 42, content_width, 38)
            info_top = panel_rect[1] + 92
            button_height = 46 if width < 900 or height < 700 else 42
            direction_height = button_height

        panel_bottom = panel_rect[1] + panel_rect[3]
        return_y = max(panel_rect[1] + 1, panel_bottom - 10 - button_height)
        action_y = max(panel_rect[1] + 1, return_y - 8 - button_height)
        half_width = max(1, (content_width - 8) // 2)
        action_button = (content_x, action_y, half_width, button_height)
        turn_button = (
            content_x + half_width + 8,
            action_y,
            max(1, content_width - half_width - 8),
            button_height,
        )
        return_button = (content_x, return_y, content_width, button_height)

        log_bottom = max(panel_rect[1] + 1, action_y - 8)
        requested_log_height = max(76, min(180, int(panel_rect[3] * 0.25)))
        control_height = 6 + direction_height + 4 + button_height
        info_min_height = 34 if stacked else 80
        max_log_height = max(
            30,
            log_bottom - (info_top + info_min_height + control_height),
        )
        log_height = 30 if log_collapsed else min(requested_log_height, max_log_height)
        log_top = max(panel_rect[1] + 1, log_bottom - log_height)
        log_rect = (content_x, log_top, content_width, max(30, log_bottom - log_top))
        toggle_width = min(104, max(76, content_width // 3))
        log_toggle_button = (
            content_x + content_width - toggle_width - 4,
            log_top + 2,
            toggle_width,
            min(26, max(20, log_rect[3] - 4)),
        )

        skill_top = max(panel_rect[1] + 1, log_top - control_height)
        boogie_button = (content_x, skill_top, half_width, button_height)
        excalibur_button = (
            content_x + half_width + 8,
            skill_top,
            max(1, content_width - half_width - 8),
            button_height,
        )
        direction_width = max(24, (content_width - 18) // 4)
        direction_y = skill_top + button_height + 4
        direction_buttons = tuple(
            (
                direction,
                (
                    content_x + index * (direction_width + 6),
                    direction_y,
                    direction_width,
                    direction_height,
                ),
            )
            for index, direction in enumerate(
                (AttackDirection.UP, AttackDirection.DOWN, AttackDirection.LEFT, AttackDirection.RIGHT)
            )
        )
        unit_info_rect = (
            content_x,
            info_top,
            content_width,
            max(1, skill_top - info_top - 8),
        )
        return BattleLayout(
            window_size=(width, height),
            grid_origin=(grid_x, grid_y),
            cell_size=cell_size,
            grid_rect=(grid_x, grid_y, grid_width_px, grid_height_px),
            panel_rect=panel_rect,
            message_rect=message_rect,
            unit_info_rect=unit_info_rect,
            boogie_button=boogie_button,
            excalibur_button=excalibur_button,
            direction_buttons=direction_buttons,
            action_button=action_button,
            turn_button=turn_button,
            return_button=return_button,
            log_rect=log_rect,
            log_toggle_button=log_toggle_button,
            stacked=stacked,
        )

    def _sync_compatibility_geometry(self) -> None:
        """Expose the current layout through the old public geometry names."""

        layout = self.layout
        self.GRID_ORIGIN = layout.grid_origin
        self.CELL_SIZE = layout.cell_size
        self.PANEL_X = layout.panel_rect[0]
        self.PANEL_RECT = layout.panel_rect
        self.BOOGIE_BUTTON = layout.boogie_button
        self.EXCALIBUR_BUTTON = layout.excalibur_button
        self.DIRECTION_BUTTONS = layout.direction_buttons
        self.ACTION_BUTTON = layout.action_button
        self.TURN_BUTTON = layout.turn_button
        self.RETURN_BUTTON = layout.return_button

    def set_window_size(self, size: tuple[int, int]) -> None:
        """Recompute drawing and hit-test coordinates after a resize."""

        width = max(1, int(size[0]))
        height = max(1, int(size[1]))
        was_stacked = self.layout.stacked
        becomes_stacked = height > width * 1.08
        if becomes_stacked and not self.layout.stacked:
            self.log_collapsed = True
        self.window_size = (width, height)
        self.layout = self.layout_for_size(
            self.window_size,
            grid_width=self.engine.width,
            grid_height=self.engine.height,
            log_collapsed=self.log_collapsed,
        )
        self._sync_compatibility_geometry()
        self.hovered_id = None
        if becomes_stacked and not was_stacked:
            self.map_zoom = 1.35
            self.map_pan = [0.0, 0.0]
        elif not becomes_stacked:
            self.map_zoom = 1.0
            self.map_pan = [0.0, 0.0]
        self._clamp_map_pan()

    @staticmethod
    def _initial_window_size(pygame: Any) -> tuple[int, int]:
        """Choose a client size that leaves room for the Windows taskbar."""

        web_size = PygameBattleApp._browser_viewport_size()
        if web_size is not None:
            return web_size

        desktop_width, desktop_height = (1366, 768)
        try:
            sizes = pygame.display.get_desktop_sizes()
            if sizes:
                desktop_width, desktop_height = sizes[0]
        except (AttributeError, IndexError, TypeError, pygame.error):
            pass
        return (
            min(1600, max(800, int(desktop_width) - 40)),
            min(1000, max(560, int(desktop_height) - 100)),
        )

    @staticmethod
    def _browser_viewport_size(browser_platform: Any = None) -> Optional[tuple[int, int]]:
        """Return the CSS viewport size exposed by Pygbag, when available.

        Pygbag sizes the visible canvas from the browser viewport but does not
        reliably deliver a Pygame ``VIDEORESIZE`` event on mobile rotation.
        Keeping this bridge small lets the Windows path remain unchanged while
        allowing the web loop to resynchronise its logical layout.
        """

        if sys.platform != "emscripten":
            return None
        try:
            if browser_platform is None:
                import platform as browser_platform

            window = browser_platform.window
            width = int(window.innerWidth)
            height = int(window.innerHeight)
            if width <= 0 or height <= 0:
                return None
            return max(1, width), max(1, height)
        except (AttributeError, TypeError, ValueError, ImportError):
            return None

    def run(self) -> BattleEngine:
        try:
            import pygame
        except ImportError as exc:
            raise RuntimeError(
                "Pygame-CE is required to run the UI. Install dependencies with "
                "python -m pip install -r requirements.txt."
            ) from exc

        pygame.init()
        initial_size = self._initial_window_size(pygame)
        screen = pygame.display.set_mode(initial_size, pygame.RESIZABLE)
        self.set_window_size(screen.get_size())
        pygame.display.set_caption("ターン制戦闘プロトタイプ")
        clock = pygame.time.Clock()
        font_path = find_japanese_font(pygame)
        fonts = {
            "title": load_font(pygame, font_path, 30),
            "normal": load_font(pygame, font_path, 21),
            "small": load_font(pygame, font_path, 17),
            "button": load_font(pygame, font_path, 19),
            "cell": load_font(pygame, font_path, 20),
            "tiny": load_font(pygame, font_path, 13),
        }
        running = True
        while running and not self.return_requested:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.VIDEORESIZE:
                    self.set_window_size(event.size)
                    screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
                elif event.type == getattr(pygame, "WINDOWSIZECHANGED", -1):
                    self.set_window_size(screen.get_size())
                elif event.type == pygame.MOUSEMOTION:
                    self._handle_pointer_motion(event.pos, pygame)
                elif event.type == pygame.MOUSEWHEEL:
                    self._handle_scroll(event.y, pygame.mouse.get_pos())
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if getattr(event, "button", None) == 3:
                        self._handle_mouse_button(event, pygame)
                        continue
                    position = pointer_down_position(
                        event,
                        self.window_size,
                        mouse_button_down_type=pygame.MOUSEBUTTONDOWN,
                        finger_down_type=getattr(pygame, "FINGERDOWN", None),
                    )
                    if position is not None:
                        self._handle_pointer_down(position, pygame)
                elif event.type == getattr(pygame, "MOUSEBUTTONUP", -1):
                    if getattr(event, "button", None) == 1:
                        self._handle_pointer_up(event.pos, pygame)
                elif event.type == getattr(pygame, "FINGERMOTION", -1):
                    self._handle_touch_motion(
                        normalized_touch_position(event.x, event.y, self.window_size),
                        pygame,
                        getattr(event, "finger_id", getattr(event, "fingerid", 0)),
                    )
                elif event.type == getattr(pygame, "FINGERDOWN", -1):
                    position = pointer_down_position(
                        event,
                        self.window_size,
                        mouse_button_down_type=pygame.MOUSEBUTTONDOWN,
                        finger_down_type=getattr(pygame, "FINGERDOWN", None),
                    )
                    if position is not None:
                        self._handle_touch_down(
                            position,
                            pygame,
                            getattr(event, "finger_id", getattr(event, "fingerid", 0)),
                        )
                elif event.type == getattr(pygame, "FINGERUP", -1):
                    self._handle_touch_up(
                        normalized_touch_position(event.x, event.y, self.window_size),
                        pygame,
                        getattr(event, "finger_id", getattr(event, "fingerid", 0)),
                    )
                elif event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        if self.engine.game_over and not self.return_requested:
                            self.return_requested = True
                    elif event.key == pygame.K_ESCAPE:
                        if self.engine.turn_side is Faction.ALLY and not self.engine.game_over:
                            self._cancel_pending_selection()
            # Some Windows/DPI combinations change the client size without a
            # reliable VIDEORESIZE event.
            actual_size = screen.get_size()
            if actual_size != self.window_size:
                self.set_window_size(actual_size)

            # Pygbag's JavaScript runtime resizes the CSS canvas on browser
            # rotation, but pygame-ce 2D does not consistently receive a
            # VIDEORESIZE event for that change.  Polling the CSS viewport is
            # cheap and keeps drawing, hit testing, and the canvas aspect ratio
            # aligned on Android Chrome.
            web_size = self._browser_viewport_size()
            if web_size is not None and web_size != self.window_size:
                screen = pygame.display.set_mode(web_size, pygame.RESIZABLE)
                self.set_window_size(screen.get_size())

            self._run_enemy_ai(pygame.time.get_ticks())
            self._draw(screen, fonts, pygame)
            pygame.display.flip()
            clock.tick(60)
        pygame.quit()
        return self.engine

    def _dispatch_pointer_down(self, position: tuple[int, int], pygame: Any, event: Any) -> None:
        """Send mouse/touch taps through one action path without duplicates."""

        clock = getattr(pygame, "time", None)
        get_ticks = getattr(clock, "get_ticks", None)
        time_ms = int(get_ticks()) if callable(get_ticks) else None
        if not self._pointer_deduplicator.accept(position, time_ms):
            return
        if getattr(event, "button", 1) == 3:
            self._handle_mouse_button(event, pygame)
            return
        self._handle_mouse_button(SimpleNamespace(button=1, pos=position), pygame)

    def _handle_pointer_down(
        self,
        position: tuple[int, int],
        pygame: Any,
        *,
        source: str = "mouse",
    ) -> None:
        """Begin a tap or map drag without changing battle state yet."""

        self._pointer_down_position = position
        self._pointer_last_position = position
        self._pointer_dragging = False
        self._pointer_down_in_map = self._point_in_rect(position, self.layout.grid_rect)
        self._pointer_source = source

    def _handle_pointer_motion(
        self,
        position: tuple[int, int],
        pygame: Any,
        *,
        source: str = "mouse",
    ) -> None:
        """Update hover state or pan the map while a pointer is held."""

        if self._pointer_down_position is None:
            self._update_hover(position)
            return
        if self._pointer_last_position is None:
            self._pointer_last_position = position
            return

        last_x, last_y = self._pointer_last_position
        dx = position[0] - last_x
        dy = position[1] - last_y
        down_x, down_y = self._pointer_down_position
        moved_enough = math.hypot(position[0] - down_x, position[1] - down_y) >= 8
        if self._pointer_down_in_map and moved_enough:
            self._pointer_dragging = True
            self.map_pan[0] += dx
            self.map_pan[1] += dy
            self._clamp_map_pan()
            self.hovered_id = None
        elif not self._pointer_dragging:
            self._update_hover(position)
        self._pointer_last_position = position

    def _handle_pointer_up(
        self,
        position: tuple[int, int],
        pygame: Any,
        *,
        source: str = "mouse",
    ) -> None:
        """Commit a tap, or finish a map drag without selecting a cell."""

        if self._pointer_down_position is None:
            return
        was_dragging = self._pointer_dragging
        self._pointer_down_position = None
        self._pointer_last_position = None
        self._pointer_dragging = False
        self._pointer_down_in_map = False
        self._pointer_source = source
        if not was_dragging:
            self._handle_mouse_button(SimpleNamespace(button=1, pos=position), pygame)

    def _handle_touch_down(
        self,
        position: tuple[int, int],
        pygame: Any,
        touch_id: int = 0,
    ) -> None:
        self._touch_points[int(touch_id)] = position
        if len(self._touch_points) >= 2:
            points = self._active_touch_points()
            self._pinch_distance = math.dist(points[0], points[1])
            self._pinch_center = self._touch_center(points)
            self._pinch_in_map = all(
                self._point_in_rect(point, self.layout.grid_rect) for point in points
            )
            self._pointer_down_position = None
            self._pointer_last_position = None
            self._pointer_dragging = True
            return
        self._handle_pointer_down(position, pygame, source="touch")

    def _handle_touch_motion(
        self,
        position: tuple[int, int],
        pygame: Any,
        touch_id: int = 0,
    ) -> None:
        touch_id = int(touch_id)
        self._touch_points[touch_id] = position
        if len(self._touch_points) >= 2:
            points = self._active_touch_points()
            distance = math.dist(points[0], points[1])
            center = self._touch_center(points)
            if self._pinch_in_map and self._pinch_distance and distance > 1:
                self._zoom_map(
                    distance / self._pinch_distance,
                    self._pinch_center or center,
                    new_focus=center,
                )
            self._pinch_distance = distance
            self._pinch_center = center
            return
        self._handle_pointer_motion(position, pygame, source="touch")

    def _handle_touch_up(
        self,
        position: tuple[int, int],
        pygame: Any,
        touch_id: int = 0,
    ) -> None:
        touch_id = int(touch_id)
        was_pinch = len(self._touch_points) >= 2 or self._pinch_distance is not None
        self._touch_points.pop(touch_id, None)
        if was_pinch:
            self._pinch_distance = None
            self._pinch_center = None
            self._pinch_in_map = False
            self._pointer_down_position = None
            self._pointer_last_position = None
            self._pointer_dragging = False
            return
        self._handle_pointer_up(position, pygame, source="touch")

    def _active_touch_points(self) -> tuple[tuple[int, int], tuple[int, int]]:
        """Return the first two touch points in stable finger-id order."""

        points = tuple(self._touch_points[key] for key in sorted(self._touch_points)[:2])
        if len(points) < 2:
            raise ValueError("a pinch requires two active touch points")
        return points[0], points[1]

    @staticmethod
    def _touch_center(
        points: tuple[tuple[int, int], tuple[int, int]],
    ) -> tuple[int, int]:
        return (
            (points[0][0] + points[1][0]) // 2,
            (points[0][1] + points[1][1]) // 2,
        )

    def _map_geometry(self) -> tuple[tuple[int, int], int, tuple[int, int, int, int]]:
        """Return transformed map origin, cell size, and visible viewport."""

        view = self.layout.grid_rect
        cell_size = max(1, int(round(self.layout.cell_size * self.map_zoom)))
        total_width = cell_size * self.engine.width
        total_height = cell_size * self.engine.height
        origin_x = int(round(view[0] + (view[2] - total_width) / 2 + self.map_pan[0]))
        origin_y = int(round(view[1] + (view[3] - total_height) / 2 + self.map_pan[1]))
        return (origin_x, origin_y), cell_size, view

    def _clamp_map_pan(self) -> None:
        view = self.layout.grid_rect
        cell_size = max(1, int(round(self.layout.cell_size * self.map_zoom)))
        max_x = max(0, (cell_size * self.engine.width - view[2]) // 2)
        max_y = max(0, (cell_size * self.engine.height - view[3]) // 2)
        self.map_pan[0] = max(-max_x, min(max_x, self.map_pan[0]))
        self.map_pan[1] = max(-max_y, min(max_y, self.map_pan[1]))

    def _zoom_map(
        self,
        factor: float,
        focus: Optional[tuple[int, int]] = None,
        *,
        new_focus: Optional[tuple[int, int]] = None,
    ) -> None:
        """Zoom while keeping a map point under the moving pinch center.

        ``focus`` is the previous center and ``new_focus`` is the current
        center.  Mouse-wheel zoom uses the same point for both, while a pinch
        can zoom and pan at once without losing the map location between the
        user's fingers.
        """

        if not self.layout.stacked:
            return
        old_origin, old_cell, view = self._map_geometry()
        old_focus = focus or (view[0] + view[2] // 2, view[1] + view[3] // 2)
        target_focus = new_focus or old_focus
        world_x = (old_focus[0] - old_origin[0]) / max(1, old_cell)
        world_y = (old_focus[1] - old_origin[1]) / max(1, old_cell)
        new_zoom = max(1.0, min(2.5, self.map_zoom * float(factor)))
        if abs(new_zoom - self.map_zoom) < 0.001 and target_focus == old_focus:
            return
        self.map_zoom = new_zoom
        new_cell = max(1, int(round(self.layout.cell_size * self.map_zoom)))
        base_origin_x = view[0] + (view[2] - new_cell * self.engine.width) / 2
        base_origin_y = view[1] + (view[3] - new_cell * self.engine.height) / 2
        self.map_pan[0] = target_focus[0] - (base_origin_x + world_x * new_cell)
        self.map_pan[1] = target_focus[1] - (base_origin_y + world_y * new_cell)
        self._clamp_map_pan()

    def _map_world_at(self, screen_position: tuple[int, int]) -> tuple[float, float]:
        """Return continuous map coordinates under a screen position."""

        (grid_x, grid_y), cell_size, _ = self._map_geometry()
        return (
            (screen_position[0] - grid_x) / max(1, cell_size),
            (screen_position[1] - grid_y) / max(1, cell_size),
        )

    def _grid_position_at(self, mouse_position: tuple[int, int]) -> Optional[Position]:
        if not self._point_in_rect(mouse_position, self.layout.grid_rect):
            return None
        (grid_x, grid_y), cell_size, _ = self._map_geometry()
        grid_position = Position(
            math.floor((mouse_position[0] - grid_x) / cell_size),
            math.floor((mouse_position[1] - grid_y) / cell_size),
        )
        if not (0 <= grid_position.x < self.engine.width and 0 <= grid_position.y < self.engine.height):
            return None
        return grid_position

    def _handle_mouse_button(self, event: Any, pygame: Any) -> None:
        """Dispatch actions separately from non-mutating information clicks."""

        button = getattr(event, "button", None)
        if button == 3:
            self._inspect_at(event.pos)
            return
        if button != 1:
            return
        if self.engine.game_over:
            self._handle_click(event.pos, pygame)
            return
        if self.engine.turn_side is Faction.ALLY:
            self._handle_click(event.pos, pygame)

    def _set_message(self, message: str) -> None:
        localized = localize_message(message, turn_number=self.engine.turn_number)
        self.message = localized
        self.log_scroll = 0
        if not self.log or self.log[-1] != localized:
            self.log.append(localized)

    def _record_result(self, result: ActionResult) -> None:
        self._set_message(result.message)

    def _clear_pending(self) -> None:
        self.pending_skill_id = None
        self.pending_direction = None
        self.pending_swap_ids = []

    def _cancel_pending_selection(self) -> None:
        if self.pending_skill_id is None and self.pending_direction is None and not self.pending_swap_ids:
            self._set_message("選択中のスキル操作はありません。")
            return
        self._clear_pending()
        self._set_message("スキル選択をキャンセルしました。行動権は消費していません。")

    def _handle_click(self, mouse_position: tuple[int, int], pygame: Any) -> None:
        layout = self.layout
        if self.engine.game_over:
            if pygame.Rect(*layout.return_button).collidepoint(mouse_position):
                self.return_requested = True
            return
        if self.engine.turn_side is not Faction.ALLY:
            return

        x, y = mouse_position
        if pygame.Rect(*layout.log_toggle_button).collidepoint(mouse_position):
            self.log_collapsed = not self.log_collapsed
            self.set_window_size(self.window_size)
            return
        if pygame.Rect(*layout.boogie_button).collidepoint(mouse_position):
            self._select_boogie_woogie()
            return
        if pygame.Rect(*layout.excalibur_button).collidepoint(mouse_position):
            self._select_excalibur()
            return
        if self.pending_skill_id == EXCALIBUR_ID:
            for direction, rect_data in layout.direction_buttons:
                if pygame.Rect(*rect_data).collidepoint(mouse_position):
                    self._select_direction(direction)
                    return
        if pygame.Rect(*layout.action_button).collidepoint(mouse_position):
            self._finish_action()
            return
        if pygame.Rect(*layout.turn_button).collidepoint(mouse_position):
            result = self.engine.end_turn()
            self._record_result(result)
            self.selected_id = None
            self._clear_pending()
            return

        clicked_position = self._grid_position_at((x, y))
        if clicked_position is None:
            return
        clicked_unit = self._unit_at((x, y))
        if clicked_unit is not None:
            clicked_position = clicked_unit.position

        if self.pending_skill_id == BOOGIE_WOOGIE_ID:
            self._handle_swap_target_click(clicked_unit)
            return

        if clicked_unit and clicked_unit.faction is Faction.ALLY:
            if (
                self.selected_id is not None
                and clicked_unit.unit_id != self.selected_id
                and self.engine.get_unit(self.selected_id).post_attack_move_available
            ):
                self._set_message("政宗の再移動を先に完了してください。")
                return
            self.selected_id = clicked_unit.unit_id
            self.inspected_id = None
            self._clear_pending()
            self._set_message(f"{display_name(clicked_unit)}を選択しました。")
            return

        if self.selected_id is None:
            self._set_message("先に味方ユニットを選択してください。")
            return

        if clicked_unit and clicked_unit.faction is Faction.ENEMY:
            if self.pending_skill_id is None:
                result = self.engine.attack_unit(self.selected_id, clicked_unit.unit_id)
            elif self.pending_direction is None:
                self._set_message("先にエクスカリバーの攻撃方向を選択してください。")
                return
            else:
                valid_targets = self.engine.get_attackable_targets(
                    self.selected_id,
                    skill_id=self.pending_skill_id,
                    direction=self.pending_direction,
                )
                if clicked_unit.unit_id not in {unit.unit_id for unit in valid_targets}:
                    self._set_message("その敵は選択した範囲の対象外です。")
                    return
                result = self.engine.use_skill(
                    self.selected_id,
                    self.pending_skill_id,
                    direction=self.pending_direction,
                )
            self._record_result(result)
            if result.success:
                self._clear_pending()
                if self.engine.game_over:
                    self.selected_id = None
            return

        if clicked_position in self.engine.get_reachable_positions(self.selected_id):
            result = self.engine.move_unit(self.selected_id, clicked_position)
            self._record_result(result)
        else:
            self._set_message("そのマスには移動できません。")

    def _run_enemy_ai(self, now_ms: int) -> None:
        """Advance at most one enemy action without blocking the Pygame loop."""

        if self.engine.game_over or self.engine.turn_side is not Faction.ENEMY:
            self.ai_next_action_at = 0
            return
        if self.ai_next_action_at == 0:
            self.ai_next_action_at = now_ms + self.AI_ACTION_DELAY_MS
            self._set_message("敵AIが行動を考えています……")
            return
        if now_ms < self.ai_next_action_at:
            return

        self.selected_id = None
        self._clear_pending()
        result = self.enemy_ai.step(self.engine)
        if result is not None:
            self._record_result(result)
            self.ai_next_action_at = now_ms + self.AI_ACTION_DELAY_MS

    def _finish_action(self) -> None:
        if self.selected_id is None:
            self._set_message("行動を終了する味方ユニットを選択してください。")
            return
        result = self.engine.end_unit_action(self.selected_id)
        self._record_result(result)
        if result.success:
            self.selected_id = None
            self._clear_pending()

    def _handle_swap_target_click(self, clicked_unit: Optional[Unit]) -> None:
        if clicked_unit is None or clicked_unit.defeated:
            self._set_message("位置交換する生存ユニットを選択してください。")
            return
        candidates = self.engine.get_attackable_targets(
            self.selected_id,
            skill_id=BOOGIE_WOOGIE_ID,
        )
        if clicked_unit.unit_id not in {unit.unit_id for unit in candidates}:
            self._set_message("そのユニットは位置交換の範囲外です。")
            return
        if not self.pending_swap_ids:
            self.pending_swap_ids = [clicked_unit.unit_id]
            self._set_message(f"1体目：{display_name(clicked_unit)}。2体目を選択してください。")
            return
        if clicked_unit.unit_id == self.pending_swap_ids[0]:
            self._set_message("異なる2体を選択してください。")
            return
        result = self.engine.use_skill(
            self.selected_id,
            BOOGIE_WOOGIE_ID,
            (self.pending_swap_ids[0], clicked_unit.unit_id),
        )
        self._record_result(result)
        if result.success:
            self._clear_pending()
            if self.engine.game_over:
                self.selected_id = None

    def _select_excalibur(self) -> None:
        if self.selected_id is None:
            self._set_message("先に味方ユニットを選択してください。")
            return
        unit = self.engine.get_unit(self.selected_id)
        skill = unit.skills.get(EXCALIBUR_ID)
        if skill is None:
            self._set_message("このユニットはエクスカリバーを持っていません。")
            return
        if unit.action_ended or unit.attacked_this_turn:
            self._set_message("このユニットは現在スキルを使用できません。")
            return
        if unit.skill_uses_remaining(EXCALIBUR_ID) <= 0:
            self._set_message(f"{skill.name}は使用済みです。")
            return
        if self.pending_skill_id == EXCALIBUR_ID:
            self._clear_pending()
            self._set_message(f"{skill.name}の選択を解除しました。")
        else:
            self.pending_skill_id = EXCALIBUR_ID
            self.pending_direction = None
            self.pending_swap_ids = []
            self._set_message(f"{skill.name}を選択しました。攻撃方向を選んでください。")

    def _select_boogie_woogie(self) -> None:
        if self.selected_id is None:
            self._set_message("先に味方ユニットを選択してください。")
            return
        unit = self.engine.get_unit(self.selected_id)
        skill = unit.skills.get(BOOGIE_WOOGIE_ID)
        if skill is None:
            self._set_message("このユニットは不義遊戯を持っていません。")
            return
        if unit.action_ended or unit.attacked_this_turn:
            self._set_message("このユニットは現在スキルを使用できません。")
            return
        if unit.skill_uses_remaining(BOOGIE_WOOGIE_ID) <= 0:
            self._set_message(f"{skill.name}は使用済みです。")
            return
        if self.pending_skill_id == BOOGIE_WOOGIE_ID:
            self._clear_pending()
            self._set_message(f"{skill.name}の選択を解除しました。")
            return
        self.pending_skill_id = BOOGIE_WOOGIE_ID
        self.pending_direction = None
        self.pending_swap_ids = []
        self._set_message(f"{skill.name}を選択しました。交換する2体を選んでください。")

    def _select_direction(self, direction: AttackDirection) -> None:
        if self.selected_id is None or self.pending_skill_id != EXCALIBUR_ID:
            self._set_message("先にエクスカリバーを選択してください。")
            return
        targets = self.engine.get_attackable_targets(
            self.selected_id,
            skill_id=self.pending_skill_id,
            direction=direction,
        )
        if not targets:
            self.pending_direction = None
            self._set_message(f"{direction_label(direction)}方向に敵がいません。")
            return
        self.pending_direction = direction
        self._set_message(f"{direction_label(direction)}方向を選択しました。範囲内の敵を確認してください。")

    def _update_hover(self, mouse_position: tuple[int, int]) -> None:
        unit = self._unit_at(mouse_position)
        self.hovered_id = unit.unit_id if unit is not None else None

    def _inspect_at(self, mouse_position: tuple[int, int]) -> None:
        unit = self._unit_at(mouse_position)
        self.inspected_id = unit.unit_id if unit is not None else None
        if unit is not None:
            self.hovered_id = unit.unit_id

    def _handle_scroll(self, delta: int, mouse_position: tuple[int, int]) -> None:
        if delta == 0:
            return
        if self._point_in_rect(mouse_position, self.layout.grid_rect):
            self._zoom_map(1.12 if delta > 0 else 1 / 1.12, mouse_position)
            return
        if self.log_collapsed or not self._point_in_rect(mouse_position, self.layout.log_rect):
            return
        visible = max(1, (self.layout.log_rect[3] - 28) // 20)
        limit = max(0, len(self.log) - visible)
        self.log_scroll = max(0, min(limit, self.log_scroll + (1 if delta > 0 else -1)))

    def _unit_at(self, mouse_position: tuple[int, int]) -> Optional[Unit]:
        position = self._grid_position_at(mouse_position)
        if position is None:
            return None
        return next(
            (
                unit
                for unit in self.engine.units.values()
                if not unit.defeated and unit.position == position
            ),
            None,
        )

    def _info_unit(self) -> Optional[Unit]:
        for unit_id in (self.hovered_id, self.inspected_id, self.selected_id):
            if unit_id is None:
                continue
            unit = self.engine.units.get(unit_id)
            if unit is not None and not unit.defeated:
                return unit
        return None

    def _attack_preview(self) -> Optional[tuple[int, int]]:
        """Return a non-mutating reference damage and remaining troop count."""

        if self.selected_id is None or self.hovered_id is None:
            return None
        attacker = self.engine.units.get(self.selected_id)
        defender = self.engine.units.get(self.hovered_id)
        if (
            attacker is None
            or defender is None
            or attacker.defeated
            or defender.defeated
            or defender.faction is not Faction.ENEMY
        ):
            return None
        base_damage = 100
        if self.pending_skill_id == EXCALIBUR_ID:
            if self.pending_direction is None:
                return None
            skill = attacker.skills.get(EXCALIBUR_ID)
            if skill is None:
                return None
            base_damage = skill.base_damage
        elif self.pending_skill_id is not None:
            return None
        valid_targets = self.engine.get_attackable_targets(
            attacker.unit_id,
            skill_id=self.pending_skill_id,
            direction=self.pending_direction,
        )
        if defender.unit_id not in {unit.unit_id for unit in valid_targets}:
            return None
        damage = calculate_damage(attacker, defender, base_damage)
        return damage, max(0, defender.troops - damage)

    def _draw(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        screen.fill((28, 31, 38))
        self._draw_grid(screen, fonts, pygame)
        self._draw_panel(screen, fonts, pygame)
        if self.engine.game_over:
            screen_size = screen.get_size()
            overlay = pygame.Surface(screen_size, pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            screen.blit(overlay, (0, 0))
            box_width = min(560, max(320, screen_size[0] - 40))
            box_height = 220
            box = pygame.Rect(
                (screen_size[0] - box_width) // 2,
                max(24, (screen_size[1] - box_height) // 2),
                box_width,
                box_height,
            )
            pygame.draw.rect(screen, (48, 52, 64), box)
            pygame.draw.rect(screen, (220, 205, 125), box, 2)
            winner = "勝利" if self.engine.winner is Faction.ALLY else "敗北"
            text = fonts["title"].render(winner, True, (255, 230, 100))
            screen.blit(text, text.get_rect(center=(box.centerx, box.y + 42)))
            ally_troops = sum(unit.troops for unit in self.engine.units_for_side(Faction.ALLY, alive_only=True))
            enemy_troops = sum(unit.troops for unit in self.engine.units_for_side(Faction.ENEMY, alive_only=True))
            self._blit_text(
                screen,
                fonts["small"],
                f"味方の残存兵数：{ally_troops}　敵の残存兵数：{enemy_troops}",
                (box.x + 24, box.y + 82),
            )
            alive_allies = len(self.engine.units_for_side(Faction.ALLY, alive_only=True))
            alive_enemies = len(self.engine.units_for_side(Faction.ENEMY, alive_only=True))
            self._blit_text(
                screen,
                fonts["small"],
                f"生存ユニット：味方{alive_allies}体／敵{alive_enemies}体",
                (box.x + 24, box.y + 110),
            )
            self._button(
                screen,
                fonts["button"],
                pygame,
                self.layout.return_button,
                "戦略マップへ戻る" if self.return_on_game_over else "メニューへ戻る",
                enabled=True,
            )

    def _draw_grid(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        layout = self.layout
        (grid_x, grid_y), cell_size, view_rect = self._map_geometry()
        grid_width = cell_size * self.engine.width
        grid_height = cell_size * self.engine.height
        previous_clip = screen.get_clip()
        screen.set_clip(pygame.Rect(*view_rect))
        pygame.draw.rect(screen, (210, 210, 190), view_rect)

        selected_unit = None
        if self.selected_id is not None:
            selected_unit = self.engine.units.get(self.selected_id)
            if selected_unit is None or selected_unit.defeated:
                selected_unit = None
        if selected_unit is not None:
            for position in self.engine.get_reachable_positions(self.selected_id):
                rect = self._cell_rect(position, pygame)
                surface = pygame.Surface((cell_size, cell_size), pygame.SRCALPHA)
                move_color = (
                    (255, 150, 60, 115)
                    if selected_unit.post_attack_move_available
                    else (70, 150, 255, 100)
                )
                surface.fill(move_color)
                screen.blit(surface, rect.topleft)

            skill_positions: set[Position] = set()
            if self.pending_skill_id == EXCALIBUR_ID:
                directions = (
                    (self.pending_direction,)
                    if self.pending_direction is not None
                    else tuple(direction for direction, _ in layout.direction_buttons)
                )
                for direction in directions:
                    skill_positions.update(
                        self.engine.get_skill_target_positions(
                            self.selected_id,
                            EXCALIBUR_ID,
                            direction,
                        )
                    )
            for position in skill_positions:
                surface = pygame.Surface((cell_size, cell_size), pygame.SRCALPHA)
                surface.fill((255, 190, 60, 105))
                screen.blit(surface, self._cell_rect(position, pygame).topleft)

            for target in self.engine.get_attackable_targets(
                self.selected_id,
                skill_id=self.pending_skill_id,
                direction=self.pending_direction,
            ):
                rect = self._cell_rect(target.position, pygame)
                color = (255, 220, 80) if target.unit_id in self.pending_swap_ids else (245, 90, 90)
                pygame.draw.rect(screen, color, rect, max(2, cell_size // 12))

        for x in range(self.engine.width + 1):
            px = grid_x + x * cell_size
            pygame.draw.line(screen, (100, 105, 100), (px, grid_y), (px, grid_y + grid_height))
        for y in range(self.engine.height + 1):
            py = grid_y + y * cell_size
            pygame.draw.line(screen, (100, 105, 100), (grid_x, py), (grid_x + grid_width, py))

        for unit in sorted(self.engine.units.values(), key=lambda item: item.unit_id):
            if unit.defeated:
                continue
            cell_x = grid_x + unit.position.x * cell_size
            cell_y = grid_y + unit.position.y * cell_size
            center = (cell_x + cell_size // 2, cell_y + cell_size // 2)
            color = (65, 125, 235) if unit.faction is Faction.ALLY else (220, 75, 75)
            if unit.action_ended:
                color = tuple(max(40, channel // 2) for channel in color)
            radius = max(5, cell_size // 2 - max(3, cell_size // 8))
            pygame.draw.circle(screen, color, center, radius)
            if unit.unit_id == self.selected_id:
                pygame.draw.circle(screen, (255, 235, 90), center, radius + 3, max(2, cell_size // 12))
            elif unit.unit_id == self.hovered_id:
                pygame.draw.circle(screen, (240, 240, 240), center, radius + 2, 2)
            if unit.action_ended:
                arm = max(4, radius // 2)
                pygame.draw.line(screen, (220, 220, 220), (center[0] - arm, center[1] - arm), (center[0] + arm, center[1] + arm), 2)
                pygame.draw.line(screen, (220, 220, 220), (center[0] + arm, center[1] - arm), (center[0] - arm, center[1] + arm), 2)

            marker = unit_marker(unit)
            map_label = map_unit_label(unit, self.engine.units.values())
            marker_font = fonts["cell"]
            if marker_font.size(map_label)[0] > max(8, cell_size - 4):
                marker_font = fonts["tiny"]
            label_for_cell = map_label
            if marker_font.size(label_for_cell)[0] > max(8, cell_size - 4):
                label_for_cell = marker
            text = marker_font.render(label_for_cell, True, (255, 255, 255))
            screen.blit(text, text.get_rect(center=center))
            if label_for_cell == marker and map_label != marker:
                suffix = map_label[len(marker):] if map_label.startswith(marker) else "?"
                badge = fonts["tiny"].render(suffix, True, (255, 255, 255))
                badge_rect = badge.get_rect(topright=(cell_x + cell_size - 2, cell_y + 2))
                pygame.draw.rect(screen, (25, 28, 34), badge_rect.inflate(4, 2))
                screen.blit(badge, badge_rect)
            self._draw_troop_bar(screen, pygame, unit, cell_x, cell_y, cell_size)
        screen.set_clip(previous_clip)
        pygame.draw.rect(screen, (120, 125, 120), pygame.Rect(*view_rect), 2)

    @staticmethod
    def _draw_troop_bar(
        screen: Any,
        pygame: Any,
        unit: Unit,
        cell_x: int,
        cell_y: int,
        cell_size: int,
    ) -> None:
        background_rect, fill_rect = PygameBattleApp.troop_bar_geometry(
            cell_x,
            cell_y,
            cell_size,
            unit.troops,
            unit.max_troops,
        )
        bar_x, bar_y, bar_width, bar_height = background_rect
        background = pygame.Rect(bar_x, bar_y, bar_width, bar_height)
        pygame.draw.rect(screen, (30, 32, 36), background)
        if fill_rect[2] > 0:
            fill = pygame.Rect(*fill_rect)
            color = (80, 210, 120) if unit.faction is Faction.ALLY else (235, 105, 95)
            pygame.draw.rect(screen, color, fill)
        pygame.draw.rect(screen, (230, 230, 230), background, 1)

    @staticmethod
    def troop_bar_geometry(
        cell_x: int,
        cell_y: int,
        cell_size: int,
        troops: int,
        max_troops: int,
    ) -> tuple[LayoutRect, LayoutRect]:
        """Return background/fill rectangles without touching battle state."""

        if max_troops <= 0:
            raise ValueError("max_troops must be positive")
        bar_width = max(8, cell_size - 8)
        bar_height = max(3, min(6, cell_size // 6))
        bar_x = cell_x + (cell_size - bar_width) // 2
        bar_y = cell_y + cell_size - bar_height - max(2, cell_size // 12)
        ratio = max(0.0, min(1.0, troops / max_troops))
        fill_width = 0 if ratio <= 0 else max(1, int(bar_width * ratio))
        return (
            (bar_x, bar_y, bar_width, bar_height),
            (bar_x, bar_y, fill_width, bar_height),
        )

    def _draw_panel(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        layout = self.layout
        panel = pygame.Rect(*layout.panel_rect)
        pygame.draw.rect(screen, (45, 49, 59), panel)
        pygame.draw.rect(screen, (110, 115, 125), panel, 2)
        left = panel.x + 20 if panel.width >= 400 else panel.x + 12
        right_width = max(80, panel.width - (left - panel.x) - 16)
        side_text = faction_label(self.engine.turn_side)
        if self.engine.turn_side is Faction.ENEMY and not self.engine.game_over:
            side_text += "（AI）"
        self._blit_text(screen, fonts["title"], f"第{self.engine.turn_number}ターン：{side_text}", (left, panel.y + 10))
        self._blit_wrapped(
            screen,
            fonts["small"],
            self.message,
            layout.message_rect[0],
            layout.message_rect[1] + 2,
            layout.message_rect[2],
            20,
            max_lines=2,
        )

        info_unit = self._info_unit()
        if info_unit is not None:
            self._draw_unit_info(screen, fonts, pygame, info_unit)
        else:
            self._blit_text(screen, fonts["normal"], "【操作ガイド】", (left, layout.unit_info_rect[1] + 8))
            guide = (
                "味方ユニットをクリック：選択\n"
                "青いマス：移動　赤枠：攻撃対象\n"
                "敵にホバー／右クリック：情報確認\n"
                "Esc：スキル選択をキャンセル"
            )
            self._blit_wrapped(
                screen,
                fonts["small"],
                guide,
                left,
                layout.unit_info_rect[1] + 42,
                right_width,
                22,
                max_lines=6,
            )

        player_turn = self.engine.turn_side is Faction.ALLY and not self.engine.game_over
        compact_controls = layout.boogie_button[2] < 180
        if self.selected_id is not None:
            unit = self.engine.units.get(self.selected_id)
            if unit is not None:
                if BOOGIE_WOOGIE_ID in unit.skills:
                    skill = unit.skills[BOOGIE_WOOGIE_ID]
                    available = unit.skill_uses_remaining(BOOGIE_WOOGIE_ID) > 0
                    self._button(
                        screen,
                        fonts["button"],
                        pygame,
                        layout.boogie_button,
                        f"不義：{'可' if available else '済'}"
                        if compact_controls
                        else f"不義遊戯：{'可' if available else '済'}",
                        enabled=player_turn and available and not unit.attacked_this_turn and not unit.action_ended,
                        selected=self.pending_skill_id == BOOGIE_WOOGIE_ID,
                    )
                if EXCALIBUR_ID in unit.skills:
                    skill = unit.skills[EXCALIBUR_ID]
                    available = unit.skill_uses_remaining(EXCALIBUR_ID) > 0
                    self._button(
                        screen,
                        fonts["button"],
                        pygame,
                        layout.excalibur_button,
                        f"エクス：{'可' if available else '済'}"
                        if compact_controls
                        else f"エクスカリバー：{'可' if available else '済'}",
                        enabled=player_turn and available and not unit.attacked_this_turn and not unit.action_ended,
                        selected=self.pending_skill_id == EXCALIBUR_ID,
                    )
                    if self.pending_skill_id == EXCALIBUR_ID:
                        for direction, rect_data in layout.direction_buttons:
                            has_target = bool(
                                self.engine.get_attackable_targets(
                                    self.selected_id,
                                    skill_id=EXCALIBUR_ID,
                                    direction=direction,
                                )
                            )
                            self._button(
                                screen,
                                fonts["button"],
                                pygame,
                                rect_data,
                                direction_label(direction),
                                enabled=player_turn and has_target,
                                selected=direction is self.pending_direction,
                            )

        selected_unit = self.engine.units.get(self.selected_id) if self.selected_id else None
        action_label = (
            ("再移動終了" if layout.action_button[2] < 180 else "再移動せず終了")
            if selected_unit is not None and selected_unit.post_attack_move_available
            else "行動終了"
        )
        self._button(
            screen,
            fonts["button"],
            pygame,
            layout.action_button,
            action_label,
            enabled=player_turn and selected_unit is not None,
        )
        self._button(
            screen,
            fonts["button"],
            pygame,
            layout.turn_button,
            "ターン終了",
            enabled=player_turn,
        )
        self._draw_log(screen, fonts, pygame)

    def _draw_unit_info(self, screen: Any, fonts: dict[str, Any], pygame: Any, unit: Unit) -> None:
        rect = pygame.Rect(*self.layout.unit_info_rect)
        previous_clip = screen.get_clip()
        screen.set_clip(rect)
        left = rect.x + 8
        y = rect.y + 6
        heading = "【選択ユニット】" if unit.unit_id == self.selected_id else "【ユニット情報】"
        self._blit_text(screen, fonts["small"], heading, (left, y))
        self._blit_text(screen, fonts["normal"], display_name(unit), (left, y + 21), (255, 230, 120))
        faction_color = (125, 180, 255) if unit.faction is Faction.ALLY else (255, 140, 130)
        self._blit_text(screen, fonts["small"], f"所属：{faction_label(unit.faction)}", (left, y + 45), faction_color)
        bar_rect = pygame.Rect(left, y + 67, max(80, rect.width - 24), 8)
        pygame.draw.rect(screen, (30, 32, 36), bar_rect)
        ratio = max(0.0, min(1.0, unit.troops / unit.max_troops))
        if ratio > 0:
            pygame.draw.rect(
                screen,
                (80, 210, 120) if unit.faction is Faction.ALLY else (235, 105, 95),
                (bar_rect.x, bar_rect.y, max(1, int(bar_rect.width * ratio)), bar_rect.height),
            )
        pygame.draw.rect(screen, (230, 230, 230), bar_rect, 1)
        self._blit_text(screen, fonts["small"], f"兵数：{unit.troops} / {unit.max_troops}", (left, y + 80))
        self._blit_wrapped(
            screen,
            fonts["small"],
            f"出力：{unit.effective_power}　耐久：{unit.defense}",
            left,
            y + 103,
            max(40, rect.width - 16),
            18,
            max_lines=2,
        )
        self._blit_wrapped(
            screen,
            fonts["small"],
            f"機動：{unit.move}　射程：{unit.attack_range}",
            left,
            y + 126,
            max(40, rect.width - 16),
            18,
            max_lines=2,
        )
        move_state = "済" if unit.moved_this_turn else "可能"
        attack_state = "済" if unit.attacked_this_turn else "可能"
        action_state = "終了" if unit.action_ended else "継続中"
        self._blit_wrapped(
            screen,
            fonts["small"],
            f"移動：{move_state}　攻撃：{attack_state}　行動：{action_state}",
            left,
            y + 149,
            max(40, rect.width - 16),
            18,
            max_lines=2,
        )
        self._blit_text(screen, fonts["small"], "【固有能力・スキル】", (left, y + 172))
        ability_y = y + 195
        lines = []
        for skill in unit.skills.values():
            limit = skill.uses_per_turn or skill.uses_per_battle
            remaining = unit.skill_uses_remaining(skill.skill_id)
            lines.append(f"{skill.name}：{skill_status(remaining > 0)}（残り{remaining}/{limit}）")
        for ability in unit.abilities.values():
            if ability.power_per_successful_attack > 0:
                lines.append(f"{ability.name}：{unit.ability_stack_count(ability.ability_id)}スタック")
            elif ability.guard is not None:
                guard = ability.guard
                lines.append(
                    f"{ability.name}（常時）：周囲{guard.radius}マス・被ダメージ{guard.damage_reduction_percent}%軽減"
                )
                lines.append(
                    f"致死時は{guard.lethal_share_percent}%を肩代わり・回数制限なし"
                )
            elif unit.post_attack_move_available:
                lines.append(f"{ability.name}：再移動可能（{unit.post_attack_move_range}）")
            elif unit.post_attack_move_used:
                lines.append(f"{ability.name}：再移動済み")
            else:
                lines.append(f"{ability.name}：攻撃後再移動")
        if not lines:
            lines.append("なし")
        for line in lines:
            wrapped = self._wrap_text(line, fonts["small"], max(40, rect.width - 16))
            for wrapped_line in wrapped[:2]:
                self._blit_text(screen, fonts["small"], wrapped_line, (left, ability_y))
                ability_y += 18

        preview = self._attack_preview()
        if preview is not None:
            damage, remaining = preview
            self._blit_text(
                screen,
                fonts["small"],
                f"予測ダメージ（参考）：{damage}　敵兵数：{remaining}",
                (left, ability_y + 2),
                (255, 220, 150),
            )
        screen.set_clip(previous_clip)

    def _draw_log(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        rect = pygame.Rect(*self.layout.log_rect)
        previous_clip = screen.get_clip()
        screen.set_clip(rect)
        pygame.draw.rect(screen, (34, 38, 47), rect)
        pygame.draw.rect(screen, (100, 105, 115), rect, 1)
        left = rect.x + 8
        title = "【戦闘ログ】（折りたたみ）" if self.log_collapsed else "【戦闘ログ】"
        self._blit_text(screen, fonts["small"], title, (left, rect.y + 5))
        self._button(
            screen,
            fonts["tiny"],
            pygame,
            self.layout.log_toggle_button,
            "ログを開く" if self.log_collapsed else "ログを閉じる",
        )
        if self.log_collapsed:
            screen.set_clip(previous_clip)
            return
        all_lines: list[str] = []
        for entry in self.log:
            wrapped = self._wrap_text(entry, fonts["small"], max(40, rect.width - 24))
            all_lines.extend(["・" + wrapped[0], *["  " + line for line in wrapped[1:]]])
        visible = max(1, (rect.height - 30) // 20)
        max_scroll = max(0, len(all_lines) - visible)
        self.log_scroll = max(0, min(max_scroll, self.log_scroll))
        start = max(0, max_scroll - self.log_scroll)
        for index, line in enumerate(all_lines[start : start + visible]):
            self._blit_text(screen, fonts["small"], line, (left, rect.y + 30 + index * 20), (215, 215, 220))
        screen.set_clip(previous_clip)

    def _cell_rect(self, position: Position, pygame: Any) -> Any:
        (grid_x, grid_y), cell_size, _ = self._map_geometry()
        return pygame.Rect(
            grid_x + position.x * cell_size,
            grid_y + position.y * cell_size,
            cell_size,
            cell_size,
        )

    @staticmethod
    def _point_in_rect(point: tuple[int, int], rect: LayoutRect) -> bool:
        x, y = point
        return rect[0] <= x < rect[0] + rect[2] and rect[1] <= y < rect[1] + rect[3]

    @staticmethod
    def _blit_text(screen: Any, font: Any, text: str, position: tuple[int, int], color=(235, 235, 235)) -> None:
        screen.blit(font.render(text, True, color), position)

    @staticmethod
    def _wrap_text(text: str, font: Any, max_width: int) -> list[str]:
        lines: list[str] = []
        for paragraph in text.split("\n"):
            current = ""
            for character in paragraph:
                candidate = current + character
                if current and font.size(candidate)[0] > max_width:
                    lines.append(current)
                    current = character
                else:
                    current = candidate
            lines.append(current)
        return lines or [""]

    def _blit_wrapped(
        self,
        screen: Any,
        font: Any,
        text: str,
        x: int,
        y: int,
        max_width: int,
        line_height: int,
        *,
        max_lines: Optional[int] = None,
    ) -> None:
        lines = self._wrap_text(text, font, max_width)
        if max_lines is not None:
            lines = lines[:max_lines]
        for line in lines:
            self._blit_text(screen, font, line, (x, y))
            y += line_height

    @staticmethod
    def _button(
        screen: Any,
        font: Any,
        pygame: Any,
        rect_data: LayoutRect,
        label: str,
        *,
        enabled: bool = True,
        selected: bool = False,
    ) -> None:
        rect = pygame.Rect(*rect_data)
        if not enabled:
            fill = (65, 68, 78)
            border = (100, 100, 110)
            text_color = (130, 130, 140)
        elif selected:
            fill = (135, 105, 45)
            border = (255, 215, 90)
            text_color = (255, 255, 255)
        else:
            fill = (80, 95, 120)
            border = (170, 180, 200)
            text_color = (255, 255, 255)
        pygame.draw.rect(screen, fill, rect)
        pygame.draw.rect(screen, border, rect, 2)
        text = font.render(label, True, text_color)
        screen.blit(text, text.get_rect(center=rect.center))
