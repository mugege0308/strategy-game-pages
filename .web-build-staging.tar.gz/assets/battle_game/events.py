"""Small event-hook layer used by the battle engine.

This is intentionally not a general-purpose ability framework.  It provides
named extension points, ordered callback dispatch, and the minimum result
controls needed for future character abilities.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .models import Position, Unit
from .skills import AttackDirection

EVENT_NAMES = (
    "on_turn_start",
    "before_move",
    "after_move",
    "before_swap",
    "after_swap",
    "before_attack",
    "after_attack",
    "before_damage",
    "after_damage",
    "on_lethal",
    "on_defeat",
)


@dataclass(slots=True)
class EventContext:
    """Mutable data passed to one event callback.

    ``actor``/``unit`` identify the unit taking the action.  Attack events also
    expose ``attacker`` and ``defender``.  Movement events expose the two
    positions.  ``damage`` is the current proposed damage for damage events.

    EventResult is the preferred way to cancel, replace damage, or prevent a
    lethal result.  Callbacks may update their context metadata and may update
    ability-owned runtime state, but they should not directly commit protected
    engine state such as action flags, skill-use counts, positions, or troops.
    Public actions are transactional at the engine boundary: a failed action
    or callback exception restores engine-managed state while preserving the
    existing Unit objects.  ``metadata`` is a small, intentionally open-ended
    escape hatch for future abilities; the engine currently reads ``end_action``
    after ``after_attack``.

    Callbacks must not call another public action on the same BattleEngine
    while an action is being resolved.  Such re-entry is rejected with a
    failed ActionResult.  ``on_defeat`` is a post-confirmation notification;
    direct revival from that event is not supported.
    """

    event_name: str
    engine: Any
    actor: Optional[Unit] = None
    unit: Optional[Unit] = None
    target: Optional[Unit] = None
    targets: tuple[Unit, ...] = ()
    attacker: Optional[Unit] = None
    defender: Optional[Unit] = None
    from_position: Optional[Position] = None
    to_position: Optional[Position] = None
    direction: Optional[AttackDirection] = None
    damage: int = 0
    cancelled: bool = False
    prevent_defeat: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EventResult:
    """Optional callback return value.

    ``cancel`` cancels the current operation.  On ``before_damage`` this means
    zero damage; on ``on_lethal`` it also prevents defeat.  ``damage`` replaces
    the proposed damage.  ``prevent_defeat`` is intended for ``on_lethal``.
    """

    cancel: bool = False
    damage: Optional[int] = None
    prevent_defeat: bool = False


EventHook = Callable[[EventContext], Optional[EventResult]]


class EventDispatcher:
    """Dispatch registered hooks in registration order.

    A dispatcher can be shared by multiple battles.  Battle-local internal
    handlers must check ``context.engine`` before changing state; external
    hooks receive every dispatched context by design.
    """

    def __init__(self) -> None:
        self._hooks: dict[str, list[EventHook]] = {name: [] for name in EVENT_NAMES}
        self.history: list[str] = []

    def register(self, event_name: str, hook: EventHook) -> None:
        if event_name not in self._hooks:
            raise ValueError(f"unknown event: {event_name}")
        self._hooks[event_name].append(hook)

    def unregister(self, event_name: str, hook: EventHook) -> None:
        if event_name not in self._hooks:
            raise ValueError(f"unknown event: {event_name}")
        self._hooks[event_name].remove(hook)

    def dispatch(self, event_name: str, context: EventContext) -> EventContext:
        if event_name not in self._hooks:
            raise ValueError(f"unknown event: {event_name}")
        context.event_name = event_name
        self.history.append(event_name)
        for hook in tuple(self._hooks[event_name]):
            result = hook(context)
            if result is None:
                continue
            if result.cancel:
                context.cancelled = True
            if result.prevent_defeat:
                context.prevent_defeat = True
            if result.damage is not None:
                context.damage = max(0, int(result.damage))
        return context
