"""Pygame setup screens for free-form multi-unit battles."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from .free_battle import FreeBattleConfiguration, PlacementRules, create_free_battle
from .models import Faction, Position, Unit
from .ui import PygameBattleApp
from .ui_text import find_japanese_font, load_font


LayoutRect = tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class FreeBattleLayout:
    window_size: tuple[int, int]
    ally_panel: LayoutRect
    enemy_panel: LayoutRect
    ally_slots: tuple[LayoutRect, ...]
    enemy_slots: tuple[LayoutRect, ...]
    ally_add: LayoutRect
    ally_remove: LayoutRect
    enemy_add: LayoutRect
    enemy_remove: LayoutRect
    confirm: LayoutRect
    menu: LayoutRect
    grid_rect: LayoutRect
    placement_units: tuple[LayoutRect, ...]
    auto_place: LayoutRect
    start: LayoutRect
    back: LayoutRect


class FreeBattleApp:
    """Compose, place, and launch one free battle.

    The composition and placement state is deliberately separate from the
    ``BattleEngine``.  Once confirmed, the normal battle UI is reused without
    a second combat implementation.
    """

    SCREEN_SIZE = (1200, 800)
    GRID_WIDTH = 20
    GRID_HEIGHT = 20

    def __init__(self, configuration: Optional[FreeBattleConfiguration] = None) -> None:
        self.configuration = configuration or FreeBattleConfiguration()
        self.rules = PlacementRules(self.GRID_WIDTH, self.GRID_HEIGHT)
        self.mode = "compose"
        self.return_requested = False
        self.message = "編成を選択してください。各枠をクリックするとキャラクターを切り替えます。"
        self.selected_placement_id: Optional[str] = None
        self.window_size = self.SCREEN_SIZE
        self.layout = self.layout_for_size(self.window_size)

    @classmethod
    def layout_for_size(cls, size: tuple[int, int]) -> FreeBattleLayout:
        # Keep one logical canvas size for narrow phones. Pygbag scales this
        # canvas to the viewport, while every hit box still stays inside the
        # same coordinate system as the drawing code.
        width = max(640, int(size[0]))
        height = max(560, int(size[1]))
        margin = 16 if width < 900 else 24
        panel_gap = 16
        panel_width = min(360, max(260, (width - 2 * margin - panel_gap) // 2))
        left_x = margin
        right_x = width - margin - panel_width
        panel_y = 72 if height < 700 else 90
        panel_height = max(300, min(500, height - panel_y - 80))
        slot_height = 44 if height < 700 else 54
        slot_gap = 6 if height < 700 else 8
        ally_slots = tuple(
            (left_x + 14, panel_y + 54 + i * (slot_height + slot_gap), panel_width - 28, slot_height)
            for i in range(5)
        )
        enemy_slots = tuple(
            (right_x + 14, panel_y + 54 + i * (slot_height + slot_gap), panel_width - 28, slot_height)
            for i in range(5)
        )
        add_y = panel_y + panel_height - 48
        ally_add = (left_x + 14, add_y, (panel_width - 36) // 2, 36)
        ally_remove = (ally_add[0] + ally_add[2] + 8, add_y, ally_add[2], 36)
        enemy_add = (right_x + 14, add_y, (panel_width - 36) // 2, 36)
        enemy_remove = (enemy_add[0] + enemy_add[2] + 8, add_y, enemy_add[2], 36)
        grid_size = min(560, height - 170, width - 2 * margin - 300)
        grid_size = max(220, grid_size)
        grid_x = width - margin - grid_size
        grid_y = 72
        button_height = 48
        button_gap = 8
        button_y = height - margin - button_height
        two_button_width = max(100, (width - 2 * margin - button_gap) // 2)
        confirm = (margin, button_y, two_button_width, button_height)
        menu = (width - margin - two_button_width, button_y, two_button_width, button_height)
        three_button_width = max(100, (width - 2 * margin - 2 * button_gap) // 3)
        back = (margin, button_y, three_button_width, button_height)
        auto_place = (margin + three_button_width + button_gap, button_y, three_button_width, button_height)
        start = (
            margin + 2 * (three_button_width + button_gap),
            button_y,
            three_button_width,
            button_height,
        )
        placement_width = max(120, min(320, grid_x - margin - button_gap))
        placement_height = 34 if height < 700 else 36
        placement_units = tuple(
            (margin, grid_y + i * (placement_height + 4), placement_width, placement_height)
            for i in range(10)
        )
        return FreeBattleLayout(
            window_size=(width, height),
            ally_panel=(left_x, panel_y, panel_width, panel_height),
            enemy_panel=(right_x, panel_y, panel_width, panel_height),
            ally_slots=ally_slots,
            enemy_slots=enemy_slots,
            ally_add=ally_add,
            ally_remove=ally_remove,
            enemy_add=enemy_add,
            enemy_remove=enemy_remove,
            confirm=confirm,
            menu=menu,
            grid_rect=(grid_x, grid_y, grid_size, grid_size),
            placement_units=placement_units,
            auto_place=auto_place,
            start=start,
            back=back,
        )

    def set_window_size(self, size: tuple[int, int]) -> None:
        self.window_size = (max(640, int(size[0])), max(560, int(size[1])))
        self.layout = self.layout_for_size(self.window_size)

    def _team(self, faction: Faction) -> list[str]:
        return (
            self.configuration.ally_character_ids
            if faction is Faction.ALLY
            else self.configuration.enemy_character_ids
        )

    def _cycle_slot(self, faction: Faction, index: int) -> None:
        from .characters import character_definitions

        team = self._team(faction)
        options = character_definitions()
        current = next(i for i, option in enumerate(options) if option.character_id == team[index])
        team[index] = options[(current + 1) % len(options)].character_id
        self.message = f"{faction.value} {index + 1}枠を変更しました。"

    def _add_slot(self, faction: Faction) -> None:
        from .characters import character_definitions

        team = self._team(faction)
        if len(team) >= 5:
            self.message = "1チーム最大5ユニットです。"
            return
        team.append(character_definitions()[0].character_id)
        self.message = "編成枠を追加しました。"

    def _remove_slot(self, faction: Faction) -> None:
        team = self._team(faction)
        if len(team) <= 1:
            self.message = "各チームに最低1ユニット必要です。"
            return
        team.pop()
        self.message = "最後の編成枠を削除しました。"

    def _confirm_composition(self) -> None:
        self.configuration.ally_positions.clear()
        self.configuration.enemy_positions.clear()
        self.configuration.auto_place(self.rules)
        self.selected_placement_id = "ally_1"
        self.mode = "placement"
        self.message = "配置画面です。味方は左半分、敵は右半分へ配置できます。"

    def _unit_ids(self) -> list[str]:
        return [
            *(f"ally_{i + 1}" for i in range(len(self.configuration.ally_character_ids))),
            *(f"enemy_{i + 1}" for i in range(len(self.configuration.enemy_character_ids))),
        ]

    def _position_map(self) -> dict[str, Position]:
        return {**self.configuration.ally_positions, **self.configuration.enemy_positions}

    def _placement_unit_at(self, mouse_position: tuple[int, int]) -> Optional[str]:
        for index, rect in enumerate(self.layout.placement_units):
            if _collide(rect, mouse_position):
                ids = self._unit_ids()
                return ids[index] if index < len(ids) else None
        return None

    def _grid_position(self, mouse_position: tuple[int, int]) -> Optional[Position]:
        x, y, size, _ = self.layout.grid_rect
        if not _collide(self.layout.grid_rect, mouse_position):
            return None
        cell = size / self.GRID_WIDTH
        return Position(int((mouse_position[0] - x) // cell), int((mouse_position[1] - y) // cell))

    def _handle_compose_click(self, mouse_position: tuple[int, int]) -> Optional[str]:
        if _collide(self.layout.menu, mouse_position):
            return "menu"
        if _collide(self.layout.confirm, mouse_position):
            self._confirm_composition()
            return None
        for index, rect in enumerate(self.layout.ally_slots):
            if index < len(self.configuration.ally_character_ids) and _collide(rect, mouse_position):
                self._cycle_slot(Faction.ALLY, index)
                return None
        for index, rect in enumerate(self.layout.enemy_slots):
            if index < len(self.configuration.enemy_character_ids) and _collide(rect, mouse_position):
                self._cycle_slot(Faction.ENEMY, index)
                return None
        if _collide(self.layout.ally_add, mouse_position):
            self._add_slot(Faction.ALLY)
        elif _collide(self.layout.ally_remove, mouse_position):
            self._remove_slot(Faction.ALLY)
        elif _collide(self.layout.enemy_add, mouse_position):
            self._add_slot(Faction.ENEMY)
        elif _collide(self.layout.enemy_remove, mouse_position):
            self._remove_slot(Faction.ENEMY)
        return None

    def _handle_placement_click(self, mouse_position: tuple[int, int]) -> Optional[str]:
        if _collide(self.layout.back, mouse_position):
            self.mode = "compose"
            self.message = "編成を調整できます。"
            return None
        if _collide(self.layout.auto_place, mouse_position):
            self.configuration.auto_place(self.rules)
            self.message = "自動配置しました。必要ならユニットを選んで再配置してください。"
            return None
        if _collide(self.layout.start, mouse_position):
            try:
                self.configuration.validate(self.rules)
                return "start_battle"
            except ValueError as exc:
                self.message = str(exc)
                return None
        selected = self._placement_unit_at(mouse_position)
        if selected is not None:
            self.selected_placement_id = selected
            self.message = f"{selected}を選択中です。配置可能マスをクリックしてください。"
            return None
        destination = self._grid_position(mouse_position)
        if destination is None or self.selected_placement_id is None:
            return None
        faction = Faction.ALLY if self.selected_placement_id.startswith("ally_") else Faction.ENEMY
        positions = self.configuration.ally_positions if faction is Faction.ALLY else self.configuration.enemy_positions
        occupied = {
            position
            for unit_id, position in self._position_map().items()
            if unit_id != self.selected_placement_id
        }
        if not self.rules.allowed(faction, destination):
            self.message = "そのマスは選択中ユニットの配置エリア外です。"
        elif destination in occupied:
            self.message = "そのマスには別のユニットがいます。"
        else:
            positions[self.selected_placement_id] = destination
            self.message = f"{self.selected_placement_id}を({destination.x},{destination.y})へ配置しました。"
        return None

    def handle_click(self, mouse_position: tuple[int, int]) -> Optional[str]:
        if self.mode == "compose":
            return self._handle_compose_click(mouse_position)
        if self.mode == "placement":
            return self._handle_placement_click(mouse_position)
        return None

    # Test/UI compatibility alias.
    _handle_click = handle_click

    def run(self) -> str:
        try:
            import pygame
        except ImportError as exc:
            raise RuntimeError("Pygame-CE is required to run the free battle mode.") from exc

        pygame.init()
        screen = pygame.display.set_mode(self.SCREEN_SIZE, pygame.RESIZABLE)
        self.set_window_size(screen.get_size())
        pygame.display.set_caption("自由戦闘・編成")
        clock = pygame.time.Clock()
        font_path = find_japanese_font(pygame)
        fonts = {
            "title": load_font(pygame, font_path, 28),
            "normal": load_font(pygame, font_path, 18),
            "small": load_font(pygame, font_path, 15),
            "button": load_font(pygame, font_path, 17),
        }
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return self._close_pygame(pygame, "quit")
                if event.type == pygame.VIDEORESIZE:
                    self.set_window_size(event.size)
                    screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return self._close_pygame(pygame, "menu")
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    action = self.handle_click(event.pos)
                    if action == "menu":
                        return self._close_pygame(pygame, "menu")
                    if action == "start_battle":
                        pygame.quit()
                        battle = create_free_battle(self.configuration, rules=self.rules)
                        battle_result = PygameBattleApp(battle, return_on_game_over=True).run()
                        if not battle_result.game_over:
                            return "menu"
                        return self._run_result_screen(battle_result)
            screen.fill((24, 28, 38))
            if self.mode == "compose":
                self._draw_compose(screen, fonts, pygame)
            else:
                self._draw_placement(screen, fonts, pygame)
            pygame.display.flip()
            clock.tick(60)
        return self._close_pygame(pygame, "menu")

    @staticmethod
    def _close_pygame(pygame: Any, result: str) -> str:
        pygame.quit()
        return result

    def _run_result_screen(self, battle: Any) -> str:
        import pygame

        pygame.init()
        screen = pygame.display.set_mode(self.SCREEN_SIZE)
        pygame.display.set_caption("自由戦闘・結果")
        font_path = find_japanese_font(pygame)
        title = load_font(pygame, font_path, 32)
        normal = load_font(pygame, font_path, 20)
        button = load_font(pygame, font_path, 18)
        menu_rect = pygame.Rect(440, 620, 320, 54)
        clock = pygame.time.Clock()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and menu_rect.collidepoint(event.pos):
                    running = False
            screen.fill((24, 28, 38))
            winner = "勝利" if battle.winner is Faction.ALLY else "敗北"
            self._text(screen, title, pygame, f"自由戦闘結果：{winner}", (600, 150), center=True)
            self._text(screen, normal, pygame, self._survivor_summary(battle), (600, 280), center=True)
            self._button(screen, button, pygame, tuple(menu_rect), "メニューへ戻る")
            pygame.display.flip()
            clock.tick(60)
        pygame.quit()
        return "menu"

    @staticmethod
    def _survivor_summary(battle: Any) -> str:
        allies = sum(unit.troops for unit in battle.units_for_side(Faction.ALLY))
        enemies = sum(unit.troops for unit in battle.units_for_side(Faction.ENEMY))
        return f"味方残存兵：{allies}　敵残存兵：{enemies}"

    def _draw_compose(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        center_x = self.layout.window_size[0] // 2
        self._text(screen, fonts["title"], pygame, "自由戦闘：編成", (center_x, 42), center=True)
        self._draw_team_panel(screen, fonts, pygame, Faction.ALLY, self.layout.ally_panel, self.layout.ally_slots)
        self._draw_team_panel(screen, fonts, pygame, Faction.ENEMY, self.layout.enemy_panel, self.layout.enemy_slots)
        self._button(screen, fonts["button"], pygame, self.layout.confirm, "編成確定・配置へ")
        self._button(screen, fonts["button"], pygame, self.layout.menu, "メニューへ戻る")
        self._text(screen, fonts["small"], pygame, self.message, (center_x, self.layout.confirm[1] - 18), center=True)

    def _draw_team_panel(self, screen: Any, fonts: dict[str, Any], pygame: Any, faction: Faction, panel: LayoutRect, slots: tuple[LayoutRect, ...]) -> None:
        import pygame as pg

        color = (40, 65, 92) if faction is Faction.ALLY else (92, 48, 55)
        pg.draw.rect(screen, color, panel)
        pg.draw.rect(screen, (215, 215, 220), panel, 2)
        title = "味方チーム" if faction is Faction.ALLY else "敵チーム"
        self._text(screen, fonts["normal"], pygame, title, (panel[0] + 16, panel[1] + 16))
        team = self._team(faction)
        from .characters import character_definition

        for index, rect in enumerate(slots):
            if index >= len(team):
                continue
            option = character_definition(team[index])
            label = f"{index + 1}. {option.display_name}  ←クリックで変更"
            self._button(screen, fonts["small"], pygame, rect, label)
        add = self.layout.ally_add if faction is Faction.ALLY else self.layout.enemy_add
        remove = self.layout.ally_remove if faction is Faction.ALLY else self.layout.enemy_remove
        self._button(screen, fonts["small"], pygame, add, "＋枠")
        self._button(screen, fonts["small"], pygame, remove, "－枠")

    def _draw_placement(self, screen: Any, fonts: dict[str, Any], pygame: Any) -> None:
        import pygame as pg

        center_x = self.layout.window_size[0] // 2
        self._text(screen, fonts["title"], pygame, "自由戦闘：初期配置", (center_x, 42), center=True)
        x, y, size, _ = self.layout.grid_rect
        cell = size / self.GRID_WIDTH
        half = size // 2
        pg.draw.rect(screen, (45, 75, 65), (x, y, half, size))
        pg.draw.rect(screen, (78, 48, 58), (x + half, y, size - half, size))
        pg.draw.rect(screen, (220, 220, 220), self.layout.grid_rect, 2)
        for i in range(1, self.GRID_WIDTH):
            pg.draw.line(screen, (115, 115, 115), (x + i * cell, y), (x + i * cell, y + size))
            pg.draw.line(screen, (115, 115, 115), (x, y + i * cell), (x + size, y + i * cell))
        positions = self._position_map()
        for index, unit_id in enumerate(self._unit_ids()):
            rect = self.layout.placement_units[index]
            faction = Faction.ALLY if unit_id.startswith("ally_") else Faction.ENEMY
            selected = unit_id == self.selected_placement_id
            self._button(screen, fonts["small"], pygame, rect, f"{unit_id} {positions[unit_id]}", selected=selected)
            position = positions[unit_id]
            center = (int(x + (position.x + 0.5) * cell), int(y + (position.y + 0.5) * cell))
            pg.draw.circle(screen, (80, 160, 240) if faction is Faction.ALLY else (230, 100, 100), center, max(8, int(cell * 0.32)))
            if selected:
                pg.draw.circle(screen, (255, 235, 80), center, max(11, int(cell * 0.40)), 3)
        self._button(screen, fonts["button"], pygame, self.layout.back, "編成へ戻る")
        self._button(screen, fonts["button"], pygame, self.layout.auto_place, "自動配置")
        self._button(screen, fonts["button"], pygame, self.layout.start, "戦闘開始")
        self._text(screen, fonts["small"], pygame, self.message, (center_x, self.layout.start[1] - 18), center=True)

    @staticmethod
    def _text(screen: Any, font: Any, pygame: Any, text: str, position: tuple[int, int], *, center: bool = False) -> None:
        surface = font.render(str(text), True, (245, 245, 250))
        rect = surface.get_rect(center=position) if center else surface.get_rect(topleft=position)
        screen.blit(surface, rect)

    @staticmethod
    def _button(screen: Any, font: Any, pygame: Any, rect_data: LayoutRect, label: str, *, selected: bool = False) -> None:
        rect = pygame.Rect(*rect_data)
        pygame.draw.rect(screen, (110, 128, 155) if selected else (65, 77, 100), rect)
        pygame.draw.rect(screen, (235, 235, 240), rect, 2)
        surface = font.render(str(label), True, (255, 255, 255))
        screen.blit(surface, surface.get_rect(center=rect.center))


def _collide(rect: LayoutRect, position: tuple[int, int]) -> bool:
    x, y, width, height = rect
    return x <= position[0] < x + width and y <= position[1] < y + height
