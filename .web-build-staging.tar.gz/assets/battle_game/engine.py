"""UI-independent turn-based battle engine."""

from __future__ import annotations

from collections import deque
from copy import deepcopy
from dataclasses import dataclass, field
from functools import wraps
from typing import Iterable, Optional

from .characters import create_kenshin, create_masamune, create_saber, create_toudo
from .combat import calculate_damage
from .events import EventContext, EventDispatcher
from .models import Faction, Position, Unit
from .skills import AttackDirection, SkillDefinition, SkillEffect, TargetingMode
from .targeting import infer_line_direction, line_positions


@dataclass(frozen=True, slots=True)
class ActionResult:
    """Result returned by a move, attack, or turn operation."""

    success: bool
    message: str
    damage: int = 0
    defeated: bool = False
    target_id: Optional[str] = None
    skill_id: Optional[str] = None
    target_ids: tuple[str, ...] = ()
    damage_by_target: dict[str, int] = field(default_factory=dict)
    defeated_ids: tuple[str, ...] = ()


def _guard_public_action(method):
    """Reject event-driven re-entry and restore failed action state."""

    @wraps(method)
    def guarded(self: "BattleEngine", *args, **kwargs):
        if self._action_in_progress:
            return ActionResult(False, "Another action is already in progress.")

        snapshot = self._snapshot_state()
        self._action_in_progress = True
        try:
            result = method(self, *args, **kwargs)
            if isinstance(result, ActionResult) and not result.success:
                self._restore_state(snapshot)
            elif isinstance(result, ActionResult) and not self._state_is_valid():
                self._restore_state(snapshot)
                return ActionResult(False, "Action produced an invalid battle state.")
            return result
        except Exception:
            self._restore_state(snapshot)
            raise
        finally:
            self._action_in_progress = False

    return guarded


class BattleEngine:
    """Rules and mutable state for one battle.

    The engine does not import Pygame and can therefore be driven by tests,
    another UI, or a future AI controller.
    """

    def __init__(
        self,
        units: Iterable[Unit],
        *,
        width: int = 20,
        height: int = 20,
        events: Optional[EventDispatcher] = None,
    ) -> None:
        if width <= 0 or height <= 0:
            raise ValueError("map dimensions must be positive")
        self.width = width
        self.height = height
        self.events = events or EventDispatcher()
        self.events.register("after_attack", self._apply_post_attack_abilities)
        self._action_in_progress = False
        self.units: dict[str, Unit] = {}
        for unit in units:
            if unit.unit_id in self.units:
                raise ValueError(f"duplicate unit id: {unit.unit_id}")
            if not self.in_bounds(unit.position):
                raise ValueError(f"unit outside map: {unit.unit_id}")
            if any(
                existing.position == unit.position and not existing.defeated
                for existing in self.units.values()
            ):
                raise ValueError(f"two units occupy {unit.position}")
            self.units[unit.unit_id] = unit

        for unit in self.units.values():
            unit.reset_battle_skills()
            unit.reset_battle_abilities()

        self.turn_side = Faction.ALLY
        self.turn_number = 1
        self.game_over = False
        self.winner: Optional[Faction] = None
        self.last_message = "Ally turn started."
        self._reset_actions_for_side(self.turn_side)
        self._dispatch_turn_start()
        self._check_game_over()

    def _snapshot_state(self) -> tuple:
        """Capture mutable battle state while preserving Unit object identity."""

        unit_refs = dict(self.units)
        unit_states: dict[str, dict[str, object]] = {}
        for unit_id, unit in unit_refs.items():
            state: dict[str, object] = {}
            for unit_field in unit.__dataclass_fields__.values():
                value = getattr(unit, unit_field.name)
                if isinstance(value, dict):
                    state[unit_field.name] = (value, deepcopy(value))
                else:
                    state[unit_field.name] = deepcopy(value)
            unit_states[unit_id] = state
        return (
            self.turn_side,
            self.turn_number,
            self.game_over,
            self.winner,
            self.last_message,
            unit_refs,
            unit_states,
        )

    def _restore_state(self, snapshot: tuple) -> None:
        (
            self.turn_side,
            self.turn_number,
            self.game_over,
            self.winner,
            self.last_message,
            unit_refs,
            unit_states,
        ) = snapshot
        self.units.clear()
        self.units.update(unit_refs)
        for unit_id, state in unit_states.items():
            unit = unit_refs[unit_id]
            for field_name, value in state.items():
                if isinstance(value, tuple) and len(value) == 2 and isinstance(value[0], dict):
                    original_dict, saved_dict = value
                    original_dict.clear()
                    original_dict.update(saved_dict)
                    setattr(unit, field_name, original_dict)
                else:
                    setattr(unit, field_name, value)

    def _state_is_valid(self) -> bool:
        alive_positions: set[Position] = set()
        for unit in self.units.values():
            if not self.in_bounds(unit.position):
                return False
            if unit.troops < 0 or unit.troops > unit.max_troops:
                return False
            if unit.post_attack_move_range < 0:
                return False
            if unit.post_attack_move_available and unit.post_attack_move_range <= 0:
                return False
            if not unit.defeated:
                if unit.position in alive_positions:
                    return False
                alive_positions.add(unit.position)
            for skill_id, uses in unit.skill_uses.items():
                skill = unit.skills.get(skill_id)
                if skill is None:
                    return False
                limit = skill.uses_per_turn or skill.uses_per_battle
                if uses < 0 or uses > limit:
                    return False
            if set(unit.skills) != set(unit.skill_uses):
                return False
            if set(unit.abilities) != set(unit.ability_stacks):
                return False
            if any(stacks < 0 for stacks in unit.ability_stacks.values()):
                return False
        return True

    @classmethod
    def demo(cls) -> "BattleEngine":
        """Create the small hand-playable setup used by the Pygame demo."""

        units = [
            create_saber("ally_1", Faction.ALLY, Position(4, 7)),
            create_masamune("ally_2", Faction.ALLY, Position(4, 10)),
            create_toudo("ally_3", Faction.ALLY, Position(6, 8)),
            create_kenshin("ally_4", Faction.ALLY, Position(6, 11)),
            Unit("enemy_1", "Enemy 1", Faction.ENEMY, Position(13, 8)),
            Unit("enemy_2", "Enemy 2", Faction.ENEMY, Position(14, 11)),
            Unit("enemy_3", "Enemy 3", Faction.ENEMY, Position(12, 13)),
        ]
        return cls(units)

    def in_bounds(self, position: Position) -> bool:
        return 0 <= position.x < self.width and 0 <= position.y < self.height

    def get_unit(self, unit_id: str) -> Unit:
        try:
            return self.units[unit_id]
        except KeyError as exc:
            raise KeyError(f"unknown unit: {unit_id}") from exc

    def units_for_side(self, faction: Faction, *, alive_only: bool = False) -> list[Unit]:
        result = [unit for unit in self.units.values() if unit.faction is faction]
        if alive_only:
            result = [unit for unit in result if not unit.defeated]
        return result

    def _occupied(self, position: Position, *, ignore_unit_id: Optional[str] = None) -> bool:
        return any(
            unit.unit_id != ignore_unit_id
            and not unit.defeated
            and unit.position == position
            for unit in self.units.values()
        )

    def _reset_actions_for_side(self, faction: Faction) -> None:
        for unit in self.units_for_side(faction):
            unit.reset_turn_actions()

    def _apply_post_attack_abilities(self, context: EventContext) -> None:
        """Apply generic after-attack ability effects."""

        attacker = context.attacker
        if (
            attacker is None
            or context.engine is not self
            or context.event_name != "after_attack"
            or not context.metadata.get("attack_successful", False)
        ):
            return

        growth_updates: list[dict[str, int | str]] = []
        for ability_id, ability in attacker.abilities.items():
            if ability.power_per_successful_attack <= 0:
                continue
            stacks = attacker.increment_ability_stack(ability_id)
            growth_updates.append(
                {
                    "ability_id": ability_id,
                    "name": ability.name,
                    "stacks": stacks,
                    "power_bonus": attacker.power_bonus(),
                }
            )
        if growth_updates:
            context.metadata["growth_updates"] = growth_updates

        if not any(
            not unit.defeated
            for unit in self.units_for_side(attacker.faction.opponent)
        ):
            return
        ranges = [
            ability.post_attack_move_range
            for ability in attacker.abilities.values()
            if ability.post_attack_move_range is not None
        ]
        if not ranges:
            return
        context.metadata["end_action"] = False
        context.metadata["post_attack_move_range"] = max(ranges)

    def _dispatch_turn_start(self) -> None:
        for unit in self.units_for_side(self.turn_side, alive_only=True):
            self.events.dispatch(
                "on_turn_start",
                EventContext(
                    event_name="on_turn_start",
                    engine=self,
                    actor=unit,
                    unit=unit,
                    metadata={"turn_number": self.turn_number, "faction": self.turn_side},
                ),
            )

    def _check_game_over(self) -> None:
        allies_alive = any(not unit.defeated for unit in self.units_for_side(Faction.ALLY))
        enemies_alive = any(not unit.defeated for unit in self.units_for_side(Faction.ENEMY))
        if not enemies_alive and allies_alive:
            self.game_over = True
            self.winner = Faction.ALLY
            self.last_message = "Victory! All enemy units were defeated."
        elif not allies_alive and enemies_alive:
            self.game_over = True
            self.winner = Faction.ENEMY
            self.last_message = "Defeat. All ally units were defeated."

    def _validate_active_unit(self, unit_id: str) -> tuple[Optional[Unit], Optional[str]]:
        unit = self.get_unit(unit_id)
        if self.game_over:
            return None, "The battle is over."
        if unit.faction is not self.turn_side:
            return None, "That unit is not on the active side."
        if unit.defeated:
            return None, "That unit has been defeated."
        if unit.action_ended:
            return None, "That unit has already ended its action."
        return unit, None

    def validate_move(self, unit_id: str, destination: Position) -> tuple[bool, str]:
        unit, error = self._validate_active_unit(unit_id)
        if error:
            return False, error
        assert unit is not None
        if unit.moved_this_turn and not unit.post_attack_move_available:
            return False, "This unit already moved this turn."
        if not self.in_bounds(destination):
            return False, "Destination is outside the map."
        if destination == unit.position:
            return False, "Choose a different destination."
        if self._occupied(destination):
            return False, "The destination is occupied."
        if destination not in self.get_reachable_positions(unit_id):
            return False, "That destination is unreachable."
        return True, ""

    def can_move(self, unit_id: str, destination: Position) -> bool:
        return self.validate_move(unit_id, destination)[0]

    def get_reachable_positions(self, unit_id: str) -> set[Position]:
        unit = self.get_unit(unit_id)
        if (
            unit.faction is not self.turn_side
            or unit.defeated
            or unit.action_ended
        ):
            return set()

        if unit.post_attack_move_available:
            move_range = unit.post_attack_move_range
        elif unit.moved_this_turn:
            return set()
        else:
            move_range = unit.move

        reachable: set[Position] = set()
        visited = {unit.position}
        queue: deque[tuple[Position, int]] = deque([(unit.position, 0)])
        directions = ((1, 0), (-1, 0), (0, 1), (0, -1))
        while queue:
            current, distance = queue.popleft()
            if distance >= move_range:
                continue
            for dx, dy in directions:
                next_position = Position(current.x + dx, current.y + dy)
                if next_position in visited or not self.in_bounds(next_position):
                    continue
                visited.add(next_position)
                if self._occupied(next_position, ignore_unit_id=unit.unit_id):
                    continue
                reachable.add(next_position)
                queue.append((next_position, distance + 1))
        return reachable

    @_guard_public_action
    def move_unit(self, unit_id: str, destination: Position) -> ActionResult:
        valid, message = self.validate_move(unit_id, destination)
        if not valid:
            return ActionResult(False, message)
        unit = self.get_unit(unit_id)
        before_context = EventContext(
            event_name="before_move",
            engine=self,
            actor=unit,
            unit=unit,
            from_position=unit.position,
            to_position=destination,
        )
        self.events.dispatch("before_move", before_context)
        if before_context.cancelled:
            return ActionResult(False, "Movement was cancelled by an event.")

        old_position = unit.position
        is_post_attack_move = unit.post_attack_move_available
        unit.position = destination
        if is_post_attack_move:
            unit.clear_post_attack_move()
            unit.post_attack_move_used = True
            unit.action_ended = True
        else:
            unit.moved_this_turn = True
            # A skill such as Toudo's position swap can leave the unit with
            # its normal movement still available after an attack-like
            # action.  Completing that movement must finish the action, while
            # an ordinary move before an attack must remain attackable.
            if unit.attacked_this_turn:
                unit.action_ended = True
        self.events.dispatch(
            "after_move",
            EventContext(
                event_name="after_move",
                engine=self,
                actor=unit,
                unit=unit,
                from_position=old_position,
                to_position=destination,
            ),
        )
        self.last_message = f"{unit.name} moved to ({destination.x}, {destination.y})."
        return ActionResult(True, self.last_message)

    def validate_attack(
        self,
        attacker_id: str,
        defender_id: str,
        *,
        attack_range: Optional[int] = None,
    ) -> tuple[bool, str]:
        attacker, error = self._validate_active_unit(attacker_id)
        if error:
            return False, error
        assert attacker is not None
        if attacker.attacked_this_turn:
            return False, "This unit already attacked this turn."
        defender = self.get_unit(defender_id)
        if defender.faction is attacker.faction:
            return False, "You cannot attack an allied unit."
        if defender.defeated:
            return False, "That unit has already been defeated."
        range_limit = attacker.attack_range if attack_range is None else attack_range
        if attacker.position.manhattan_distance(defender.position) > range_limit:
            return False, "The target is outside attack range."
        return True, ""

    def can_attack(self, attacker_id: str, defender_id: str) -> bool:
        return self.validate_attack(attacker_id, defender_id)[0]

    def _enemy_units_at_positions(
        self,
        attacker: Unit,
        positions: tuple[Position, ...],
    ) -> tuple[Unit, ...]:
        targets: list[Unit] = []
        for position in positions:
            for unit in self.units.values():
                if (
                    not unit.defeated
                    and unit.faction is attacker.faction.opponent
                    and unit.position == position
                ):
                    targets.append(unit)
                    break
        return tuple(targets)

    def get_skill_target_positions(
        self,
        attacker_id: str,
        skill_id: str,
        direction: AttackDirection | str,
    ) -> tuple[Position, ...]:
        """Return geometric cells for a skill, without filtering units."""

        attacker, error = self._validate_active_unit(attacker_id)
        if error or attacker is None:
            return ()
        skill = attacker.skills.get(skill_id)
        if skill is None or attacker.skill_uses_remaining(skill_id) <= 0:
            return ()
        if skill.targeting is not TargetingMode.LINE:
            return ()
        resolved_direction = AttackDirection.coerce(direction)
        return line_positions(
            attacker.position,
            resolved_direction,
            skill.line_length,
            width=self.width,
            height=self.height,
        )

    def get_attackable_targets(
        self,
        attacker_id: str,
        skill_id: Optional[str] = None,
        direction: Optional[AttackDirection | str] = None,
    ) -> list[Unit]:
        """Return enemy targets for normal or selected skill geometry."""

        attacker, error = self._validate_active_unit(attacker_id)
        if error or attacker is None or attacker.attacked_this_turn:
            return []
        if skill_id is None:
            return [
                unit
                for unit in self.units_for_side(attacker.faction.opponent, alive_only=True)
                if attacker.position.manhattan_distance(unit.position) <= attacker.attack_range
            ]

        skill = attacker.skills.get(skill_id)
        if skill is None or attacker.skill_uses_remaining(skill_id) <= 0:
            return []
        if skill.targeting is TargetingMode.PAIR:
            range_limit = attacker.attack_range if skill.attack_range is None else skill.attack_range
            return [
                unit
                for unit in self.units.values()
                if not unit.defeated
                and attacker.position.manhattan_distance(unit.position) <= range_limit
            ]
        if skill.targeting is TargetingMode.LINE:
            if direction is None:
                return []
            positions = self.get_skill_target_positions(attacker_id, skill_id, direction)
            return list(self._enemy_units_at_positions(attacker, positions))

        attack_range = attacker.attack_range if skill.attack_range is None else skill.attack_range
        return [
            unit
            for unit in self.units_for_side(attacker.faction.opponent, alive_only=True)
            if attacker.position.manhattan_distance(unit.position) <= attack_range
        ]

    def _attack_targets_still_valid(
        self,
        attacker: Unit,
        defenders: tuple[Unit, ...],
        *,
        skill_id: Optional[str],
        direction: Optional[AttackDirection],
    ) -> bool:
        """Revalidate an attack after ``before_attack`` callbacks have run."""

        if not self._state_is_valid():
            return False
        current_attacker = self.units.get(attacker.unit_id)
        if (
            current_attacker is not attacker
            or attacker.faction is not self.turn_side
            or attacker.defeated
            or attacker.action_ended
            or attacker.attacked_this_turn
        ):
            return False

        for defender in defenders:
            if self.units.get(defender.unit_id) is not defender or defender.defeated:
                return False

        if skill_id is None:
            return all(self.can_attack(attacker.unit_id, defender.unit_id) for defender in defenders)

        skill = attacker.skills.get(skill_id)
        if skill is None or attacker.skill_uses_remaining(skill_id) <= 0:
            return False

        if skill.targeting is TargetingMode.LINE:
            if direction is None:
                return False
            current_ids = {
                unit.unit_id
                for unit in self.get_attackable_targets(
                    attacker.unit_id,
                    skill_id=skill_id,
                    direction=direction,
                )
            }
            return all(defender.unit_id in current_ids for defender in defenders)

        if skill.targeting is TargetingMode.PAIR:
            current_ids = {
                unit.unit_id
                for unit in self.get_attackable_targets(
                    attacker.unit_id,
                    skill_id=skill_id,
                )
            }
            return (
                len(defenders) == 2
                and defenders[0].unit_id != defenders[1].unit_id
                and all(defender.unit_id in current_ids for defender in defenders)
            )

        range_limit = attacker.attack_range if skill.attack_range is None else skill.attack_range
        return all(
            self.validate_attack(
                attacker.unit_id,
                defender.unit_id,
                attack_range=range_limit,
            )[0]
            for defender in defenders
        )

    def _swap_targets_still_valid(
        self,
        actor: Unit,
        targets: tuple[Unit, Unit],
        skill_id: str,
    ) -> bool:
        """Revalidate a position swap after ``before_swap`` callbacks."""

        if not self._state_is_valid():
            return False
        if self.units.get(actor.unit_id) is not actor:
            return False
        if actor.defeated or actor.action_ended or actor.attacked_this_turn:
            return False
        if actor.skill_uses_remaining(skill_id) <= 0:
            return False
        candidates = {
            unit.unit_id
            for unit in self.get_attackable_targets(actor.unit_id, skill_id=skill_id)
        }
        return (
            targets[0].unit_id != targets[1].unit_id
            and all(self.units.get(target.unit_id) is target for target in targets)
            and all(not target.defeated for target in targets)
            and all(target.unit_id in candidates for target in targets)
        )

    @_guard_public_action
    def attack_unit(self, attacker_id: str, defender_id: str) -> ActionResult:
        valid, message = self.validate_attack(attacker_id, defender_id)
        if not valid:
            return ActionResult(False, message, target_id=defender_id)
        return self._resolve_attack(
            attacker_id,
            (defender_id,),
            base_damage=100,
            attack_kind="normal",
        )

    def _resolve_skill_request(
        self,
        attacker_id: str,
        skill_id: str,
        target_or_direction: Optional[str | AttackDirection | tuple[str, str]],
        direction: Optional[str | AttackDirection],
    ) -> tuple[bool, str, Optional[SkillDefinition], Optional[AttackDirection], tuple[Unit, ...]]:
        attacker, error = self._validate_active_unit(attacker_id)
        if error:
            return False, error, None, None, ()
        assert attacker is not None
        skill = attacker.skills.get(skill_id)
        if skill is None:
            return False, "That unit does not have this skill.", None, None, ()
        if attacker.skill_uses_remaining(skill_id) <= 0:
            return False, f"{skill.name} has already been used this battle.", skill, None, ()

        target_hint: Optional[str] = None
        resolved_direction: Optional[AttackDirection] = None
        if direction is not None:
            resolved_direction = AttackDirection.coerce(direction)
        elif isinstance(target_or_direction, AttackDirection):
            resolved_direction = target_or_direction
        elif isinstance(target_or_direction, str):
            try:
                resolved_direction = AttackDirection.coerce(target_or_direction)
            except ValueError:
                target_hint = target_or_direction

        if skill.targeting is TargetingMode.LINE:
            if resolved_direction is None and target_hint is not None:
                target_unit = self.get_unit(target_hint)
                # Backward compatibility for the Phase 2 target-id overload:
                # callers that still pass one target id retain the old
                # adjacent-target validation. New line attacks pass a
                # direction and use the full line_length geometry.
                if attacker.position.manhattan_distance(target_unit.position) > attacker.attack_range:
                    return False, "The target is outside attack range.", skill, None, ()
                resolved_direction = infer_line_direction(
                    attacker.position,
                    target_unit.position,
                    skill.line_length,
                )
            if resolved_direction is None:
                return False, "Choose an attack direction.", skill, None, ()
            targets = tuple(
                self.get_attackable_targets(
                    attacker_id,
                    skill_id=skill_id,
                    direction=resolved_direction,
                )
            )
            if not targets:
                return False, "There are no enemies in that direction.", skill, resolved_direction, ()
            if target_hint is not None and target_hint not in {unit.unit_id for unit in targets}:
                return False, "The target is outside the skill area.", skill, resolved_direction, ()
            return True, "", skill, resolved_direction, targets

        if skill.targeting is TargetingMode.PAIR:
            if not isinstance(target_or_direction, tuple) or len(target_or_direction) != 2:
                return False, "Choose two different targets.", skill, None, ()
            first_id, second_id = target_or_direction
            if first_id == second_id:
                return False, "Choose two different targets.", skill, None, ()
            candidates = {unit.unit_id for unit in self.get_attackable_targets(attacker_id, skill_id=skill_id)}
            if first_id not in candidates or second_id not in candidates:
                return False, "Both targets must be alive and within swap range.", skill, None, ()
            return True, "", skill, None, (self.get_unit(first_id), self.get_unit(second_id))

        defender_id = target_or_direction if isinstance(target_or_direction, str) else None
        if defender_id is None:
            return False, "Choose a target.", skill, None, ()
        range_limit = attacker.attack_range if skill.attack_range is None else skill.attack_range
        valid, message = self.validate_attack(
            attacker_id,
            defender_id,
            attack_range=range_limit,
        )
        if not valid:
            return False, message, skill, None, ()
        return True, "", skill, None, (self.get_unit(defender_id),)

    def validate_skill(
        self,
        attacker_id: str,
        skill_id: str,
        target_or_direction: Optional[str | AttackDirection | tuple[str, str]] = None,
        *,
        direction: Optional[str | AttackDirection] = None,
    ) -> tuple[bool, str]:
        valid, message, _, _, _ = self._resolve_skill_request(
            attacker_id,
            skill_id,
            target_or_direction,
            direction,
        )
        return valid, message

    def can_use_skill(
        self,
        attacker_id: str,
        skill_id: str,
        target_or_direction: Optional[str | AttackDirection | tuple[str, str]] = None,
        *,
        direction: Optional[str | AttackDirection] = None,
    ) -> bool:
        return self.validate_skill(
            attacker_id,
            skill_id,
            target_or_direction,
            direction=direction,
        )[0]

    @_guard_public_action
    def use_skill(
        self,
        attacker_id: str,
        skill_id: str,
        target_or_direction: Optional[str | AttackDirection | tuple[str, str]] = None,
        *,
        direction: Optional[str | AttackDirection] = None,
    ) -> ActionResult:
        valid, message, skill, resolved_direction, targets = self._resolve_skill_request(
            attacker_id,
            skill_id,
            target_or_direction,
            direction,
        )
        target_hint = target_or_direction if isinstance(target_or_direction, str) else None
        if not valid or skill is None:
            return ActionResult(
                False,
                message,
                target_id=target_hint,
                skill_id=skill_id,
            )
        if skill.effect is SkillEffect.POSITION_SWAP:
            first, second = targets
            before_swap = EventContext(
                event_name="before_swap",
                engine=self,
                actor=self.get_unit(attacker_id),
                unit=self.get_unit(attacker_id),
                target=first,
                targets=(first, second),
                metadata={
                    "skill_id": skill_id,
                    "target_ids": (first.unit_id, second.unit_id),
                    "positions_before": (first.position, second.position),
                },
            )
            self.events.dispatch("before_swap", before_swap)
            if before_swap.cancelled:
                return ActionResult(
                    False,
                    "Position swap was cancelled by an event.",
                    target_ids=(first.unit_id, second.unit_id),
                    skill_id=skill_id,
                )
            actor = self.get_unit(attacker_id)
            if not self._swap_targets_still_valid(actor, (first, second), skill_id):
                return ActionResult(
                    False,
                    "Position swap targets became invalid after the event.",
                    target_ids=(first.unit_id, second.unit_id),
                    skill_id=skill_id,
                )
            if not actor.consume_skill(skill_id):
                return ActionResult(
                    False,
                    "The skill is no longer available.",
                    target_ids=(first.unit_id, second.unit_id),
                    skill_id=skill_id,
                )
            first_position, second_position = first.position, second.position
            first.position, second.position = second_position, first_position
            self.events.dispatch(
                "after_swap",
                EventContext(
                    event_name="after_swap",
                    engine=self,
                    actor=actor,
                    unit=actor,
                    target=first,
                    targets=(first, second),
                    metadata={
                        "skill_id": skill_id,
                        "target_ids": (first.unit_id, second.unit_id),
                        "positions_before": (first_position, second_position),
                        "positions_after": (first.position, second.position),
                    },
                ),
            )
            if not self._state_is_valid():
                return ActionResult(
                    False,
                    "Position swap produced an invalid battle state.",
                    target_ids=(first.unit_id, second.unit_id),
                    skill_id=skill_id,
                )
            actor.attacked_this_turn = True
            # ``ends_action`` is a skill-level rule.  A skill that leaves the
            # normal move unused may continue the action once; if the unit
            # already moved, the same skill still ends the action.
            actor.action_ended = skill.ends_action or actor.moved_this_turn
            self.last_message = (
                f"{actor.name} used {skill.name}: "
                f"{first.name} and {second.name} swapped positions."
            )
            self._maybe_advance_turn()
            return ActionResult(
                True,
                self.last_message,
                target_id=first.unit_id,
                target_ids=(first.unit_id, second.unit_id),
                skill_id=skill_id,
            )
        return self._resolve_attack(
            attacker_id,
            tuple(unit.unit_id for unit in targets),
            base_damage=skill.base_damage,
            attack_kind="skill",
            skill_id=skill_id,
            action_label=skill.name,
            direction=resolved_direction,
        )

    def _resolve_attack(
        self,
        attacker_id: str,
        target_ids: tuple[str, ...],
        *,
        base_damage: int,
        attack_kind: str,
        skill_id: Optional[str] = None,
        action_label: str = "normal attack",
        direction: Optional[AttackDirection] = None,
    ) -> ActionResult:
        attacker = self.get_unit(attacker_id)
        defenders = tuple(self.get_unit(unit_id) for unit_id in target_ids)
        if not defenders:
            return ActionResult(False, "There are no valid targets.", skill_id=skill_id)

        attacker_troops_at_start = attacker.troops
        first_target = defenders[0]
        before_attack = EventContext(
            event_name="before_attack",
            engine=self,
            actor=attacker,
            attacker=attacker,
            target=first_target,
            targets=defenders,
            defender=first_target,
            direction=direction,
            metadata={
                "event_scope": "attack",
                "attack_kind": attack_kind,
                "skill_id": skill_id,
                "base_damage": base_damage,
                "target_ids": target_ids,
                "target_count": len(defenders),
                "attacker_troops_at_start": attacker_troops_at_start,
            },
        )
        self.events.dispatch("before_attack", before_attack)
        if before_attack.cancelled:
            return ActionResult(
                False,
                "Attack was cancelled by an event.",
                target_id=target_ids[0] if len(target_ids) == 1 else None,
                target_ids=target_ids,
                skill_id=skill_id,
            )

        if not self._attack_targets_still_valid(
            attacker,
            defenders,
            skill_id=skill_id,
            direction=direction,
        ):
            return ActionResult(
                False,
                "Attack targets became invalid after the event.",
                target_id=target_ids[0] if len(target_ids) == 1 else None,
                target_ids=target_ids,
                skill_id=skill_id,
            )

        if skill_id is not None and not attacker.consume_skill(skill_id):
            return ActionResult(
                False,
                "The skill is no longer available.",
                target_id=target_ids[0] if len(target_ids) == 1 else None,
                target_ids=target_ids,
                skill_id=skill_id,
            )

        resolved_base_damage = int(before_attack.metadata.get("base_damage", base_damage))
        damage_by_target: dict[str, int] = {}
        defeated_ids: list[str] = []

        for defender in defenders:
            calculated_damage = calculate_damage(
                attacker,
                defender,
                base_damage=resolved_base_damage,
                attacker_troops=attacker_troops_at_start,
            )
            before_damage = EventContext(
                event_name="before_damage",
                engine=self,
                actor=attacker,
                attacker=attacker,
                target=defender,
                targets=(defender,),
                defender=defender,
                direction=direction,
                damage=calculated_damage,
                metadata={
                    "event_scope": "target",
                    "calculated_damage": calculated_damage,
                    "base_damage": resolved_base_damage,
                    "attack_kind": attack_kind,
                    "skill_id": skill_id,
                    "target_ids": (defender.unit_id,),
                    "attacker_troops_at_start": attacker_troops_at_start,
                },
            )
            self.events.dispatch("before_damage", before_damage)
            proposed_damage = 0 if before_damage.cancelled else max(0, before_damage.damage)
            troops_before = defender.troops
            applied_damage = min(proposed_damage, defender.troops)
            defender.troops = max(0, defender.troops - applied_damage)
            damage_by_target[defender.unit_id] = applied_damage

            lethal_cancelled = False
            if defender.defeated:
                on_lethal = EventContext(
                    event_name="on_lethal",
                    engine=self,
                    actor=attacker,
                    attacker=attacker,
                    target=defender,
                    targets=(defender,),
                    defender=defender,
                    direction=direction,
                    damage=applied_damage,
                    prevent_defeat=False,
                    metadata={
                        "event_scope": "target",
                        "troops_before_damage": troops_before,
                        "base_damage": resolved_base_damage,
                        "attack_kind": attack_kind,
                        "skill_id": skill_id,
                    },
                )
                self.events.dispatch("on_lethal", on_lethal)
                if on_lethal.prevent_defeat or on_lethal.cancelled:
                    defender.troops = 1
                    lethal_cancelled = True

            self.events.dispatch(
                "after_damage",
                EventContext(
                    event_name="after_damage",
                    engine=self,
                    actor=attacker,
                    attacker=attacker,
                    target=defender,
                    targets=(defender,),
                    defender=defender,
                    direction=direction,
                    damage=applied_damage,
                    metadata={
                        "event_scope": "target",
                        "calculated_damage": calculated_damage,
                        "applied_damage": applied_damage,
                        "lethal_cancelled": lethal_cancelled,
                        "base_damage": resolved_base_damage,
                        "attack_kind": attack_kind,
                        "skill_id": skill_id,
                    },
                ),
            )

            defeated = defender.defeated and not lethal_cancelled
            if defeated:
                defeated_ids.append(defender.unit_id)
                self.events.dispatch(
                    "on_defeat",
                    EventContext(
                        event_name="on_defeat",
                        engine=self,
                        actor=attacker,
                        unit=defender,
                        target=defender,
                        targets=(defender,),
                        attacker=attacker,
                        defender=defender,
                        direction=direction,
                        damage=applied_damage,
                        metadata={
                            "event_scope": "target",
                            "base_damage": resolved_base_damage,
                            "attack_kind": attack_kind,
                            "skill_id": skill_id,
                        },
                    ),
                )
                if not defender.defeated:
                    raise RuntimeError("on_defeat handlers cannot revive a defeated unit.")

        attacker.attacked_this_turn = True
        total_damage = sum(damage_by_target.values())
        after_attack = EventContext(
            event_name="after_attack",
            engine=self,
            actor=attacker,
            attacker=attacker,
            target=first_target,
            targets=defenders,
            defender=first_target,
            direction=direction,
            damage=total_damage,
            metadata={
                "event_scope": "attack",
                "end_action": True,
                "defeated_ids": tuple(defeated_ids),
                "damage_by_target": dict(damage_by_target),
                "attack_kind": attack_kind,
                "skill_id": skill_id,
                "base_damage": resolved_base_damage,
                "attack_successful": True,
            },
        )
        self.events.dispatch("after_attack", after_attack)
        post_attack_move_range = after_attack.metadata.get("post_attack_move_range")
        if (
            not after_attack.metadata.get("end_action", True)
            and post_attack_move_range is not None
        ):
            attacker.grant_post_attack_move(int(post_attack_move_range))
        if after_attack.metadata.get("end_action", True):
            attacker.action_ended = True

        self._check_game_over()
        self._maybe_advance_turn()
        if skill_id is None:
            if len(defenders) == 1:
                result_message = f"{attacker.name} dealt {total_damage} damage to {first_target.name}."
            else:
                result_message = f"{attacker.name} dealt {total_damage} damage to {len(defenders)} targets."
        else:
            result_message = (
                f"{attacker.name} used {action_label} and dealt "
                f"{total_damage} damage to {len(defenders)} target(s)."
            )
        for update in after_attack.metadata.get("growth_updates", ()):
            result_message += (
                f" {update['name']} stack: {update['stacks']} "
                f"(power +{update['power_bonus']})."
            )
        if defeated_ids:
            result_message += f" {len(defeated_ids)} target(s) were defeated."
        self.last_message = result_message
        return ActionResult(
            True,
            result_message,
            damage=total_damage,
            defeated=bool(defeated_ids),
            target_id=target_ids[0] if len(target_ids) == 1 else None,
            skill_id=skill_id,
            target_ids=target_ids,
            damage_by_target=damage_by_target,
            defeated_ids=tuple(defeated_ids),
        )

    @_guard_public_action
    def end_unit_action(self, unit_id: str) -> ActionResult:
        unit, error = self._validate_active_unit(unit_id)
        if error:
            return ActionResult(False, error)
        assert unit is not None
        unit.clear_post_attack_move()
        unit.action_ended = True
        self.last_message = f"{unit.name} ended its action."
        self._maybe_advance_turn()
        return ActionResult(True, self.last_message)

    @_guard_public_action
    def end_turn(self) -> ActionResult:
        if self.game_over:
            return ActionResult(False, "The battle is over.")
        for unit in self.units_for_side(self.turn_side, alive_only=True):
            unit.clear_post_attack_move()
            unit.action_ended = True
        self._advance_turn()
        return ActionResult(True, self.last_message)

    def _maybe_advance_turn(self) -> None:
        if self.game_over:
            return
        active_units = self.units_for_side(self.turn_side, alive_only=True)
        if active_units and all(unit.action_ended for unit in active_units):
            self._advance_turn()

    def _advance_turn(self) -> None:
        if self.game_over:
            return
        for unit in self.units_for_side(self.turn_side):
            unit.clear_post_attack_move()
        self.turn_side = self.turn_side.opponent
        self.turn_number += 1
        self._reset_actions_for_side(self.turn_side)
        self._dispatch_turn_start()
        self.last_message = f"{self.turn_side.value.title()} turn started."
        self._check_game_over()
