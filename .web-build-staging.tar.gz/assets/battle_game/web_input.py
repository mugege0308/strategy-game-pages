"""Small, dependency-free pointer helpers for the browser frontend.

Pygame-web normally turns a tap into a mouse event, but some mobile/browser
combinations also expose ``FINGERDOWN``.  Keeping the conversion here makes
the web entry point testable without opening a Pygame window and does not
change the Windows UI event path.
"""

from __future__ import annotations

from typing import Any, Optional


class PointerDeduplicator:
    """Suppress one synthetic mouse event after a touch event.

    SDL/Pygbag may expose the same tap as ``FINGERDOWN`` and
    ``MOUSEBUTTONDOWN``.  The first event is handled, while a near-identical
    second event in the short compatibility window is ignored.
    """

    def __init__(self, window_ms: int = 180) -> None:
        self.window_ms = max(0, int(window_ms))
        self._last_position: Optional[tuple[int, int]] = None
        self._last_time_ms: Optional[int] = None

    def accept(self, position: tuple[int, int], time_ms: Optional[int]) -> bool:
        if time_ms is not None and self._last_position == position and self._last_time_ms is not None:
            if 0 <= time_ms - self._last_time_ms <= self.window_ms:
                return False
        self._last_position = position
        self._last_time_ms = time_ms
        return True


def normalized_touch_position(
    x: float,
    y: float,
    screen_size: tuple[int, int],
) -> tuple[int, int]:
    """Convert Pygame's normalized finger coordinates to screen pixels."""

    width, height = (max(1, int(screen_size[0])), max(1, int(screen_size[1])))
    return (
        max(0, min(width - 1, int(round(float(x) * width)))),
        max(0, min(height - 1, int(round(float(y) * height)))),
    )


def pointer_down_position(
    event: Any,
    screen_size: tuple[int, int],
    *,
    mouse_button_down_type: int,
    finger_down_type: Optional[int],
) -> Optional[tuple[int, int]]:
    """Return a left-click/tap position, or ``None`` for other events."""

    event_type = getattr(event, "type", None)
    if event_type == mouse_button_down_type and getattr(event, "button", None) == 1:
        position = getattr(event, "pos", None)
        if position is not None:
            return int(position[0]), int(position[1])
    if finger_down_type is not None and event_type == finger_down_type:
        return normalized_touch_position(
            getattr(event, "x", 0.0),
            getattr(event, "y", 0.0),
            screen_size,
        )
    return None
