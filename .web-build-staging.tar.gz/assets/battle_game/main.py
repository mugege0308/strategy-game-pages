"""Command-line entry point for the battle and strategic-map demos."""

from .mode_ui import PygameModeMenu
from .free_battle_ui import FreeBattleApp
from .strategy_ui import StrategyMapApp
from .ui import PygameBattleApp


def main() -> None:
    next_mode = "menu"
    strategy_app: StrategyMapApp | None = None
    while next_mode != "quit":
        if next_mode == "menu":
            strategy_app = None
            next_mode = PygameModeMenu().run()
        elif next_mode == "battle":
            PygameBattleApp().run()
            next_mode = "menu"
        elif next_mode == "free_battle":
            FreeBattleApp().run()
            next_mode = "menu"
        elif next_mode == "strategy":
            strategy_app = strategy_app or StrategyMapApp()
            next_mode = strategy_app.run()
        elif next_mode == "invasion":
            if strategy_app is None:
                next_mode = "menu"
                continue
            battle = strategy_app.start_invasion()
            if battle is None:
                next_mode = "strategy"
                continue
            battle_result = PygameBattleApp(battle, return_on_game_over=True).run()
            if battle_result.game_over:
                result = strategy_app.finish_invasion(battle_result)
                if not result.success:
                    strategy_app.cancel_invasion()
                next_mode = "strategy"
            else:
                strategy_app.cancel_invasion()
                next_mode = "quit"
        else:
            next_mode = "quit"


if __name__ == "__main__":
    main()
